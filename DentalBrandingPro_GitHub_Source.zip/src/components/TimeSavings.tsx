import React from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import { Clock, Shield, Sparkles, UserCheck, CalendarCheck, HelpCircle, Star } from 'lucide-react';

interface TimeSavingsProps {
  lang: Language;
}

export const TimeSavings: React.FC<TimeSavingsProps> = ({ lang }) => {
  const strings = t[lang];
  const isAr = lang === 'ar';

  const icons = [
    <HelpCircle key="1" className="w-5 h-5 text-[#00D4B2]" />,
    <CalendarCheck key="2" className="w-5 h-5 text-blue-500" />,
    <UserCheck key="3" className="w-5 h-5 text-teal-500" />,
    <Star key="4" className="w-5 h-5 text-amber-500" />,
  ];

  return (
    <section id="gain-temps" className="py-16 lg:py-24 bg-white dark:bg-[#071324] border-b border-slate-200 dark:border-slate-800 transition-colors duration-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-teal-800 dark:text-teal-300 text-xs font-bold uppercase tracking-wider mb-3">
            <Clock className="w-3.5 h-3.5 text-teal-600 dark:text-teal-400" />
            <span>{isAr ? 'إنتاجية العيادة واسترجاع الوقت' : 'Productivité Médicale'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#0F2C59] dark:text-white tracking-tight mb-3">
            {strings.timeSavings.title}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
            {strings.timeSavings.subtitle}
          </p>
        </div>

        {/* 4 Glassmorphic Breakdown Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto mb-10">
          {strings.timeSavings.cards.map((card, idx) => (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-slate-50/80 dark:bg-slate-800/50 border border-slate-200/80 dark:border-slate-700/60 hover:border-[#00D4B2] dark:hover:border-[#00D4B2] transition-all hover:shadow-lg flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div className="w-10 h-10 rounded-xl bg-white dark:bg-slate-700/80 shadow-2xs border border-slate-200 dark:border-slate-600 flex items-center justify-center">
                    {icons[idx]}
                  </div>
                  <span className="text-base font-black font-mono text-[#0F2C59] dark:text-white bg-white dark:bg-slate-700/80 px-2.5 py-1 rounded-lg border border-slate-200 dark:border-slate-600">
                    {card.hours}
                  </span>
                </div>

                <h3 className="text-base font-bold text-slate-900 dark:text-white mb-2 group-hover:text-[#0F2C59] dark:group-hover:text-[#00D4B2] transition-colors">
                  {card.title}
                </h3>
                <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                  {card.desc}
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-200/60 dark:border-slate-700/50 flex items-center gap-1.5 text-[11px] font-medium text-teal-700 dark:text-teal-400">
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isAr ? 'منظومة آلية 100%' : 'Processus 100% automatisé'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Total summary proof banner */}
        <div className="max-w-3xl mx-auto p-4 sm:p-5 rounded-2xl bg-[#0F2C59] dark:bg-slate-800/90 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-xl border border-transparent dark:border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#00D4B2]/20 flex items-center justify-center text-[#00D4B2] shrink-0">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">
                {isAr ? 'الحصيلة الإجمالية الشهرية' : 'Bilan Cumulé Mensuel'}
              </div>
              <div className="text-xs text-slate-300">{strings.timeSavings.total}</div>
            </div>
          </div>
          <div className="text-xs font-bold text-[#00D4B2] uppercase tracking-wider bg-white/10 px-3 py-1.5 rounded-lg border border-white/15">
            {isAr ? '+180 مريض يحظى باستقبال أفضل سنوياً' : '+180 Patients Mieux Reçus / An'}
          </div>
        </div>

      </div>
    </section>
  );
};
