import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import {
  Smartphone,
  ExternalLink,
  RotateCcw,
  Lock,
  Unlock,
  Globe,
  BookOpen,
  QrCode,
  FileSpreadsheet,
  CheckCircle2,
  ShieldCheck,
  Zap,
  Wifi,
  Signal,
  BatteryCharging,
  Maximize2,
  ChevronRight,
  Sparkles,
  MousePointerClick,
  Layers,
  Activity,
  Check,
} from 'lucide-react';

interface IPhonePreviewProps {
  lang: Language;
}

type DeviceMode = 's24' | 'compact';

interface DemoItem {
  id: string;
  number: string;
  label: { fr: string; ar: string };
  sub: { fr: string; ar: string };
  badge: { fr: string; ar: string };
  url: string;
  embedUrl?: string;
  icon: React.ComponentType<{ className?: string }>;
  features: {
    fr: string[];
    ar: string[];
  };
  metrics: {
    fr: { label: string; val: string };
    ar: { label: string; val: string };
  };
}

export const IPhonePreview: React.FC<IPhonePreviewProps> = ({ lang }) => {
  const isAr = lang === 'ar';
  const tr = t[lang].preview;

  const demos: DemoItem[] = [
    {
      id: 'site',
      number: '01',
      label: {
        fr: 'Site Web Interactif du Cabinet',
        ar: 'الموقع الإلكتروني التفاعلي للعيادة',
      },
      sub: {
        fr: 'Diagnostic guidé en 3 clics, calcul des coûts & prise de RDV WhatsApp direct',
        ar: 'تشخيص ذاتي موجه للأعراض، حاسبة التكلفة التقديرية وحجز فوري عبر واتساب',
      },
      badge: {
        fr: 'Score 99/100 • Ultra-Rapide',
        ar: 'سرعة 99/100 • فائقة',
      },
      url: 'https://centre-dentaire-yasmile.netlify.app/',
      icon: Globe,
      features: {
        fr: [
          'Diagnostic Dentaire Interactif par symptômes',
          'Calculateur de devis estimatif temps réel',
          'Bouton de prise de RDV qualifiée sur WhatsApp',
          'Vitesse de chargement record (< 0.8s)',
        ],
        ar: [
          'أداة التشخيص الذاتي التفاعلي للأعراض',
          'حاسبة التكلفة التقديرية التفاعلية للمريض',
          'زر حجز الموعد المؤهل مباشرة عبر الواتساب',
          'سرعة تحميل قياسية (< 0.8 ثانية) معتمدة',
        ],
      },
      metrics: {
        fr: { label: 'Vitesse Mobile', val: '0.7s • PageSpeed 99' },
        ar: { label: 'سرعة التحميل', val: '0.7 ثانية • تقييم 99' },
      },
    },
    {
      id: 'blog',
      number: '02',
      label: {
        fr: 'Blog Médical SEO & Réponses Prêtes',
        ar: 'المدونة الطبية وبنك الإجابات الجاهزة',
      },
      sub: {
        fr: '20+ articles médicaux de référencement & banques de réponses WhatsApp pour la secrétaire',
        ar: 'مقالات سيو طبية متخصصة وبنك ردود واتساب لتوفير وقت السكرتارية',
      },
      badge: {
        fr: '+15h de secrétariat libérées',
        ar: 'توفير 15 ساعة/أسبوع',
      },
      url: 'https://yasmile-blog.netlify.app/',
      icon: BookOpen,
      features: {
        fr: [
          'Articles SEO locaux prêts pour Google & IA',
          'Banque de réponses rapides pour WhatsApp',
          'Modèles de réponses aux avis Google (Avis Patients)',
          'Foire aux questions (FAQ) médicale rassurante',
        ],
        ar: [
          'مقالات سيو محلية معتمدة لمحركات البحث والذكاء الاصطناعي',
          'بنك سيناريوهات الردود الجاهزة لواتساب السكرتارية',
          'نماذج الرد الاحترافي على تقييمات المرضى في Google',
          'قسم الأسئلة الشائعة الطبية لتطمين المريض مسبقاً',
        ],
      },
      metrics: {
        fr: { label: 'Gain Hebdo', val: '15h libérées / sem.' },
        ar: { label: 'الوقت المسترجع', val: '15 ساعة / أسبوع' },
      },
    },
    {
      id: 'bio',
      number: '03',
      label: {
        fr: 'Carte Bio Digitale DentaLink',
        ar: 'بطاقة الاتصال الرقمية DentaLink',
      },
      sub: {
        fr: 'Page bio chirurgicale pour Instagram : bouton vCard, bouton urgence & QR Code HD',
        ar: 'صفحة بايو ذكية لإنستغرام: حفظ جهة الاتصال vCard، زر الطوارئ ورمز QR فائق الدقة',
      },
      badge: {
        fr: 'Smart Contact • 1 Clic',
        ar: 'حفظ الاتصال • بنقرة واحدة',
      },
      url: 'https://yasmile-bio.netlify.app/',
      icon: QrCode,
      features: {
        fr: [
          'Bouton vCard : enregistrement direct du contact du cabinet',
          'Bouton Urgence dentaire prioritaire immédiat',
          'Accès direct Google Maps & itinéraires GPS',
          'QR Code HD imprimable pour cartes de visite papier',
        ],
        ar: [
          'زر vCard لحفظ رقم العيادة في هاتف المريض بنقرة واحدة',
          'زر الطوارئ المباشر للحالات المستعجلة',
          'رابط مباشر لموقع العيادة على خرائط Google',
          'رمز QR فائق الدقة قابل للطباعة على الكروت الورقية',
        ],
      },
      metrics: {
        fr: { label: 'Conversion Bio', val: '+45% de contacts' },
        ar: { label: 'معدل الحفظ', val: '+45% حفظ مباشر' },
      },
    },
    {
      id: 'guide',
      number: '04',
      label: {
        fr: 'Guide Opérationnel & Scripts',
        ar: 'الدليل التشغيلي وبنك المحتوى السنوي',
      },
      sub: {
        fr: 'Banque de 52 semaines de contenu Instagram, scripts de réception & guide Google Maps Top 3',
        ar: 'خطة 52 أسبوعاً لمنشورات إنستغرام، سيناريو استقبال المكالمات وتصدر خرائط Google',
      },
      badge: {
        fr: '52 Semaines de Contenu',
        ar: '52 أسبوع خطة متكاملة',
      },
      url: 'https://yasmile-guide.netlify.app/',
      embedUrl: '/demo-guide/index.html',
      icon: FileSpreadsheet,
      features: {
        fr: [
          'Banque de contenu Instagram pour 52 semaines',
          'Script chirurgical d’accueil téléphonique pour la secrétaire',
          'Guide d’optimisation Google Maps pour atteindre le Top 3',
          'Modèles de messages de relance et de confirmation',
        ],
        ar: [
          'بنك أفكار ومنشورات طبية لإنستغرام تغطي 52 أسبوعاً كاملاً',
          'سيناريو احترافي لاستقبال المكالمات والرد على السكرتارية',
          'دليل تحسين الحساب وتصدر المراتب الثلاث الأولى في Google Maps',
          'قوالب رسائل تأكيد ومتابعة المواعيد بعد العلاج',
        ],
      },
      metrics: {
        fr: { label: 'Visibilité Google', val: 'Objectif Top 3 Local' },
        ar: { label: 'الظهور المحلي', val: 'المراتب الـ 3 الأولى' },
      },
    },
  ];

  const [activeDemo, setActiveDemo] = useState<DemoItem>(demos[0]);
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('s24');
  const [touchEnabled, setTouchEnabled] = useState(false);
  const [iframeKey, setIframeKey] = useState(0);
  const [isLoading, setIsLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState('09:41');

  // Update clock
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const minutes = now.getMinutes().toString().padStart(2, '0');
      setCurrentTime(`${hours}:${minutes}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleReload = () => {
    setIsLoading(true);
    setIframeKey((prev) => prev + 1);
  };

  const handleSelectDemo = (demo: DemoItem) => {
    if (demo.id !== activeDemo.id) {
      setActiveDemo(demo);
      setIsLoading(true);
      setIframeKey((prev) => prev + 1);
    }
  };

  // Dimensions config - Exclusively Flagship Android Devices
  const deviceSpecs = {
    s24: {
      name: isAr ? 'الهاتف الذكي (Android)' : 'Le Smartphone (Android)',
      label: isAr ? 'الهاتف' : 'Smartphone',
      dimensions: '412 × 915 px',
      aspectRatio: 'aspect-[412/860]',
      maxWidthClass: 'w-full max-w-[412px]',
      heightClass: 'h-[600px] sm:h-[730px] md:h-[800px]',
      corner: 'rounded-[32px] sm:rounded-[38px]',
      innerCorner: 'rounded-[24px] sm:rounded-[28px]',
      notchType: 'punch-hole',
    },
    compact: {
      name: isAr ? 'أندرويد قياسي (Android Compact)' : 'Android Standard (Compact View)',
      label: isAr ? 'أندرويد مدمج' : 'Android Compact',
      dimensions: '360 × 780 px',
      aspectRatio: 'aspect-[360/780]',
      maxWidthClass: 'w-full max-w-[360px]',
      heightClass: 'h-[570px] sm:h-[680px] md:h-[740px]',
      corner: 'rounded-[28px] sm:rounded-[34px]',
      innerCorner: 'rounded-[20px] sm:rounded-[26px]',
      notchType: 'punch-hole',
    },
  };

  const currentSpec = deviceSpecs[deviceMode];

  return (
    <section
      id="demo-3d"
      className="py-16 sm:py-20 lg:py-28 bg-[#071326] text-white relative overflow-hidden border-b border-slate-800"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Background ambient lighting */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] bg-[#00D4B2]/10 rounded-full blur-[140px] pointer-events-none"></div>
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-[#0F2C59]/40 rounded-full blur-[120px] pointer-events-none"></div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10 sm:mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#00D4B2]/15 border border-[#00D4B2]/40 text-[#00D4B2] text-xs font-bold uppercase tracking-wider mb-4 shadow-sm shadow-[#00D4B2]/10">
            <Smartphone className="w-4 h-4 text-[#00D4B2]" />
            <span>{tr.badge}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold tracking-tight text-white mb-4 leading-tight">
            {tr.title}
          </h2>

          <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
            {tr.subtitle}
          </p>

          {/* Quick Real-Time Status Pill */}
          <div className="mt-5 inline-flex flex-wrap items-center justify-center gap-3 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-semibold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              <span className="w-1.5 h-1.5 -ml-3.5 rounded-full bg-emerald-400"></span>
              {tr.liveBadge}
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-slate-300">
              <ShieldCheck className="w-3.5 h-3.5 text-[#00D4B2]" />
              {tr.sslSecure}
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-800/80 border border-slate-700/80 text-amber-300">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              {tr.speedScore}
            </span>
          </div>
        </div>

        {/* 4 Interactive Live Elements Selector Deck */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-8 sm:mb-10">
          {demos.map((d) => {
            const Icon = d.icon;
            const isActive = activeDemo.id === d.id;
            return (
              <button
                key={d.id}
                onClick={() => handleSelectDemo(d)}
                className={`relative text-start p-4 sm:p-4.5 rounded-2xl transition-all duration-300 border flex flex-col justify-between group ${
                  isActive
                    ? 'bg-gradient-to-b from-[#0F2C59] to-[#0A192F] border-[#00D4B2] shadow-xl shadow-[#00D4B2]/15 ring-2 ring-[#00D4B2]/30 scale-[1.02]'
                    : 'bg-slate-800/60 hover:bg-slate-800/90 border-slate-700/80 hover:border-slate-600 text-slate-300'
                }`}
              >
                {/* Top Badge & Number */}
                <div className="flex items-center justify-between gap-2 mb-3 w-full">
                  <div className="flex items-center gap-2">
                    <span
                      className={`text-xs font-black px-2 py-0.5 rounded-md font-mono ${
                        isActive
                          ? 'bg-[#00D4B2] text-[#0A192F]'
                          : 'bg-slate-700 text-slate-300 group-hover:bg-slate-600'
                      }`}
                    >
                      {d.number}
                    </span>
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        isActive
                          ? 'bg-[#00D4B2]/20 text-[#00D4B2] border border-[#00D4B2]/40'
                          : 'bg-slate-700/60 text-slate-400'
                      }`}
                    >
                      {isAr ? d.badge.ar : d.badge.fr}
                    </span>
                  </div>

                  {isActive ? (
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00D4B2] shadow-sm shadow-[#00D4B2] animate-pulse"></span>
                  ) : (
                    <span className="w-2 h-2 rounded-full bg-slate-600"></span>
                  )}
                </div>

                {/* Title & Subtitle */}
                <div className="mb-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Icon
                      className={`w-4 h-4 shrink-0 ${
                        isActive ? 'text-[#00D4B2]' : 'text-slate-400 group-hover:text-white'
                      }`}
                    />
                    <h3
                      className={`font-bold text-sm sm:text-base leading-snug line-clamp-1 ${
                        isActive ? 'text-white' : 'text-slate-200'
                      }`}
                    >
                      {isAr ? d.label.ar : d.label.fr}
                    </h3>
                  </div>
                  <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                    {isAr ? d.sub.ar : d.sub.fr}
                  </p>
                </div>

                {/* Footer Metric Pill */}
                <div className="pt-2 border-t border-slate-700/50 flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">
                    {isAr ? d.metrics.ar.label : d.metrics.fr.label}
                  </span>
                  <span
                    className={`font-semibold ${
                      isActive ? 'text-[#00D4B2]' : 'text-slate-300'
                    }`}
                  >
                    {isAr ? d.metrics.ar.val : d.metrics.fr.val}
                  </span>
                </div>
              </button>
            );
          })}
        </div>

        {/* Device Dimension Bar & Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-6 p-3 bg-slate-800/80 border border-slate-700/80 rounded-2xl max-w-4xl mx-auto backdrop-blur-sm">
          {/* Dimension Presets */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-center sm:justify-start">
            <span className="text-xs text-slate-400 font-medium hidden md:inline-block">
              {tr.deviceDimensions}
            </span>
            <div className="inline-flex rounded-xl bg-slate-900/90 p-1 border border-slate-700/60">
              <button
                onClick={() => setDeviceMode('s24')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  deviceMode === 's24'
                    ? 'bg-[#00D4B2] text-[#0A192F] shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <span>{isAr ? 'الهاتف الذكي' : 'Le Smartphone'}</span>
                <span className="text-[10px] opacity-75 font-mono">(412×915)</span>
              </button>

              <button
                onClick={() => setDeviceMode('compact')}
                className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                  deviceMode === 'compact'
                    ? 'bg-[#00D4B2] text-[#0A192F] shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <span>{isAr ? 'أندرويد مدمج' : 'Android Compact'}</span>
                <span className="text-[10px] opacity-75 font-mono">(360×780)</span>
              </button>
            </div>
          </div>

          {/* Action Tools: Touch Lock & Full Screen */}
          <div className="flex items-center gap-2 w-full sm:w-auto justify-center sm:justify-end">
            <button
              onClick={() => setTouchEnabled(!touchEnabled)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all border ${
                touchEnabled
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                  : 'bg-amber-500/20 text-amber-300 border-amber-500/40 hover:bg-amber-500/30'
              }`}
              title={touchEnabled ? tr.lockHint : tr.touchHint}
            >
              {touchEnabled ? (
                <>
                  <Unlock className="w-3.5 h-3.5 text-emerald-400" />
                  <span>{tr.touchActive}</span>
                </>
              ) : (
                <>
                  <Lock className="w-3.5 h-3.5 text-amber-400" />
                  <span>{tr.touchLocked}</span>
                </>
              )}
            </button>

            <button
              onClick={handleReload}
              className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors"
              title={tr.reloadDemo}
              aria-label={tr.reloadDemo}
            >
              <RotateCcw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#00D4B2]' : ''}`} />
            </button>

            <a
              href={activeDemo.url}
              target="_blank"
              rel="noopener noreferrer"
              className="px-3 py-1.5 rounded-xl bg-slate-900/80 hover:bg-[#00D4B2] hover:text-[#0A192F] text-[#00D4B2] border border-[#00D4B2]/40 text-xs font-bold transition-all flex items-center gap-1.5 shadow-sm"
            >
              <span>{tr.openExternal}</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Main Grid: Device Simulator + Feature Inspection Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center max-w-6xl mx-auto">
          
          {/* Left/Right Inspection Panel on Desktop */}
          <div className="lg:col-span-5 order-2 lg:order-1 flex flex-col justify-center">
            <div className="p-6 bg-slate-800/80 border border-slate-700/80 rounded-3xl shadow-2xl backdrop-blur-md">
              
              {/* Element Header */}
              <div className="flex items-center gap-2 text-xs font-bold text-[#00D4B2] uppercase tracking-wider mb-2">
                <Sparkles className="w-4 h-4" />
                <span>
                  {isAr ? 'العنصر المختار حالياً' : 'Élément Actif en Démonstration'} ({activeDemo.number})
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-white mb-2 leading-snug">
                {isAr ? activeDemo.label.ar : activeDemo.label.fr}
              </h3>

              <p className="text-sm text-slate-300 mb-6 leading-relaxed">
                {isAr ? activeDemo.sub.ar : activeDemo.sub.fr}
              </p>

              {/* Tested Capabilities Checklist */}
              <div className="mb-6">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
                  {tr.testedFeatures}
                </h4>
                <div className="space-y-2.5">
                  {(isAr ? activeDemo.features.ar : activeDemo.features.fr).map((feat, idx) => (
                    <div
                      key={idx}
                      className="flex items-start gap-2.5 text-xs sm:text-sm text-slate-200"
                    >
                      <CheckCircle2 className="w-4 h-4 text-[#00D4B2] shrink-0 mt-0.5" />
                      <span>{feat}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Active URL & Touch Guidance Note */}
              <div className="p-3.5 bg-slate-900/90 rounded-2xl border border-slate-700/80">
                <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
                  <span className="font-mono text-[11px] truncate text-slate-300">
                    {activeDemo.url}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 font-semibold shrink-0">
                    LIVE SSL
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  {touchEnabled
                    ? isAr
                      ? '✓ اللمس مفعّل: يمكنك الضغط على الأزرار وتمرير النموذج داخل الشاشة بحرية.'
                      : '✓ Tactile activé : vous pouvez cliquer sur les boutons et faire défiler la démo.'
                    : isAr
                      ? '🔒 وضع التمرير الآمن: انقر على شاشة الهاتف في أي وقت لتفعيل اللمس والتصفح.'
                      : '🔒 Défilement sécurisé : cliquez sur l’écran pour activer la navigation tactile.'}
                </p>
              </div>

              {/* Quick direct launch */}
              <div className="mt-5 flex items-center justify-between">
                <a
                  href={activeDemo.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full inline-flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-gradient-to-r from-[#00D4B2] to-[#10B981] text-[#0A192F] font-bold text-xs sm:text-sm shadow-lg shadow-[#00D4B2]/20 hover:opacity-95 transition-all"
                >
                  <span>{isAr ? 'فتح النموذج في نافذة مستقلة كاملة' : 'Ouvrir la Démo en Plein Écran'}</span>
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>

            </div>
          </div>

          {/* Right/Center Device Mockup Frame */}
          <div className="lg:col-span-7 order-1 lg:order-2 flex flex-col items-center justify-center">
            
            {/* The Precision Smartphone Frame */}
            <div
              className={`relative mx-auto ${currentSpec.maxWidthClass} ${currentSpec.heightClass} bg-slate-900 ${currentSpec.corner} p-3.5 sm:p-4 shadow-[0_25px_60px_-15px_rgba(0,212,178,0.25)] border-[5px] sm:border-[6px] border-slate-700/90 ring-1 ring-white/20 transition-all duration-300 flex flex-col`}
              style={{
                boxShadow:
                  '0 25px 60px -15px rgba(0, 212, 178, 0.2), 0 0 0 1px rgba(255, 255, 255, 0.1), inset 0 0 12px rgba(255, 255, 255, 0.05)',
              }}
            >
              {/* Android Infinity-O Centered Punch-Hole Camera */}
              <div className="absolute top-3.5 sm:top-4 left-1/2 -translate-x-1/2 w-4 h-4 bg-black rounded-full z-40 border border-slate-700/80 shadow-inner flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-slate-900 border border-blue-900/60"></span>
              </div>

              {/* Android Status Bar: Time & Connectivity */}
              <div className="w-full flex items-center justify-between px-4 sm:px-5 pt-1 pb-2 text-[11px] font-semibold text-slate-300 z-30 select-none">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono tracking-tight font-bold text-slate-100">{currentTime}</span>
                  <span className="text-[9px] px-1 py-0.5 rounded bg-slate-800 text-slate-400 font-mono font-bold">4G+</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Signal className="w-3 h-3 text-slate-300" />
                  <span className="text-[10px] font-bold text-emerald-400 font-mono">5G</span>
                  <Wifi className="w-3 h-3 text-slate-300" />
                  <div className="flex items-center gap-0.5">
                    <span className="text-[10px] font-mono">100%</span>
                    <BatteryCharging className="w-3.5 h-3.5 text-emerald-400" />
                  </div>
                </div>
              </div>

              {/* Simulated Mobile Browser URL Bar */}
              <div className="w-full bg-slate-800/90 rounded-xl px-3 py-1.5 mb-2 flex items-center justify-between text-xs border border-slate-700/70 z-30 shadow-inner">
                <div className="flex items-center gap-1.5 overflow-hidden text-slate-300">
                  <Lock className="w-3 h-3 text-emerald-400 shrink-0" />
                  <span className="font-mono text-[10px] sm:text-[11px] truncate text-slate-200">
                    {activeDemo.url.replace('https://', '')}
                  </span>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={handleReload}
                    className="p-1 hover:text-white text-slate-400 transition-colors"
                    title={tr.reloadDemo}
                  >
                    <RotateCcw className={`w-3 h-3 ${isLoading ? 'animate-spin text-[#00D4B2]' : ''}`} />
                  </button>
                  <a
                    href={activeDemo.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1 hover:text-[#00D4B2] text-slate-400 transition-colors"
                    title={tr.openExternal}
                  >
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Inner Screen Display (Viewport) */}
              <div
                className={`relative flex-1 w-full bg-white ${currentSpec.innerCorner} overflow-hidden shadow-inner`}
              >
                {/* Loading indicator overlay */}
                {isLoading && (
                  <div className="absolute inset-0 bg-slate-900/90 backdrop-blur-xs z-20 flex flex-col items-center justify-center text-center p-4">
                    <div className="w-8 h-8 border-2 border-[#00D4B2] border-t-transparent rounded-full animate-spin mb-3"></div>
                    <p className="text-xs font-semibold text-white">
                      {isAr ? 'جاري تحميل المعاينة الحية...' : 'Chargement de la démo en direct...'}
                    </p>
                    <span className="text-[10px] text-slate-400 mt-1 font-mono">
                      {activeDemo.url}
                    </span>
                  </div>
                )}

                {/* Touch Overlay Protector (Prevents page scroll trapping on mobile) */}
                {!touchEnabled && (
                  <div
                    onClick={() => setTouchEnabled(true)}
                    className="absolute inset-0 z-10 bg-slate-950/40 hover:bg-slate-950/30 backdrop-blur-[1px] cursor-pointer flex flex-col items-center justify-center p-6 text-center transition-all group"
                  >
                    <div className="p-3.5 rounded-2xl bg-[#0F2C59]/90 border border-[#00D4B2]/40 text-white shadow-2xl group-hover:scale-110 transition-transform">
                      <MousePointerClick className="w-6 h-6 text-[#00D4B2] animate-bounce" />
                    </div>
                    <p className="mt-3 text-xs sm:text-sm font-bold text-white drop-shadow-md">
                      {isAr
                        ? 'انقر هنا لتفعيل اللمس وتجربة النموذج'
                        : 'Cliquez ici pour activer la navigation tactile'}
                    </p>
                    <span className="text-[10px] text-[#00D4B2] mt-1 font-medium bg-[#0A192F]/80 px-2.5 py-0.5 rounded-full border border-[#00D4B2]/20">
                      {isAr ? 'حماية تمرير الصفحة مفعلة' : 'Défilement de la page protégé'}
                    </span>
                  </div>
                )}

                {/* The Real Live Iframe */}
                <iframe
                  key={`${activeDemo.id}-${iframeKey}`}
                  src={activeDemo.embedUrl || activeDemo.url}
                  title={`Live Demo - ${activeDemo.label.fr}`}
                  className={`w-full h-full border-0 transition-opacity duration-300 ${
                    touchEnabled ? 'pointer-events-auto' : 'pointer-events-none'
                  }`}
                  loading="lazy"
                  onLoad={() => setIsLoading(false)}
                />

                {/* Floating Lock Toggle on bottom of screen when touch is enabled */}
                {touchEnabled && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setTouchEnabled(false);
                    }}
                    className="absolute bottom-3 right-3 z-30 px-3 py-1.5 rounded-full bg-slate-900/90 text-amber-300 text-[11px] font-bold border border-amber-400/40 shadow-lg backdrop-blur-md flex items-center gap-1 hover:bg-slate-800 transition-all"
                  >
                    <Lock className="w-3 h-3 text-amber-400" />
                    <span>{isAr ? 'قفل اللمس للمتابعة' : 'Verrouiller le tactile'}</span>
                  </button>
                )}
              </div>

              {/* Android Hardware Side Buttons: Volume rocker & Power on right edge */}
              <div className="absolute -right-2 sm:-right-2.5 top-24 w-1 sm:w-1.5 h-14 bg-slate-600 rounded-r" title="Volume Up/Down"></div>
              <div className="absolute -right-2 sm:-right-2.5 top-42 w-1 sm:w-1.5 h-9 bg-slate-600 rounded-r" title="Power"></div>

              {/* Android Navigation Gesture Pill */}
              <div className="w-28 h-1 bg-slate-400/80 rounded-full mx-auto mt-2 mb-0.5"></div>
            </div>

            {/* Bottom Caption & Verification */}
            <div className="mt-4 text-center">
              <p className="text-xs text-slate-400 flex items-center justify-center gap-1.5 flex-wrap">
                <span>{tr.inspectNote}</span>
                <span className="text-[#00D4B2] font-semibold">
                  ({currentSpec.name} • {currentSpec.dimensions})
                </span>
              </p>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
