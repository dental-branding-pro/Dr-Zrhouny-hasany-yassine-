import React, { useState } from 'react';
import { Language } from '../types';
import {
  HelpCircle,
  ChevronDown,
  ShieldCheck,
  CheckCircle2,
  Phone,
  MessageCircle,
  Sparkles,
} from 'lucide-react';

interface FAQSectionProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const FAQSection: React.FC<FAQSectionProps> = ({
  lang,
  onOpenBooking,
}) => {
  const isAr = lang === 'ar';
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleItem = (idx: number) => {
    setOpenIndex((prev) => (prev === idx ? null : idx));
  };

  const faqs = [
    {
      qFr: 'Est-ce que je paye avant ou après avoir vu le résultat final ?',
      qAr: 'هل أدفع قبل أو بعد استلام ومعاينة النتيجة النهائية للموقع ؟',
      aFr: 'Vous ne payez absolument rien à l’avance. Notre engagement est formel : notre équipe développe, configure et met en ligne l’intégralité de votre écosystème. Vous l’inspectez sur votre propre smartphone et sur PC, vous testez tous les boutons et formulaires. Vous ne réglez les 2000 DH (au lieu du prix initial de 5000 DH - offre limitée) qu’une fois pleinement satisfait.',
      aAr: 'لا تدفع أي سنتيم مسبقاً! التزامنا صارم وواضح: يقوم فريقنا التقني ببرمجة وتجهيز المنظومة كاملة، وتقوم بمعاينتها وتجربتها بنفسك على هاتفك وحاسوبك والتأكد من سرعة الموقع ونماذج الحجز. ولا يتم تحويل مبلغ 2000 درهم فقط (بدل السعر الأصلي 5000 درهم لفترة محدودة) إلا بعد رضاك التام.',
    },
    {
      qFr: 'Y a-t-il un abonnement mensuel ou annuel à payer par la suite ?',
      qAr: 'هل هناك أي اشتراك شهري أو سنوي يتوجب دفعه لاحقاً ؟',
      aFr: 'Non, 0 DH d’abonnement. Le tarif promotionnel de 2000 DH (au lieu de 5000 DH - offre limitée) est un paiement unique. L’hébergement ultra-rapide et votre nom de domaine personnalisé sont offerts et inclus sans aucun renouvellement annuel (0 DH/an). Vous n’aurez aucune facture mensuelle récurrente ni mauvaise surprise.',
      aAr: 'لا، إطلاقاً! 0 درهم اشتراك سنوي أو شهري. مبلغ 2000 درهم (السعر الأصلي 5000 درهم - عرض استثنائي لفترة محدودة) هو دفعة واحدة ونهائية بدون أي اشتراك سنوي. الاستضافة فائقة السرعة واسم النطاق مشمولان ومجانيان بدون أي مصاريف تجديد سنوية (0 درهم/سنة) وبدون أي رسوم خفية أو تكاليف غير معلنة.',
    },
    {
      qFr: 'L’écosystème respecte-t-il les règles de l’Ordre National des Médecins Dentistes du Maroc ?',
      qAr: 'هل المنظومة والموقع متوافقان مع قوانين الهيئة الوطنية لأطباء الأسنان بالمغرب ؟',
      aFr: 'Oui, à 100% et de manière rigoureuse. Nos réalisations sont conçues dans le respect absolu du Code de Déontologie Dentaire au Maroc. Le site web n’effectue aucune publicité commerciale agressive ni promotion tarifaire sur les actes médicaux. Il assure une présence d’information médicale éthique : présentation des compétences et spécialités du praticien, localisation GPS Google Maps, horaires d’accueil, numéros de garde et d’urgence, et prise de rendez-vous pour moderniser l’accueil sans enfreindre la déontologie.',
      aAr: 'نعم، 100% وبشكل صارم ومحكم. تم تطوير وهندسة المنظومة بالكامل احتراماً تاماً لميثاق أخلاقيات مهنة طب الأسنان بالمغرب (Code de Déontologie). الموقع لا يتضمن أي إشهار تجاري مستفز أو مضاربات في أسعار العلاجات الطبية، بل يقتصر على التعريف المهني العلمي بالعيادة والتخصصات، أوقات العمل، أرقام الطوارئ، التموضع الجغرافي على خرائط Google وتسهيل حجز المواعيد مع المرضى بما يحفظ هيبة ووقار الطبيب ورسالته الإنسانية النبيلة.',
    },
    {
      qFr: 'Quels sont les praticiens qui ont fait confiance à Dental Branding Pro ?',
      qAr: 'من هم الأطباء الذين وثقوا في Dental Branding Pro واستفادوا من المنظومة ؟',
      aFr: 'De nombreux praticiens de renom au Maroc nous font confiance, notamment le Dr. Omar El Haddad (Tanger - carte en direct : card-drelhaddadomar.netlify.app) et le Dr. Soumia Benammouch (Tanger - carte en direct : card-drsoumiabenaammouch.netlify.app). Ils ont modernisé leur accueil patient, automatisé les réservations WhatsApp et gagné un temps précieux chaque semaine.',
      aAr: 'وثق في منظومتنا نخبة من الأطباء المتميزين، من بينهم الدكتور عمر الحداد (طنجة - بطاقته الحية: card-drelhaddadomar.netlify.app) والدكتورة سمية بنعموش (طنجة - بطاقتها الحية: card-drsoumiabenaammouch.netlify.app). وقد ساهمت المنظومة في عصرنة استقبال مرضاهم وتوفير أكثر من 16 ساعة أسبوعياً مع راحة الدفع بعد المعاينة.',
    },
    {
      qFr: 'Quel est le délai de livraison et de mise en service garanti ?',
      qAr: 'ما هي المدة الزمنية المضمونة لتجهيز وإطلاق المنظومة بالكامل ؟',
      aFr: 'Le délai garanti est de 7 jours ouvrés à compter de la réception de vos informations (nom du cabinet, logo éventuel, ville et numéro WhatsApp). Durant ce délai, nous nous chargeons de tout de A à Z sans mobiliser votre temps.',
      aAr: 'المدة الزمنية المضمونة هي 7 أيام عمل فقط من تاريخ استلام معلومات العيادة (اسم الطبيب والعيادة، التخصص، الشعار إن وجد، المدينة ورقم الواتساب). نقوم بكل العمل التقني نيابة عنك دون هدر وقتك الطبي الثمين.',
    },
    {
      qFr: 'Comment les patients prennent-ils rendez-vous ? Où vont les messages ?',
      qAr: 'كيف يستقبل الطبيب ومساعدته حجوزات واستفسارات المرضى ؟',
      aFr: 'Toutes les interactions (demandes de consultations, urgences, pré-diagnostics interactifs) sont redirigées directement sur le numéro WhatsApp officiel de votre cabinet. Le message arrive pré-rempli avec le nom du patient, sa ville et le motif précis de son besoin.',
      aAr: 'تصل كافة طلبات الحجز والاستفسارات الطبية وحالات الطوارئ مباشرة وبشكل فوري إلى رقم الواتساب الرسمي لعيادتك. تصلك الرسالة منسقة وجاهزة بالاسم، نوع الحالة، والوقت المفضل دون أي وسيط أو تعقيد.',
    },
    {
      qFr: 'Suis-je propriétaire de mon nom de domaine et de mon site ?',
      qAr: 'هل أمتلك اسم النطاق وكافة بيانات ومحتويات الموقع ملكية تامة ؟',
      aFr: 'Oui, vous êtes propriétaire à 100% de votre nom de domaine, de votre identité et de l’ensemble des textes et banques de réponses. De plus, le nom de domaine professionnel et l’hébergement cloud ultra-rapide sont 100% gratuits et offerts (0 DH de frais de renouvellement annuel), sans aucun abonnement captif.',
      aAr: 'نعم، عيادتك هي المالك القانوني والفعلي بنسبة 100% لاسم النطاق والمنظومة وكافة المحتويات ونماذج الردود الطبية بدون أي تبعية أو شروط احتكارية. ونؤكد أن اسم النطاق المخصص (.com أو .ma) والاستضافة السحابية فائقة السرعة مشمولان ومجانيان 100% ضمن الباقة بدون أي مصاريف أو اشتراكات تجديد سنوية إطلاقاً (0 درهم/سنة).',
    },
    {
      qFr: 'Que comprend exactement l’écosystème numérique complet livré pour mon cabinet ?',
      qAr: 'ما هي المكونات الدقيقة للمنظومة الرقمية الشاملة التي تستلمها عيادتي ؟',
      aFr: 'L’écosystème comprend une solution clé en main complète : 1) Un site vitrine médical ultra-rapide (< 0.8s) conforme à l’Ordre National. 2) Une carte digitale sans contact DentaLink (NFC & QR Code). 3) Un système intelligent de prise de rendez-vous directement sur votre WhatsApp officiel. 4) Une banque de réponses types pour libérer 15h par semaine à votre secrétariat. 5) L’optimisation de votre visibilité Google Maps locale. 6) Le nom de domaine et l’hébergement cloud offerts sans frais récurrents.',
      aAr: 'تتضمن المنظومة حزمة متكاملة متناغمة لعيادتك: 1) موقع طبي تعريفي فائق السرعة (< 0.8 ثانية) متوافق تماماً مع ميثاق الهيئة الوطنية لأطباء الأسنان. 2) بطاقة التواصل الذكية DentaLink بتقنية NFC ورمز QR. 3) نظام حجز وتوجيه مواعيد المرضى مباشرة إلى واتساب العيادة الرسمي. 4) بنك الردود الطبية المنسقة مسبقاً لتوفير أكثر من 15 ساعة أسبوعياً للسكرتارية. 5) تحسين التموضع والظهور على خرائط Google لجذب مرضى منطقتك. 6) اسم نطاق واستضافة سريعة مجاناً بدون تجديد سنوي.',
    },
    {
      qFr: 'L’écosystème nécessite-t-il des compétences techniques ou un effort du secrétariat ?',
      qAr: 'هل تحتاج المنظومة إلى خبرة تقنية من الطبيب أو تدريب معقد للسكرتارية ؟',
      aFr: 'Absolument aucune compétence technique n’est requise. Aucun logiciel lourd à installer. Tout fonctionne intuitivement via l’application WhatsApp que votre assistante maîtrise déjà au quotidien : les demandes des patients arrivent claires, qualifiées et prêtes à être confirmées.',
      aAr: 'إطلاقاً! لا يتطلب الأمر أي معرفة برمجية ولا تثبيت أي برامج معقدة. المنظومة مصممة لتعمل بسلاسة فائقة عبر تطبيق WhatsApp المعتاد الذي تستخدمه السكرتارية يومياً، حيث تصل بيانات المريض واحتياجه الطبي بوضوح لتأكيد الموعد بضغطة زر.',
    },
    {
      qFr: 'Comment se passent le suivi et la maintenance technique après le lancement ?',
      qAr: 'كيف تتم المتابعة والتعديلات التقنية بعد إطلاق المنظومة ؟',
      aFr: 'L’écosystème fonctionne de manière 100% autonome et automatique ! Il repose avec une stabilité totale et une indépendance absolue sur les serveurs Google fiables et gratuits, sans nécessiter aucune intervention ni suivi technique de votre part, vous permettant de vous consacrer pleinement à votre travail médical et à vos patients en toute sérénité.',
      aAr: 'المنظومة تشتغل تلقائياً بالكامل! تعمل المنظومة باستقرار تام واستقلالية مطلقة على سيرفرات جوجل المجانية والموثوقة، دون الحاجة لأي تدخل أو متابعة تقنية من طرفكم، لتتفرغ كلياً لعملك الطبي ومرضاك بكل راحة.',
    },
  ];

  return (
    <section
      id="faq"
      className="py-16 lg:py-24 bg-white dark:bg-[#060D17] border-b border-slate-200 dark:border-slate-800 transition-colors duration-200"
    >
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-xs font-semibold text-[#0F2C59] dark:text-[#00D4B2] mb-4 shadow-xs">
            <HelpCircle className="w-3.5 h-3.5 text-[#00D4B2]" />
            <span>
              {isAr
                ? 'الأسئلة الشائعة والضمانات الرسمية'
                : 'Foire Aux Questions & Garanties'}
            </span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F2C59] dark:text-white tracking-tight mb-4">
            {isAr
              ? 'كل ما تود معرفته عن المنظومة بكل شفافية'
              : 'Tout ce que Vous Devez Savoir en Toute Transparence'}
          </h2>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            {isAr
              ? 'إجابات مباشرة وواضحة على أكثر التساؤلات التي يطرحها الأطباء قبل طلب باقة Dental Branding Pro.'
              : 'Réponses claires et directes aux questions fréquentes posées par les praticiens avant d’adopter notre écosystème.'}
          </p>

          {/* Medical Ethics Reassurance Badge */}
          <div className="mt-5 inline-flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-700/60 text-emerald-900 dark:text-emerald-300 text-xs sm:text-sm font-bold shadow-2xs">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>
              {isAr
                ? 'متوافق 100% مع ميثاق وأخلاقيات الهيئة الوطنية لأطباء الأسنان بالمغرب'
                : '100% Conforme au Code de Déontologie de l’Ordre National des Médecins Dentistes'}
            </span>
          </div>
        </div>

        {/* Accordion List */}
        <div className="space-y-4">
          {faqs.map((faq, idx) => {
            const isOpen = openIndex === idx;
            const question = isAr ? faq.qAr : faq.qFr;
            const answer = isAr ? faq.aAr : faq.aFr;

            return (
              <div
                key={idx}
                className={`rounded-2xl border transition-all duration-200 overflow-hidden ${
                  isOpen
                    ? 'border-[#00D4B2] bg-slate-50/70 dark:bg-[#0A192F] shadow-md'
                    : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-[#071324] hover:border-slate-300 dark:hover:border-slate-700'
                }`}
              >
                <button
                  onClick={() => toggleItem(idx)}
                  className="w-full py-5 px-6 sm:px-8 text-left rtl:text-right flex items-center justify-between gap-4 focus:outline-hidden"
                  aria-expanded={isOpen}
                >
                  <div className="flex items-center gap-3.5">
                    <span
                      className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 transition-colors ${
                        isOpen
                          ? 'bg-[#00D4B2] text-slate-950 font-black'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'
                      }`}
                    >
                      {idx + 1}
                    </span>
                    <span className="text-base sm:text-lg font-bold text-[#0F2C59] dark:text-white">
                      {question}
                    </span>
                  </div>

                  <ChevronDown
                    className={`w-5 h-5 text-slate-500 shrink-0 transition-transform duration-200 ${
                      isOpen ? 'transform rotate-180 text-[#00D4B2]' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 sm:px-8 pb-6 pt-1 text-sm sm:text-[15px] text-slate-600 dark:text-slate-300 leading-relaxed border-t border-slate-100 dark:border-slate-800/80">
                    <p className="pt-2">{answer}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Help & Direct Contact Card */}
        <div className="mt-12 bg-slate-50 dark:bg-[#0A192F] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 text-center sm:text-left rtl:sm:text-right">
          <div>
            <h4 className="text-lg font-bold text-[#0F2C59] dark:text-white">
              {isAr ? 'هل لديك سؤال خاص بخصوص عيادتك ؟' : 'Une question spécifique sur votre cabinet ?'}
            </h4>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {isAr
                ? 'فريقنا متاح مباشرة للإجابة على كافة استفساراتك الطبية والتقنية عبر الهاتف أو الواتساب.'
                : 'Notre équipe est à votre écoute pour échanger directement sur vos besoins cliniques.'}
            </p>
          </div>

          <div className="flex flex-col sm:flex-row items-center gap-3 w-full sm:w-auto">
            <a
              href="https://wa.me/212717516563?text=Bonjour%2C%20j%27ai%20une%20question%20concernant%20l%27offre%20Dental%20Branding%20Pro"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-2"
            >
              <MessageCircle className="w-4 h-4" />
              <span>0717516563</span>
            </a>

            <button
              onClick={onOpenBooking}
              className="w-full sm:w-auto px-4 sm:px-5 py-2.5 rounded-xl bg-[#0F2C59] dark:bg-white text-white dark:text-slate-900 font-bold text-xs shadow-md transition-colors flex items-center justify-center gap-2.5"
            >
              <div className="inline-flex items-center gap-1.5 bg-white/10 dark:bg-slate-100 px-2 py-0.5 rounded-lg shrink-0">
                <span className="text-[10px] line-through decoration-[1.5px] text-slate-300 dark:text-slate-500 font-semibold whitespace-nowrap">
                  {isAr ? '5000 درهم' : '5000 DH'}
                </span>
                <span className="text-xs font-black text-[#00D4B2] dark:text-emerald-700 font-mono whitespace-nowrap">
                  {isAr ? '2000 درهم' : '2000 DH'}
                </span>
              </div>
              <span className="whitespace-nowrap">{isAr ? 'حجز الباقة الآن' : 'Réserver Votre Pack'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
