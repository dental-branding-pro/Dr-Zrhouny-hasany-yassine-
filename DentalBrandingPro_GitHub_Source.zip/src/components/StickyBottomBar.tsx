import React from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import { MessageCircle, Zap } from 'lucide-react';

interface StickyBottomBarProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const StickyBottomBar: React.FC<StickyBottomBarProps> = ({ lang, onOpenBooking }) => {
  const strings = t[lang];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 dark:bg-[#071324]/95 backdrop-blur-md border-t border-slate-200 dark:border-slate-800 px-4 py-2.5 shadow-2xl flex items-center justify-between gap-3 transition-colors duration-200">
      {/* Price tag */}
      <div className="flex flex-col shrink-0 min-w-0">
        <div className="flex items-center gap-1.5 leading-none mb-1">
          <span className="text-[10px] text-slate-400 dark:text-slate-500 line-through decoration-[1.5px] font-semibold whitespace-nowrap">
            {lang === 'ar' ? '5000 درهم' : '5000 DH'}
          </span>
          <span className="text-base font-black font-mono text-[#0F2C59] dark:text-[#00D4B2] whitespace-nowrap">
            {strings.bottomBar.price}
          </span>
          <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 font-bold border border-amber-300/80 dark:border-amber-700/60 whitespace-nowrap">
            {lang === 'ar' ? 'لفترة محدودة' : 'Offre limitée'}
          </span>
        </div>
        <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium leading-tight whitespace-nowrap">
          {lang === 'ar' ? 'الدفع بعد المعاينة • 0 درهم/سنة' : 'Paiement après livraison • 0 DH/an'}
        </span>
      </div>

      {/* Pulsing Glowing Button */}
      <button
        onClick={onOpenBooking}
        className="flex items-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-lg animate-pulse-glow"
      >
        <MessageCircle className="w-4 h-4 fill-current" />
        <span className="whitespace-nowrap">{strings.bottomBar.cta}</span>
      </button>
    </div>
  );
};
