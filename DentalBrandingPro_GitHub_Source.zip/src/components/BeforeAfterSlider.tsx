import React, { useState } from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import {
  XCircle,
  CheckCircle2,
  Sparkles,
  AlertTriangle,
  ArrowRight,
  Zap,
  TrendingUp,
  Clock,
  ShieldCheck,
  Smartphone,
  Layers,
  Award,
  Check,
  X
} from 'lucide-react';

interface BeforeAfterSliderProps {
  lang: Language;
}

export const BeforeAfterSlider: React.FC<BeforeAfterSliderProps> = ({ lang }) => {
  const strings = t[lang];
  const isAr = lang === 'ar';

  // State to switch tabs on mobile if the user wants to inspect individual perspectives or compare side-by-side
  const [mobileView, setMobileView] = useState<'both' | 'pro' | 'traditional'>('both');

  const comparisonMetrics = [
    {
      metric: isAr ? 'سرعة فتح الموقع للجوال' : 'Vitesse mobile (PageSpeed)',
      before: isAr ? '4.8 إلى 6.2 ثوانٍ (بطيء جداً)' : '4.8 à 6.2s (très lent)',
      beforeBad: true,
      after: isAr ? '0.6 ثانية (تقييم 99/100)' : '0.6 seconde (Score 99/100)',
      afterGood: true,
      icon: Zap,
    },
    {
      metric: isAr ? 'نظام استقبال المرضى وحجز المواعيد' : 'Système de réservation & qualification',
      before: isAr ? 'مكالمات هاتفية عشوائية تشتت الطبيب' : 'Appels téléphoniques désorganisés',
      beforeBad: true,
      after: isAr ? 'تشخيص ذاتي + توجيه فوري للواتساب' : 'Diagnostic interactif + WhatsApp direct',
      afterGood: true,
      icon: Smartphone,
    },
    {
      metric: isAr ? 'تأهيل وتخفيف ضغط السكرتارية' : 'Charge de travail du secrétariat',
      before: isAr ? 'استنزاف 15h أسبوعياً في أسئلة مكررة' : '15h/semaine perdues en répétitions',
      beforeBad: true,
      after: isAr ? 'قوالب جاهزة وتوفير 60 ساعة شهرياً' : '+60h/mois libérées pour le cabinet',
      afterGood: true,
      icon: Clock,
    },
    {
      metric: isAr ? 'الاستجابة خارج أوقات العمل والعطل' : 'Disponibilité soirs, nuits & week-ends',
      before: isAr ? 'فقدان أكثر من 40% من المرضى الجدد' : 'Plus de 40% de patients perdus',
      beforeBad: true,
      after: isAr ? 'استقبال ذكي فعال 24h/24 و 7j/7' : 'Système actif 24h/24 et 7j/7 sans interruption',
      afterGood: true,
      icon: ShieldCheck,
    },
    {
      metric: isAr ? 'التكلفة والاشتراكات السنوية' : 'Coût réel & modèle d’engagement',
      before: isAr ? '800 إلى 1500 درهم شهرياً (اشتراكات متكررة مستمرة)' : '800 à 1 500 DH/mois d’abonnements récurrents',
      beforeBad: true,
      after: isAr
        ? '2000 درهم (السعر الأصلي 5000 درهم - لفترة محدودة) • 0 درهم اشتراك'
        : '2 000 DH (au lieu de 5 000 DH - Offre limitée) • 0 DH/an sans abonnement',
      afterGood: true,
      icon: Award,
    },
  ];

  const beforePoints = [
    { text: strings.comparison.before1, tag: isAr ? 'خسارة زوار' : '-53% patients' },
    { text: strings.comparison.before2, tag: isAr ? 'عدم وضوح' : 'Sans diagnostic' },
    { text: strings.comparison.before3, tag: isAr ? 'تشتيت الطاقم' : 'Stress secrétariat' },
    { text: strings.comparison.before4, tag: isAr ? 'فقدان 40%' : 'Appels perdus' },
    { text: strings.comparison.before5, tag: isAr ? 'استنزاف مالي' : 'Frais récurrents' },
  ];

  const afterPoints = [
    { text: strings.comparison.after1, tag: isAr ? 'سرعة قياسية' : '< 0.8s éclair' },
    { text: strings.comparison.after2, tag: isAr ? 'تفاعل ذكي' : '3 clics guidés' },
    { text: strings.comparison.after3, tag: isAr ? 'تنظيم فوري' : 'Fiches prêtes' },
    { text: strings.comparison.after4, tag: isAr ? 'شغال 24/7' : 'WhatsApp 24/7' },
    { text: strings.comparison.after5, tag: isAr ? '0 درهم سنوي' : '0 DH d’abonnement' },
  ];

  return (
    <section id="comparatif" className="relative py-16 lg:py-24 bg-[#050D1A] text-slate-100 overflow-hidden border-b border-white/10">
      {/* Ambient background glows */}
      <div className="absolute top-1/4 -left-48 w-96 h-96 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-1/4 -right-48 w-96 h-96 bg-[#00D4B2]/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(#ffffff08_1px,transparent_1px)] [background-size:24px_24px] pointer-events-none opacity-40" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 lg:mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-rose-500/15 via-white/5 to-[#00D4B2]/15 border border-white/10 text-xs font-bold uppercase tracking-wider mb-3">
            <span className="w-2 h-2 rounded-full bg-rose-400 animate-pulse" />
            <span className="text-slate-300">VS</span>
            <span className="w-2 h-2 rounded-full bg-[#00D4B2] animate-pulse" />
            <span className="text-slate-200 ml-1">
              {isAr ? 'مقارنة هندسية شاملة ومباشرة' : 'Audit Comparatif Haute Précision'}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-white tracking-tight mb-4">
            {strings.comparison.title}
          </h2>
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            {strings.comparison.subtitle}
          </p>

          {/* Quick Filter Switch on Mobile */}
          <div className="flex sm:hidden items-center justify-center p-1 bg-slate-900/90 border border-white/10 rounded-xl mt-6 max-w-xs mx-auto">
            <button
              onClick={() => setMobileView('both')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                mobileView === 'both'
                  ? 'bg-gradient-to-r from-slate-800 to-slate-700 text-white shadow-sm border border-white/10'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'المقارنة معاً' : 'Vue Côte-à-Côte'}
            </button>
            <button
              onClick={() => setMobileView('pro')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                mobileView === 'pro'
                  ? 'bg-gradient-to-r from-emerald-500 to-[#00D4B2] text-[#0A192F] shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'الجيل الجديد' : 'Dental Pro'}
            </button>
            <button
              onClick={() => setMobileView('traditional')}
              className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                mobileView === 'traditional'
                  ? 'bg-gradient-to-r from-rose-600 to-rose-700 text-white shadow-sm font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {isAr ? 'التقليدي' : 'Traditionnel'}
            </button>
          </div>
        </div>

        {/* TOP DUAL CARDS: Direct Side-By-Side Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8 items-stretch mb-12">
          
          {/* 1. LEFT CARD: Le Modèle Traditionnel (Before / Inefficace) */}
          <div
            className={`relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-[#13101C]/90 via-[#120B14]/90 to-[#0B060C]/95 border border-rose-500/25 shadow-xl transition-all duration-300 hover:border-rose-500/40 flex flex-col justify-between ${
              mobileView === 'pro' ? 'hidden sm:flex' : 'flex'
            }`}
          >
            {/* Ambient Red glow badge */}
            <div className="absolute top-0 right-0 w-44 h-44 bg-rose-600/10 rounded-full blur-3xl pointer-events-none" />

            <div>
              {/* Header Badge */}
              <div className="flex items-center justify-between gap-2 mb-5">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-rose-500/15 border border-rose-500/30 text-rose-300 text-xs font-bold uppercase tracking-wider">
                  <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  <span>{strings.comparison.beforeTitle}</span>
                </div>
                <span className="text-[11px] font-semibold text-rose-400/90 bg-rose-950/60 border border-rose-800/40 px-2.5 py-1 rounded-md">
                  {isAr ? '⚠️ نموذج قديم مكلف' : '⚠️ Modèle Obsolète'}
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-white mb-2 leading-tight">
                {isAr ? 'ضغط يومي متكرر، بطء، وفقدان مستمر لمرضى جدد' : 'Stress Quotidien, Lenteurs & Patients Perdus'}
              </h3>
              <p className="text-xs sm:text-sm text-rose-200/70 mb-6">
                {isAr
                  ? 'المواقع التقليدية لا تجيب على أسئلة المريض، ولا تقدم حلولاً تفاعلية، وتكلف عيادتك آلاف الدراهم سنوياً بلا عائد حقيقي.'
                  : 'Un site inerte ne rassure pas le patient, sature votre secrétariat d’appels inutiles et génère des frais mensuels continus.'}
              </p>

              {/* Point-by-point pain list */}
              <ul className="space-y-3.5 mb-6">
                {beforePoints.map((pt, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-3 p-3 rounded-xl bg-rose-950/20 border border-rose-900/30 text-xs sm:text-sm text-slate-300 transition-all hover:bg-rose-950/30"
                  >
                    <div className="w-5 h-5 rounded-full bg-rose-500/20 border border-rose-500/40 text-rose-400 flex items-center justify-center shrink-0 mt-0.5">
                      <X className="w-3.5 h-3.5 stroke-[2.5]" />
                    </div>
                    <div className="flex-1">
                      <span className="text-rose-100/90 leading-snug block">{pt.text}</span>
                    </div>
                    <span className="text-[10px] font-bold text-rose-400 bg-rose-900/40 border border-rose-700/30 px-2 py-0.5 rounded shrink-0">
                      {pt.tag}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Bottom summary pill */}
            <div className="pt-4 border-t border-rose-500/15 flex items-center justify-between text-xs text-rose-300/80">
              <span className="flex items-center gap-1.5 font-medium">
                <AlertTriangle className="w-4 h-4 text-rose-400" />
                {isAr ? 'النتيجة: استنزاف للوقت والمال' : 'Bilan : Charge mentale & perte de patients'}
              </span>
              <span className="font-bold text-rose-400">
                {isAr ? '-40% كفاءة' : 'Inefficace'}
              </span>
            </div>
          </div>

          {/* 2. RIGHT CARD: Dental Branding Pro (After / Haute Performance) */}
          <div
            className={`relative rounded-3xl p-6 sm:p-8 bg-gradient-to-b from-[#0B1A30]/95 via-[#081528]/95 to-[#050D1A]/98 border-2 border-[#00D4B2]/40 shadow-2xl transition-all duration-300 hover:border-[#00D4B2]/70 flex flex-col justify-between ${
              mobileView === 'traditional' ? 'hidden sm:flex' : 'flex'
            }`}
          >
            {/* Ambient Cyan glow badge */}
            <div className="absolute top-0 right-0 w-56 h-56 bg-[#00D4B2]/15 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -top-3.5 right-6 px-3.5 py-1 rounded-full bg-gradient-to-r from-amber-400 via-emerald-400 to-[#00D4B2] text-[#0A192F] text-[11px] font-black uppercase tracking-wider shadow-lg flex items-center gap-1">
              <Sparkles className="w-3 h-3 fill-current" />
              <span>{isAr ? 'المنظومة المعتمدة 2026' : 'STANDARD RECOMMANDÉ'}</span>
            </div>

            <div>
              {/* Header Badge */}
              <div className="flex items-center justify-between gap-2 mb-5">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/20 border border-emerald-400/40 text-emerald-300 text-xs font-bold uppercase tracking-wider">
                  <CheckCircle2 className="w-4 h-4 text-[#00D4B2] shrink-0" />
                  <span>{strings.comparison.afterTitle}</span>
                </div>
                <span className="text-[11px] font-bold text-emerald-300 bg-emerald-950/60 border border-emerald-500/30 px-2.5 py-1 rounded-md flex items-center gap-1">
                  <Zap className="w-3 h-3 text-[#00D4B2]" />
                  <span>{isAr ? 'سرعة < 0.8s' : '< 0.8s Éclair'}</span>
                </span>
              </div>

              <h3 className="text-xl sm:text-2xl font-black text-white mb-2 leading-tight">
                {isAr ? 'عيادة متطورة، سريعة، ومنظمة 100% بنظام متكامل' : 'Cabinet Moderne, Fluide & 100% Connecté'}
              </h3>
              <p className="text-xs sm:text-sm text-cyan-100/70 mb-6">
                {isAr
                  ? 'منظومة تجمع بين سرعة خرافية، فحص أولي تفاعلي للأعراض، حفظ فوري لمعلومات العيادة، وتوفير حقيقي لأكثر من 60 ساعة شهرياً.'
                  : 'Un écosystème intelligent qui qualifie chaque patient, élimine le temps perdu au secrétariat et valorise l’image d’excellence de votre cabinet.'}
              </p>

              {/* Point-by-point advantage list */}
              <ul className="space-y-3.5 mb-6">
                {afterPoints.map((pt, idx) => (
                  <li
                    key={idx}
                    className="flex items-start gap-3 p-3 rounded-xl bg-[#0F2848]/40 border border-[#00D4B2]/20 text-xs sm:text-sm text-slate-100 transition-all hover:bg-[#0F2848]/70 hover:border-[#00D4B2]/40"
                  >
                    <div className="w-5 h-5 rounded-full bg-emerald-500/20 border border-[#00D4B2]/50 text-[#00D4B2] flex items-center justify-center shrink-0 mt-0.5">
                      <Check className="w-3.5 h-3.5 stroke-[3]" />
                    </div>
                    <div className="flex-1">
                      <span className="text-white font-medium leading-snug block">{pt.text}</span>
                    </div>
                    <span className="text-[10px] font-bold text-[#00D4B2] bg-emerald-950/80 border border-emerald-500/30 px-2 py-0.5 rounded shrink-0">
                      {pt.tag}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Bottom summary pill */}
            <div className="pt-4 border-t border-[#00D4B2]/20 flex items-center justify-between text-xs text-emerald-300">
              <span className="flex items-center gap-1.5 font-bold">
                <TrendingUp className="w-4 h-4 text-[#00D4B2]" />
                {isAr ? 'النتيجة: تحويل المرضى وتوفير 60 ساعة شهرياً' : 'Bilan : +15h libérées/semaine & Conversion maximale'}
              </span>
              <span className="font-extrabold text-[#00D4B2] text-sm">
                {isAr ? 'امتياز 10/10' : '99/100'}
              </span>
            </div>
          </div>

        </div>

        {/* COMPARATIVE METRICS MATRIX (Clear, High-Tech Table) */}
        <div className="rounded-3xl bg-[#0A1628]/90 border border-white/10 p-5 sm:p-8 backdrop-blur-xl shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-white/10">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00D4B2] to-sky-400 p-[1.5px] flex items-center justify-center shadow-md">
                <div className="w-full h-full bg-[#071322] rounded-[10px] flex items-center justify-center text-[#00D4B2]">
                  <Layers className="w-5 h-5" />
                </div>
              </div>
              <div>
                <h4 className="text-base sm:text-lg font-bold text-white">
                  {isAr ? 'جدول التدقيق الفني المقارن' : 'Matrice Comparative Détaillée'}
                </h4>
                <p className="text-xs text-slate-400">
                  {isAr ? 'مقارنة المعايير الجوهرية بالأرقام والنتائج' : 'Indicateurs clés de performance et rentabilité'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold">
              <div className="flex items-center gap-1.5 text-rose-400">
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <span>{isAr ? 'التقليدي' : 'Site Classique'}</span>
              </div>
              <div className="flex items-center gap-1.5 text-[#00D4B2]">
                <span className="w-2.5 h-2.5 rounded-full bg-[#00D4B2]" />
                <span>Dental Branding Pro</span>
              </div>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead>
                <tr className="border-b border-white/5 text-slate-400 text-[11px] uppercase tracking-wider">
                  <th className={`py-3 px-3 sm:px-4 ${isAr ? 'text-right' : 'text-left'}`}>
                    {isAr ? 'المعيار' : 'Critère'}
                  </th>
                  <th className={`py-3 px-3 sm:px-4 text-rose-400/90 ${isAr ? 'text-right' : 'text-left'}`}>
                    {isAr ? 'الموقع التقليدي' : 'Site Web Classique'}
                  </th>
                  <th className={`py-3 px-3 sm:px-4 text-[#00D4B2] ${isAr ? 'text-right' : 'text-left'}`}>
                    Dental Branding Pro
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {comparisonMetrics.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                      <td className={`py-4 px-3 sm:px-4 font-medium text-white ${isAr ? 'text-right' : 'text-left'}`}>
                        <div className={`flex items-center gap-2.5 ${isAr ? 'flex-row-reverse justify-end' : ''}`}>
                          <div className="w-7 h-7 rounded-lg bg-slate-800/80 border border-white/10 flex items-center justify-center text-slate-300 shrink-0">
                            <Icon className="w-3.5 h-3.5" />
                          </div>
                          <span>{item.metric}</span>
                        </div>
                      </td>
                      <td className={`py-4 px-3 sm:px-4 text-slate-400 ${isAr ? 'text-right' : 'text-left'}`}>
                        <div className={`inline-flex items-center gap-1.5 text-rose-300/90 ${isAr ? 'flex-row-reverse' : ''}`}>
                          <XCircle className="w-4 h-4 text-rose-400 shrink-0" />
                          <span>{item.before}</span>
                        </div>
                      </td>
                      <td className={`py-4 px-3 sm:px-4 font-semibold text-emerald-300 ${isAr ? 'text-right' : 'text-left'}`}>
                        <div className={`inline-flex items-center gap-1.5 text-[#00D4B2] ${isAr ? 'flex-row-reverse' : ''}`}>
                          <CheckCircle2 className="w-4 h-4 text-[#00D4B2] shrink-0" />
                          <span>{item.after}</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* Quick CTA strip inside comparison */}
          <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-start">
              <span className="text-xs text-slate-400 block">
                {isAr ? 'الترقية إلى المنظومة المتطورة:' : 'Passez au standard d’excellence :'}
              </span>
              <span className="text-sm font-bold text-white flex items-center gap-2 flex-wrap">
                <span>{isAr ? 'عرض متكامل:' : 'Pack Complet :'}</span>
                <span className="text-slate-400 line-through decoration-[1.5px] text-xs font-semibold whitespace-nowrap">
                  {isAr ? '5000 درهم' : '5000 DH'}
                </span>
                <span className="text-[#00D4B2] font-black whitespace-nowrap">
                  {isAr ? '2000 درهم فقط' : '2000 DH'}
                </span>
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 font-bold whitespace-nowrap">
                  {isAr ? 'لفترة محدودة' : 'Offre limitée'}
                </span>
                <span className="text-slate-400 text-xs whitespace-nowrap">
                  {isAr ? '• بدون أي اشتراك سنوي' : '• 0 DH/an'}
                </span>
              </span>
            </div>

            <a
              href="#tarifs"
              className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-amber-400 via-emerald-400 to-[#00D4B2] text-[#0A192F] font-bold text-xs uppercase tracking-wider shadow-lg hover:shadow-cyan-500/25 transition-all hover:scale-[1.02] shrink-0"
            >
              <span className="text-[11px] line-through decoration-[1.5px] decoration-slate-800 text-slate-800/80 font-bold whitespace-nowrap">
                {isAr ? '5000 درهم' : '5000 DH'}
              </span>
              <span className="whitespace-nowrap">
                {isAr ? 'طلب تفعيل العيادة (2000 درهم - لفترة محدودة)' : 'Commander (2000 DH - Offre limitée)'}
              </span>
              <ArrowRight className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
            </a>
          </div>

        </div>

      </div>
    </section>
  );
};
