import React from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import { X, Zap, CheckCircle2, MessageCircle, ArrowRight, ShieldCheck } from 'lucide-react';

interface QuickModeDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onOpenBooking: () => void;
}

export const QuickModeDrawer: React.FC<QuickModeDrawerProps> = ({
  isOpen,
  onClose,
  lang,
  onOpenBooking,
}) => {
  const strings = t[lang];
  const isAr = lang === 'ar';

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs transition-opacity"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="relative w-full max-w-md h-full bg-white dark:bg-slate-900 shadow-2xl flex flex-col justify-between overflow-y-auto animate-in slide-in-from-right duration-300 transition-colors">
        
        {/* Drawer Header */}
        <div className="p-6 bg-[#0F2C59] dark:bg-slate-800 text-white border-b border-white/10 dark:border-slate-700">
          <div className="flex items-center justify-between mb-3">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-[#0F2C59] text-xs font-black uppercase tracking-wider">
              <Zap className="w-3.5 h-3.5 fill-current" />
              <span>{isAr ? 'ملخص تنفيذي (60 ثانية)' : 'Synthèse 60 Secondes'}</span>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <h3 className="text-xl font-extrabold tracking-tight">
            {strings.quickModeDrawer.title}
          </h3>
          <p className="text-xs text-slate-300 mt-1">
            {strings.quickModeDrawer.subtitle}
          </p>
        </div>

        {/* 5 Bullet Points */}
        <div className="p-6 space-y-4 text-xs sm:text-sm text-slate-700 dark:text-slate-300 flex-1">
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60">
            <p className="font-semibold text-slate-900 dark:text-white">{strings.quickModeDrawer.point1}</p>
          </div>
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60">
            <p className="font-semibold text-slate-900 dark:text-white">{strings.quickModeDrawer.point2}</p>
          </div>
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60">
            <p className="font-semibold text-slate-900 dark:text-white">{strings.quickModeDrawer.point3}</p>
          </div>
          <div className="p-3.5 bg-slate-50 dark:bg-slate-800/60 rounded-xl border border-slate-200 dark:border-slate-700/60">
            <p className="font-semibold text-slate-900 dark:text-white">{strings.quickModeDrawer.point4}</p>
          </div>
          <div className="p-3.5 bg-teal-50 dark:bg-teal-950/40 rounded-xl border border-[#00D4B2]/40 dark:border-[#00D4B2]/30">
            <p className="font-bold text-teal-950 dark:text-teal-200">{strings.quickModeDrawer.point5}</p>
          </div>
        </div>

        {/* Drawer Action */}
        <div className="p-6 bg-slate-50 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 space-y-3">
          <button
            onClick={() => {
              onClose();
              onOpenBooking();
            }}
            className="w-full py-3.5 px-4 bg-[#0F2C59] dark:bg-[#00D4B2] hover:bg-[#163a73] dark:hover:bg-[#10B981] text-white dark:text-[#0A192F] rounded-xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-colors"
          >
            <span>{strings.quickModeDrawer.cta}</span>
            <ArrowRight className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
          </button>

          <a
            href="https://wa.me/212717516563?text=Bonjour%20Dental%20Branding%20Pro%2C%20j'ai%20lu%20le%20r%C3%A9sum%C3%A9%2060s%20et%20je%20souhaite%20lancer%20mon%20cabinet%20pour%202000%20DH."
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{isAr ? 'واتساب مباشر (0717516563)' : 'WhatsApp Direct (0717516563)'}</span>
          </a>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>{isAr ? 'الدفع بعد التسليم والمعاينة الكاملة' : 'Paiement après livraison & inspection garantie'}</span>
          </div>
        </div>

      </div>
    </div>
  );
};
