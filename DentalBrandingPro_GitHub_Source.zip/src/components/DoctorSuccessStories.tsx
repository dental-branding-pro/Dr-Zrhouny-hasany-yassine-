import React, { useState, useEffect, useRef } from 'react';
import { Language } from '../types';
import {
  Star,
  CheckCircle2,
  Clock,
  ShieldCheck,
  Stethoscope,
  Quote,
  ArrowRight,
  MapPin,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  Pause,
  Play,
  UserCheck,
  Award,
  ExternalLink,
  Globe,
} from 'lucide-react';
import drOmarImg from '../assets/images/dr_omar_portrait_1791390540104.jpg';
import drSoumiaImg from '../assets/images/dr_soumia_portrait_1791390580642.jpg';

interface DoctorSuccessStoriesProps {
  lang: Language;
  onOpenBooking: () => void;
}

interface DoctorItem {
  id: string;
  name: string;
  city: string;
  badge: string;
  tagColor: string;
  avatarBg: string;
  initials: string;
  photo: string;
  liveUrl?: string;
  liveUrlLabel?: string;
  stats: { label: string; value: string }[];
  quote: string;
  deliverables: string[];
}

export const DoctorSuccessStories: React.FC<DoctorSuccessStoriesProps> = ({
  lang,
  onOpenBooking,
}) => {
  const isAr = lang === 'ar';
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const touchStartX = useRef<number | null>(null);
  const touchEndX = useRef<number | null>(null);

  const doctors: DoctorItem[] = [
    {
      id: 'dr-omar',
      name: isAr ? 'الدكتور عمر الحداد' : 'Dr. Omar El Haddad',
      city: isAr ? 'طنجة' : 'Tanger',
      badge: isAr ? 'عيادة معتمدة • حصل على الحزمة' : 'Cabinet Vérifié • Pack Activé',
      tagColor: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
      avatarBg: 'from-blue-600 to-cyan-600',
      initials: 'OH',
      photo: drOmarImg,
      liveUrl: 'https://card-drelhaddadomar.netlify.app/',
      liveUrlLabel: isAr ? 'معاينة البطاقة الذكية الحية للدكتور عمر الحداد' : 'Voir la carte digitale en direct du Dr. Omar El Haddad',
      stats: [
        {
          label: isAr ? 'ساعات موفرة أسبوعياً' : 'Temps gagné / semaine',
          value: '16h',
        },
        {
          label: isAr ? 'سرعة فتح الموقع' : 'Vitesse de chargement',
          value: '< 0.7s',
        },
        {
          label: isAr ? 'تقييم المنظومة' : 'Satisfaction globale',
          value: '5.0 / 5',
        },
      ],
      quote: isAr
        ? '« كانت مسؤولة الاستقبال تستنزف معظم وقتها في الرد على نفس المكالمات والأسئلة المكررة حول المواعيد والخدمات. بفضل Dental Branding Pro، أصبح المرضى يجدون كل المعلومات بوضوح ويحجزون مواعيدهم مباشرة عبر الواتساب في ثوانٍ. والموقع فائق السرعة بشكل لا يقارن، والأهم هو راحة الدفع بعد المعاينة والتسليم. »'
        : '« Mon secrétariat perdait un temps précieux à répondre aux mêmes questions téléphoniques sur les tarifs et les prises de rendez-vous. Grâce à Dental Branding Pro, les patients accèdent directement aux informations et réservent sur WhatsApp en quelques clics. La vitesse est fulgurante et le paiement après livraison m’a apporté une sérénité totale. »',
      deliverables: isAr
        ? [
            'بطاقة ذكية تفاعلية DentaLink حية ومفعلة (card-drelhaddadomar.netlify.app)',
            'موقع فائق السرعة مخصص للعيادة بهوية احترافية',
            'نماذج ردود واتساب للاستفسارات وحجز المواعيد',
            'دومين واستضافة سريعة مجانية بدون أي اشتراك',
          ]
        : [
            'Carte DentaLink interactive en direct (card-drelhaddadomar.netlify.app)',
            'Site web clinique ultra-rapide (< 0.7s) avec identité sur-mesure',
            'Banque de réponses WhatsApp pour prises de rendez-vous',
            'Domaine & Hébergement offerts (0 DH/an de renouvellement)',
          ],
    },
    {
      id: 'dr-soumia',
      name: isAr ? 'الدكتورة سمية بنعموش' : 'Dr. Soumia Benammouch',
      city: isAr ? 'طنجة' : 'Tanger',
      badge: isAr ? 'عيادة معتمدة • حصلت على الحزمة' : 'Cabinet Vérifié • Pack Activé',
      tagColor: 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 border-emerald-500/20',
      avatarBg: 'from-rose-600 to-indigo-600',
      initials: 'SB',
      photo: drSoumiaImg,
      liveUrl: 'https://card-drsoumiabenaammouch.netlify.app/',
      liveUrlLabel: isAr ? 'معاينة البطاقة الذكية الحية للدكتورة سمية' : 'Voir la carte digitale en direct du Dr. Soumia',
      stats: [
        {
          label: isAr ? 'جاهزية الاستقبال' : 'Disponibilité patients',
          value: '24h/7j',
        },
        {
          label: isAr ? 'مؤشر جوجل للجوال' : 'Google PageSpeed',
          value: '99 / 100',
        },
        {
          label: isAr ? 'اشتراك سنوي' : 'Abonnement récurrent',
          value: '0 DH',
        },
      ],
      quote: isAr
        ? '« سرعة التواصل والوضوح وتجربة المريض تمثل أولوية قصوى لعيادتنا. Dental Branding Pro منح عيادتنا حضوراً رقمياً راقياً جداً، ورمز QR على بطاقة الزيارة سهل على مراجعينا تسجيل رقم العيادة والوصول عبر خرائط Google فوراً. باقة متكاملة بـ 2000 درهم لمرة واحدة هي استثمار ممتاز لأي عيادة. »'
        : '« La réactivité et l’expérience patient sont capitales pour notre cabinet. Dental Branding Pro a doté notre clinique d’une présence numérique moderne et prestigieuse. Le QR code imprimable permet aux patients d’enregistrer nos coordonnées en 1 seconde. Une solution clé en main à 2000 DH remarquable. »',
      deliverables: isAr
        ? [
            'بطاقة ذكية تفاعلية DentaLink حية ومفعلة (card-drsoumiabenaammouch.netlify.app)',
            'واجهة راقية بتصميم متميز يعكس جودة العيادة',
            'رمز QR ذكي للبطاقات الورقية لحفظ الاتصال فوراً',
            'إدارة سمعة العيادة ونماذج الرد على تقييمات Google',
          ]
        : [
            'Carte DentaLink interactive en direct (card-drsoumiabenaammouch.netlify.app)',
            'Interface moderne et épurée valorisant la clinique',
            'QR code HD pour cartes de visite physiques',
            'Banque de réponses aux avis Google Maps',
          ],
    },
  ];

  // Auto-slide effect
  useEffect(() => {
    if (!isPlaying) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % doctors.length);
    }, 6500);
    return () => clearInterval(interval);
  }, [isPlaying, doctors.length]);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + doctors.length) % doctors.length);
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % doctors.length);
  };

  // Touch Swipe Handlers for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.targetTouches[0].clientX;
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    touchEndX.current = e.targetTouches[0].clientX;
  };

  const handleTouchEnd = () => {
    if (!touchStartX.current || !touchEndX.current) return;
    const diff = touchStartX.current - touchEndX.current;
    // In RTL, swipe direction is inverted
    const threshold = 50;
    if (isAr) {
      if (diff > threshold) {
        handlePrev();
      } else if (diff < -threshold) {
        handleNext();
      }
    } else {
      if (diff > threshold) {
        handleNext();
      } else if (diff < -threshold) {
        handlePrev();
      }
    }
    touchStartX.current = null;
    touchEndX.current = null;
  };

  const currentDoctor = doctors[currentIndex];

  return (
    <section
      id="medecins"
      className="py-16 lg:py-24 bg-gradient-to-b from-white via-slate-50/60 to-white dark:from-[#060D17] dark:via-[#0a172a] dark:to-[#060D17] border-b border-slate-200 dark:border-slate-800 transition-colors duration-200 overflow-hidden"
    >
      <div className="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-50 dark:bg-blue-950/50 border border-blue-200 dark:border-blue-800 text-xs font-semibold text-[#0F2C59] dark:text-[#00D4B2] mb-4 shadow-xs">
            <Stethoscope className="w-3.5 h-3.5 text-[#00D4B2]" />
            <span>
              {isAr
                ? 'ثقة متبادلة وتجارب نجاح حقيقية'
                : 'Témoignages & Études de Cas'}
            </span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F2C59] dark:text-white tracking-tight mb-4">
            {isAr
              ? 'أطباء وثقوا في Dental Branding Pro'
              : 'Praticiens qui ont fait confiance à Dental Branding Pro'}
          </h2>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            {isAr
              ? 'انضم إلى نخبة الأطباء الذين اختاروا Dental Branding Pro لتطوير الحضور الرقمي لعياداتهم بـ 2000 درهم فقط لمرة واحدة والدفع بعد المعاينة.'
              : 'Découvrez les témoignages de confrères ayant modernisé leur présence numérique avec Dental Branding Pro à 2000 DH avec paiement après livraison.'}
          </p>
        </div>

        {/* Doctor Quick Selector Tabs (Click to jump directly to any doctor) */}
        <div className="flex items-center justify-center gap-2.5 sm:gap-4 mb-8 flex-wrap">
          {doctors.map((doc, idx) => {
            const isActive = currentIndex === idx;
            return (
              <button
                key={doc.id}
                onClick={() => setCurrentIndex(idx)}
                className={`inline-flex items-center gap-2.5 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl text-xs sm:text-sm font-bold transition-all shadow-xs ${
                  isActive
                    ? 'bg-[#0F2C59] dark:bg-[#00D4B2] text-white dark:text-slate-950 shadow-md scale-105 border-2 border-[#00D4B2]'
                    : 'bg-white dark:bg-slate-800/80 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-[#00D4B2]'
                }`}
              >
                <img
                  src={doc.photo}
                  alt={doc.name}
                  className="w-6 h-6 sm:w-7 sm:h-7 rounded-full object-cover object-top ring-2 ring-emerald-500/60 shrink-0"
                />
                <span>{doc.name}</span>
                <span className="text-[11px] opacity-80 font-normal">({doc.city})</span>
                {doc.liveUrl && (
                  <span className="inline-flex items-center gap-1 text-[10px] px-1.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 font-extrabold border border-emerald-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    <span>Live</span>
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Slider Card Container */}
        <div
          className="relative"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onMouseEnter={() => setIsPlaying(false)}
          onMouseLeave={() => setIsPlaying(true)}
        >
          {/* Main Slide Card */}
          <div className="relative bg-white dark:bg-[#0A192F] rounded-2xl border-2 border-[#00D4B2]/40 dark:border-[#00D4B2]/40 shadow-2xl overflow-hidden transition-all duration-300">
            {/* Top Accent Gradient Bar */}
            <div className="h-2 w-full bg-gradient-to-r from-[#00D4B2] via-blue-500 to-indigo-600" />

            <div className="p-6 sm:p-8 lg:p-10">
              {/* Doctor Profile Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-6 border-b border-slate-100 dark:border-slate-800/80">
                <div className="flex items-center gap-4">
                  {/* Photo with verified badge */}
                  <div className="relative shrink-0">
                    <img
                      src={currentDoctor.photo}
                      alt={currentDoctor.name}
                      className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl object-cover object-top shadow-lg border-2 border-[#00D4B2]/60 ring-4 ring-emerald-500/10"
                    />
                    <div className="absolute -bottom-1.5 -right-1.5 w-6 h-6 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-md border-2 border-white dark:border-[#0A192F]">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <h3 className="text-2xl sm:text-3xl font-extrabold text-[#0F2C59] dark:text-white">
                        {currentDoctor.name}
                      </h3>
                    </div>
                    <div className="flex items-center gap-3 flex-wrap mt-1">
                      <p className="text-sm sm:text-base font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                        <MapPin className="w-4 h-4 text-[#00D4B2]" />
                        <span>{currentDoctor.city}</span>
                      </p>
                      {currentDoctor.liveUrl && (
                        <a
                          href={currentDoctor.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-700 dark:text-[#00D4B2] border border-emerald-500/30 text-xs font-bold transition-all shadow-2xs group"
                          title={isAr ? 'فتح البطاقة الرقمية التفاعلية الحية' : 'Ouvrir la carte interactive en direct'}
                        >
                          <span className="relative flex h-2 w-2">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                          </span>
                          <Globe className="w-3.5 h-3.5" />
                          <span>{isAr ? 'بطاقة DentaLink الحية أونلاين' : 'Carte DentaLink live'}</span>
                          <ExternalLink className="w-3 h-3 group-hover:translate-x-0.5 transition-transform" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>

                {/* Verified Badge */}
                <div
                  className={`inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold border shrink-0 self-start shadow-2xs ${currentDoctor.tagColor}`}
                >
                  <CheckCircle2 className="w-4 h-4 text-emerald-500" />
                  <span>{currentDoctor.badge}</span>
                </div>
              </div>

              {/* Quote Box */}
              <div className="my-6 sm:my-8 relative bg-slate-50 dark:bg-slate-900/70 rounded-2xl p-5 sm:p-7 border border-slate-100 dark:border-slate-800 shadow-inner">
                <Quote className="w-8 h-8 text-[#00D4B2]/40 mb-2" />
                <p className="text-base sm:text-lg text-slate-700 dark:text-slate-200 leading-relaxed italic">
                  {currentDoctor.quote}
                </p>
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-5 pt-4 border-t border-slate-200/60 dark:border-slate-800">
                  <div className="flex items-center gap-3">
                    <img
                      src={currentDoctor.photo}
                      alt={currentDoctor.name}
                      className="w-11 h-11 rounded-xl object-cover object-top ring-2 ring-[#00D4B2] shadow-sm shrink-0"
                    />
                    <div>
                      <div className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                        <span>{currentDoctor.name}</span>
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                      </div>
                      <div className="text-[11px] sm:text-xs text-slate-500 dark:text-slate-400">
                        {currentDoctor.city} • {isAr ? 'طبيب أسنان جراح' : 'Chirurgien-Dentiste'}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 text-amber-400 shrink-0">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                    ))}
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300 mx-1">
                      5.0 / 5.0
                    </span>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                      {isAr ? 'تعليق موثق' : 'Avis vérifié'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Live Delivered Project Showcase (Dr. Soumia's DentaLink Card) */}
              {currentDoctor.liveUrl && (
                <div className="my-6 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/5 to-cyan-500/10 dark:from-emerald-950/40 dark:via-slate-900/60 dark:to-teal-950/40 border-2 border-emerald-500/30 dark:border-emerald-500/40 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                  <div className="flex items-start sm:items-center gap-3.5">
                    <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 to-[#00D4B2] text-slate-950 flex items-center justify-center shadow-md shadow-emerald-500/20 shrink-0">
                      <Globe className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 dark:text-[#00D4B2]">
                          {isAr ? 'النموذج الفعلي المنجز أونلاين' : 'Exemple Réel en Ligne'}
                        </span>
                        <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500 text-white shadow-2xs">
                          <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />
                          {isAr ? 'مباشر وتفاعلي' : 'Live & Interactif'}
                        </span>
                      </div>
                      <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white mt-0.5">
                        {isAr
                          ? `البطاقة الرقمية التفاعلية (DentaLink) لـ ${currentDoctor.name}`
                          : `Carte Digitale Interactive DentaLink du ${currentDoctor.name}`}
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 font-mono mt-0.5 break-all">
                        {currentDoctor.liveUrl.replace(/^https?:\/\//, '').replace(/\/$/, '')}
                      </p>
                    </div>
                  </div>

                  <a
                    href={currentDoctor.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-[#00D4B2] hover:bg-[#00bf9e] text-slate-950 text-xs sm:text-sm font-black shadow-md hover:shadow-lg transition-all transform hover:-translate-y-0.5 active:scale-95 shrink-0 group"
                  >
                    <span>{isAr ? 'معاينة وتجربة البطاقة الحية' : 'Tester la carte en direct'}</span>
                    <ExternalLink className="w-4 h-4 group-hover:translate-x-0.5 transition-transform" />
                  </a>
                </div>
              )}

              {/* KPI Metrics */}
              <div className="grid grid-cols-3 gap-2 sm:gap-4 py-5 border-y border-slate-100 dark:border-slate-800/80 my-4 text-center">
                {currentDoctor.stats.map((s, idx) => (
                  <div
                    key={idx}
                    className="bg-slate-50/80 dark:bg-slate-900/50 p-3 sm:p-4 rounded-xl border border-slate-200/60 dark:border-slate-800 shadow-2xs"
                  >
                    <div className="text-xl sm:text-2xl font-black text-[#0F2C59] dark:text-[#00D4B2]">
                      {s.value}
                    </div>
                    <div className="text-xs text-slate-500 dark:text-slate-400 mt-1 leading-tight font-medium">
                      {s.label}
                    </div>
                  </div>
                ))}
              </div>

              {/* Deliverables checklist */}
              <div className="mt-6">
                <p className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-3">
                  {isAr ? 'عناصر الحزمة المفعلة للعيادة :' : 'Éléments activés pour le cabinet :'}
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300">
                  {currentDoctor.deliverables.map((item, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-[#00D4B2] shrink-0" />
                      <span>{item}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Footer action bar */}
            <div className="px-6 sm:px-10 py-4 bg-slate-50 dark:bg-slate-900/90 border-t border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="flex items-center gap-3 flex-wrap">
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  <span>{isAr ? 'ضمان التسليم والمعاينة قبل الدفع' : 'Paiement après réception & test'}</span>
                </span>
                {currentDoctor.liveUrl && (
                  <a
                    href={currentDoctor.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-[#00D4B2] hover:underline"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>{isAr ? `معاينة بطاقة ${currentDoctor.name}` : `Carte ${currentDoctor.name}`}</span>
                  </a>
                )}
              </div>
              <button
                onClick={onOpenBooking}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-[#0F2C59] dark:bg-[#00D4B2] text-white dark:text-slate-950 font-bold text-xs shadow-md transition-all flex items-center justify-center gap-2 hover:opacity-95"
              >
                <span>{isAr ? 'احجز باقة مماثلة لعيادتك' : 'Commander le même pack'}</span>
                <ArrowRight className={`w-3.5 h-3.5 ${isAr ? 'rotate-180' : ''}`} />
              </button>
            </div>
          </div>

          {/* Slider Controls (Next / Prev Arrows) */}
          <div className="flex items-center justify-between mt-6">
            {/* Prev Button */}
            <button
              onClick={handlePrev}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-[#00D4B2] hover:text-[#00D4B2] shadow-sm transition-all text-xs font-bold"
              aria-label={isAr ? 'السابق' : 'Précédent'}
            >
              <ChevronRight className={`w-4 h-4 ${isAr ? '' : 'rotate-180'}`} />
              <span>{isAr ? 'السابق' : 'Précédent'}</span>
            </button>

            {/* Slider Dots & Counter */}
            <div className="flex items-center gap-2">
              {doctors.map((_, dotIdx) => (
                <button
                  key={dotIdx}
                  onClick={() => setCurrentIndex(dotIdx)}
                  className={`h-2.5 rounded-full transition-all duration-300 ${
                    currentIndex === dotIdx
                      ? 'w-8 bg-[#00D4B2]'
                      : 'w-2.5 bg-slate-300 dark:bg-slate-700 hover:bg-slate-400'
                  }`}
                  aria-label={`Slide ${dotIdx + 1}`}
                />
              ))}

              <span className="text-xs font-bold text-slate-500 dark:text-slate-400 ml-2">
                {currentIndex + 1} / {doctors.length}
              </span>
            </div>

            {/* Next Button */}
            <button
              onClick={handleNext}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-[#00D4B2] hover:text-[#00D4B2] shadow-sm transition-all text-xs font-bold"
              aria-label={isAr ? 'التالي' : 'Suivant'}
            >
              <span>{isAr ? 'التالي' : 'Suivant'}</span>
              <ChevronLeft className={`w-4 h-4 ${isAr ? '' : 'rotate-180'}`} />
            </button>
          </div>
        </div>

        {/* Bottom Trust Banner */}
        <div className="mt-12 bg-gradient-to-r from-blue-900 to-[#0F2C59] rounded-2xl p-6 sm:p-8 text-white shadow-xl flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center sm:text-left rtl:sm:text-right">
            <div className="w-12 h-12 rounded-xl bg-[#00D4B2]/20 border border-[#00D4B2]/40 flex items-center justify-center shrink-0">
              <ShieldCheck className="w-6 h-6 text-[#00D4B2]" />
            </div>
            <div>
              <h4 className="text-lg font-bold">
                {isAr
                  ? 'منظومة احترافية كاملة بدون أي مخاطرة مالية'
                  : 'Une solution clé en main complète sans aucun risque'}
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 leading-relaxed">
                {isAr ? (
                  <>
                    نقوم ببرمجة وتجهيز كامل المنظومة لعيادتك. تعاين وتجرب كل شيء قبل دفع{' '}
                    <span className="font-bold text-white">2000 درهم فقط</span> بدلاً من{' '}
                    <span className="text-[11px] line-through decoration-[1.5px] decoration-slate-400 text-slate-400 font-semibold whitespace-nowrap">
                      5000 درهم
                    </span>{' '}
                    <span className="text-amber-300 font-bold">(عرض لفترة محدودة)</span>. 0 درهم اشتراك سنوي.
                  </>
                ) : (
                  <>
                    Nous configurons l’intégralité de l’écosystème. Vous inspectez et validez avant de régler{' '}
                    <span className="font-bold text-white">2000 DH</span> au lieu de{' '}
                    <span className="text-[11px] line-through decoration-[1.5px] decoration-slate-400 text-slate-400 font-semibold whitespace-nowrap">
                      5000 DH
                    </span>{' '}
                    <span className="text-amber-300 font-bold">(Offre limitée)</span>. 0 DH d’abonnement.
                  </>
                )}
              </p>
            </div>
          </div>

          <button
            onClick={onOpenBooking}
            className="w-full sm:w-auto px-5 sm:px-6 py-3 rounded-xl bg-[#00D4B2] hover:bg-[#00bf9e] text-slate-950 font-bold text-sm shadow-lg transition-all transform hover:-translate-y-0.5 shrink-0 flex items-center justify-center gap-2.5"
          >
            <div className="inline-flex items-center gap-1.5 bg-slate-950/10 px-2.5 py-0.5 rounded-lg shrink-0">
              <span className="text-[10px] line-through decoration-[1.5px] decoration-slate-800 text-slate-700 font-bold whitespace-nowrap">
                {isAr ? '5000 درهم' : '5000 DH'}
              </span>
              <span className="text-xs font-black text-slate-950 font-mono whitespace-nowrap">
                {isAr ? '2000 درهم' : '2000 DH'}
              </span>
            </div>
            <span className="whitespace-nowrap font-extrabold">
              {isAr ? 'طلب الباقة الآن' : 'Commander le Pack'}
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-950/10 text-slate-900 font-bold whitespace-nowrap hidden min-[400px]:inline-block">
              {isAr ? 'لفترة محدودة' : 'Offre limitée'}
            </span>
          </button>
        </div>
      </div>
    </section>
  );
};
