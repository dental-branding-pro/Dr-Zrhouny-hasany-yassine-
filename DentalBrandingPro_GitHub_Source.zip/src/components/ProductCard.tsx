import React from 'react';
import { Language, ModalContent } from '../types';
import { t } from '../data/translations';
import {
  ExternalLink,
  ChevronRight,
  Layers,
  Globe,
  FileText,
  CreditCard,
  BookMarked,
  Sparkles,
  CheckCircle2,
} from 'lucide-react';
import websiteMockupImg from '../assets/images/website_speed_mockup_1791390638302.jpg';
import whatsappMockupImg from '../assets/images/whatsapp_automation_mockup_1791390653683.jpg';
import dentalinkCardImg from '../assets/images/dentalink_nfc_card_1791390597291.jpg';
import heroClinicImg from '../assets/images/hero_dental_clinic_1791240928954.jpg';

interface ProductCardProps {
  lang: Language;
  onOpenModal: (content: ModalContent) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({ lang, onOpenModal }) => {
  const strings = t[lang];
  const isAr = lang === 'ar';

  const products = [
    {
      num: '01',
      title: isAr ? 'موقع فائق السرعة وتشخيص ذاتي تفاعلي' : 'Site Web Ultra-Rapide & Diagnostic Dentaire Interactif',
      demoUrl: 'https://centre-dentaire-yasmile.netlify.app/',
      icon: <Globe className="w-5 h-5 text-[#00D4B2]" />,
      image: websiteMockupImg,
      badge: isAr ? 'سرعة < 0.8 ثانية • PageSpeed 99' : 'Vitesse < 0.8s • PageSpeed 99',
      desc: isAr
        ? 'موقع يحمل في أقل من 0.8 ثانية مع نظام تشخيص ذاتي تفاعلي يحدد احتياجات المريض ويربطه فوراً بواتساب العيادة.'
        : 'Chargement éclair (< 0.8s) avec outil d’auto-évaluation guidé : vos patients ciblent leur besoin clinique et réservent directement sur WhatsApp.',
      items: [
        {
          label: isAr ? '⭐ التشخيص الذاتي التفاعلي وتأهيل الحالة' : '⭐ Diagnostic Dentaire Interactif (Auto-évaluation)',
          action: () =>
            onOpenModal({
              id: 'diag',
              title: isAr ? 'أداة التشخيص الذاتي التفاعلي وتأهيل الحالة' : 'Diagnostic Dentaire Interactif & Auto-évaluation',
              type: 'diagnostic',
            }),
        },
        {
          label: isAr ? 'حجز موعد فوري ومؤهل عبر الواتساب' : 'Prise de RDV WhatsApp Directe (Motif Pré-qualifié)',
          action: () =>
            onOpenModal({
              id: 'booking',
              title: isAr ? 'حجز موعد مباشر عبر الواتساب' : 'Prise de RDV Directe sur WhatsApp',
              type: 'whatsapp_booking',
            }),
        },
      ],
    },
    {
      num: '02',
      title: isAr ? 'المدونة الطبية للسيو وبنوك الردود الذكية' : 'Blog Médical SEO & Banques de Réponses',
      demoUrl: 'https://yasmile-blog.netlify.app/',
      icon: <FileText className="w-5 h-5 text-blue-500" />,
      image: whatsappMockupImg,
      badge: isAr ? 'توفير 15 ساعة أسبوعياً' : 'Gain 15h / semaine',
      desc: isAr
        ? 'وفر 15 ساعة عمل أسبوعياً لطاقم الاستقبال: ردود واتساب جاهزة، نماذج الرد على تقييمات Google، ومقالات سيو مفصلة لمدينتك.'
        : 'Gagnez 15h de travail par semaine : réponses WhatsApp prêtes à l’emploi, modèles d’avis Google et articles référencés pour votre ville.',
      items: [
        {
          label: isAr ? 'بنك نماذج ردود واتساب للاستقبال' : 'Banque de Réponses WhatsApp',
          action: () =>
            onOpenModal({
              id: 'resp_wa',
              title: isAr ? 'بنك ردود واتساب لمسؤولة الاستقبال' : 'Banque de Réponses WhatsApp Secrétariat',
              type: 'whatsapp_responses',
            }),
        },
        {
          label: isAr ? 'نماذج الرد على تقييمات Google Maps' : 'Banque de Réponses aux Avis Google',
          action: () =>
            onOpenModal({
              id: 'resp_google',
              title: isAr ? 'نماذج الردود الاحترافية على تقييمات Google' : 'Modèles de Réponses aux Avis Patients Google',
              type: 'google_reviews',
            }),
        },
        {
          label: isAr ? 'مقالات سيو طبية متصدرة لمدينتك' : 'Articles SEO Spécifiques à votre Ville',
          action: () =>
            onOpenModal({
              id: 'seo_art',
              title: isAr ? 'مقالات سيو طبية متصدرة محلياً' : 'Articles SEO Dentaires Référencés Localement',
              type: 'seo_articles',
            }),
        },
        {
          label: isAr ? 'محرك الأسئلة الشائعة المؤتمت' : 'Moteur FAQ Automatisé',
          action: () =>
            onOpenModal({
              id: 'faq_eng',
              title: isAr ? 'محرك الأسئلة الشائعة للمرضى' : 'Moteur FAQ Questions Fréquentes Patients',
              type: 'faq_engine',
            }),
        },
      ],
    },
    {
      num: '03',
      title: isAr ? 'البطاقة الذكية DentaLink ورمز الـ QR' : 'Carte Bio Intelligente & QR Code (DentaLink)',
      demoUrl: 'https://yasmile-bio.netlify.app/',
      icon: <CreditCard className="w-5 h-5 text-emerald-500" />,
      image: dentalinkCardImg,
      badge: isAr ? 'تقنية NFC و QR فائق الدقة' : 'NFC & QR Code HD Imprimable',
      desc: isAr
        ? 'رابط موحد واحترافي لصفحة إنستغرام وتيك توك، مرفوقاً برمز QR فائق الدقة مخصص لبطاقات الزيارة الورقية ومكتب الاستقبال.'
        : 'Le lien unique et moderne à placer sur Instagram et TikTok, couplé à un QR code haute définition pour vos cartes de visite papier.',
      items: [
        {
          label: isAr ? 'زر حجز الموعد الفوري' : 'Bouton Rendez-vous',
          action: () =>
            onOpenModal({
              id: 'rdv',
              title: isAr ? 'زر حجز المواعيد DentaLink' : 'Bouton Prise de RDV DentaLink',
              type: 'whatsapp_booking',
            }),
        },
        {
          label: isAr ? 'زر الاتصال في حالات الطوارئ 24/7' : 'Bouton Appels Urgence',
          action: () =>
            onOpenModal({
              id: 'urg',
              title: isAr ? 'زر اتصال الطوارئ 24/7' : 'Bouton Appel Urgence 24/7',
              type: 'whatsapp_booking',
            }),
        },
        {
          label: isAr ? 'زر حفظ جهة الاتصال في الهاتف (vCard)' : 'Bouton vCard / Enregistrer Contact',
          action: () =>
            onOpenModal({
              id: 'vcf',
              title: isAr ? 'حفظ بطاقة جهة الاتصال (vCard)' : 'Enregistrement de la Fiche Contact (vCard)',
              type: 'vcard',
            }),
        },
        {
          label: isAr ? 'زر المسار الجغرافي على Google Maps' : 'Bouton Google Maps',
          action: () =>
            onOpenModal({
              id: 'gmaps',
              title: isAr ? 'المسار الفوري على خرائط Google' : 'Itinéraire Immédiat Google Maps',
              type: 'maps_itinerary',
            }),
        },
        {
          label: isAr ? 'زر تصفح الموقع والمدونة' : 'Bouton Site & Blog',
          action: () => {
            const link = document.createElement('a');
            link.href = 'https://centre-dentaire-yasmile.netlify.app/';
            link.target = '_blank';
            link.rel = 'noopener noreferrer';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
          },
        },
        {
          label: isAr ? 'رمز QR عالي الدقة للبطاقات الورقية' : 'QR Code HD Imprimable pour Carte Visite Papier',
          action: () =>
            onOpenModal({
              id: 'qr',
              title: isAr ? 'رمز QR عالي الدقة للطباعة' : 'QR Code HD Imprimable pour Comptoir & Cartes',
              type: 'qr_code',
            }),
        },
      ],
    },
    {
      num: '04',
      title: isAr ? 'الدليل التشغيلي وبنوك المحتوى الترويجي' : 'Guide Opérationnel & Banques de Contenu',
      demoUrl: 'https://yasmile-guide.netlify.app/',
      icon: <BookMarked className="w-5 h-5 text-purple-500" />,
      image: heroClinicImg,
      badge: isAr ? 'صدارة Google Maps لمدينتك' : 'Top 3 Google Maps Assuré',
      desc: isAr
        ? 'المنهجية العملية لتصدر المراتب الثلاث الأولى على Google Maps، خطة محتوى إنستغرام لـ 52 أسبوعاً، وسيناريو تدريب الاستقبال.'
        : 'La méthode concrète pour dominer le Top 3 Google Maps localement, alimenter Instagram pendant 52 semaines et former votre secrétaire.',
      items: [
        {
          label: isAr ? 'بنك محتوى إنستغرام لـ 52 أسبوعاً' : 'Banque Instagram 52 Semaines',
          action: () =>
            onOpenModal({
              id: 'insta',
              title: isAr ? 'جدول محتوى إنستغرام (52 أسبوعاً)' : 'Calendrier Editorial Instagram (52 Semaines)',
              type: 'instagram_bank',
            }),
        },
        {
          label: isAr ? 'منشورات دورية لحساب Google Business' : 'Banque Publications Google Maps',
          action: () =>
            onOpenModal({
              id: 'gposts',
              title: isAr ? 'منشورات جاهزة لملف Google Business' : 'Publications Régulières pour Google Business Profile',
              type: 'google_posts',
            }),
        },
        {
          label: isAr ? 'دليل تصدر المراتب الـ 3 الأولى في Google Maps' : 'Guide Référencement Google Maps Top 3',
          action: () =>
            onOpenModal({
              id: 'gtop3',
              title: isAr ? 'استراتيجية تصدر المراتب الـ 3 الأولى' : 'Stratégie pour Dominer le Top 3 Google Maps',
              type: 'maps_top3_guide',
            }),
        },
        {
          label: isAr ? 'سيناريوهات تدريب مسؤولة الاستقبال' : 'Scénarios pour Secrétaire Médicale',
          action: () =>
            onOpenModal({
              id: 'sec',
              title: isAr ? 'سيناريوهات الرد الهاتفي للاستقبال' : 'Scripts Téléphoniques pour Secrétaire Médicale',
              type: 'secretary_script',
            }),
        },
      ],
    },
  ];

  return (
    <section id="produits" className="py-16 lg:py-24 bg-[#F8FAFC] dark:bg-[#060D17] border-b border-slate-200 dark:border-slate-800 transition-colors duration-200">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-900 text-[#0F2C59] dark:text-[#00D4B2] text-xs font-bold uppercase tracking-wider mb-3">
            <Layers className="w-3.5 h-3.5 text-[#00D4B2]" />
            <span>{isAr ? 'المنظومة المتكاملة 360°' : 'Architecture Complète 360°'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-[#0F2C59] dark:text-white tracking-tight mb-3">
            {strings.products.title}
          </h2>
          <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300">
            {strings.products.subtitle}
          </p>
        </div>

        {/* 4 Products Bento Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
          {products.map((prod) => (
            <div
              key={prod.num}
              className="bg-white dark:bg-slate-900/90 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-xs hover:border-[#00D4B2] dark:hover:border-[#00D4B2] transition-all hover:shadow-xl flex flex-col justify-between group"
            >
              {/* Product Visual Image Banner */}
              <div className="relative h-44 sm:h-52 w-full overflow-hidden bg-slate-950 border-b border-slate-100 dark:border-slate-800">
                <img
                  src={prod.image}
                  alt={prod.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 opacity-90 group-hover:opacity-100"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/20 to-transparent" />
                
                {/* Floating pill badges on image */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <span className="font-mono text-xs font-extrabold text-white bg-slate-900/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/20">
                    {isAr ? `الركن ${prod.num}` : `Pilier ${prod.num}`}
                  </span>
                  
                  <span className="inline-flex items-center gap-1.5 text-xs font-bold text-slate-950 bg-[#00D4B2] px-2.5 py-1 rounded-lg shadow-sm">
                    <Sparkles className="w-3 h-3" />
                    <span>{prod.badge}</span>
                  </span>
                </div>

                {/* Quick launch link at bottom right of image */}
                <div className="absolute bottom-3 right-3">
                  <a
                    href={prod.demoUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-white bg-slate-900/90 hover:bg-[#00D4B2] hover:text-slate-950 backdrop-blur-md px-3 py-1.5 rounded-lg border border-white/20 transition-all shadow-md"
                  >
                    <span>{isAr ? 'معاينة تجريبية حية' : 'Démo Réelle'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>

              {/* Card Body */}
              <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-center gap-2.5 mb-2">
                    <div className="w-8 h-8 rounded-lg bg-teal-50 dark:bg-slate-800 text-[#00D4B2] flex items-center justify-center shrink-0">
                      {prod.icon}
                    </div>
                    <h3 className="text-lg sm:text-xl font-bold text-[#0F2C59] dark:text-white">
                      {prod.title}
                    </h3>
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    {prod.desc}
                  </p>

                  {/* Interactive Clickable List with Micro-Modals */}
                  <div className="space-y-2 mb-6">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {isAr
                        ? 'أدوات ونوافذ تفاعلية مشمولة (اضغط للتجربة) :'
                        : 'Outils & Micro-Modales Inclus (Cliquez pour tester) :'}
                    </div>
                    {prod.items.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={item.action}
                        className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-teal-50/60 dark:hover:bg-slate-800 border border-slate-200/80 dark:border-slate-700/60 hover:border-[#00D4B2] dark:hover:border-[#00D4B2] text-xs font-semibold text-slate-800 dark:text-slate-200 hover:text-[#0F2C59] dark:hover:text-[#00D4B2] transition-all group/item text-start"
                      >
                        <span className="flex items-center gap-2 truncate">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#00D4B2] shrink-0"></span>
                          <span className="truncate">{item.label}</span>
                        </span>
                        <ChevronRight className={`w-3.5 h-3.5 text-slate-400 group-hover/item:text-[#00D4B2] transition-all shrink-0 ml-1 ${isAr ? 'rotate-180 group-hover/item:-translate-x-0.5' : 'group-hover/item:translate-x-0.5'}`} />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Card Footer */}
                <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs gap-2">
                  <div className="flex items-center gap-1.5 flex-wrap">
                    <span className="text-slate-500 dark:text-slate-400 font-medium">
                      {isAr ? 'مشمول في الباقة:' : 'Inclus :'}
                    </span>
                    <span className="text-slate-400 line-through decoration-[1.5px] text-[10px] font-semibold whitespace-nowrap">
                      {isAr ? '5000 درهم' : '5000 DH'}
                    </span>
                    <span className="font-bold text-[#0F2C59] dark:text-[#00D4B2] whitespace-nowrap">
                      {isAr ? '2000 درهم' : '2000 DH'}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/70 text-amber-800 dark:text-amber-300 font-bold border border-amber-300/80 dark:border-amber-700/60 whitespace-nowrap">
                      {isAr ? 'لفترة محدودة' : 'Offre limitée'}
                    </span>
                  </div>
                  <span className="font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-1 shrink-0">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>{isAr ? 'جاهز في 7 أيام' : 'Prêt en 7 jours'}</span>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};
