import React from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import {
  ShieldCheck,
  ArrowRight,
  Sparkles,
  Clock,
  Globe2,
  Search,
  Bot,
  CreditCard,
  Globe,
  Ban,
  Radio,
  Rocket,
  Stethoscope,
  QrCode,
  Lock,
  Zap,
} from 'lucide-react';
import heroDoctorImg from '../assets/images/hero_doctor_clinic_1791393662146.jpg';

interface HeroProps {
  lang: Language;
  onOpenBooking: () => void;
  onExploreDemo: () => void;
}

const getFeatureIcon = (iconKey?: string) => {
  switch (iconKey) {
    case 'price':
      return CreditCard;
    case 'shield':
      return ShieldCheck;
    case 'globe':
      return Globe;
    case 'ban':
      return Ban;
    case 'clock24':
      return Radio;
    case 'rocket':
      return Rocket;
    case 'search':
      return Search;
    case 'bot':
      return Bot;
    case 'stethoscope':
      return Stethoscope;
    case 'qr':
      return QrCode;
    case 'time':
    default:
      return Clock;
  }
};

export const Hero: React.FC<HeroProps> = ({ lang, onOpenBooking, onExploreDemo }) => {
  const strings = t[lang];

  return (
    <section className="relative overflow-hidden pt-8 pb-14 sm:pt-12 sm:pb-20 border-b border-slate-200/80 bg-gradient-to-b from-[#F0FDF9]/40 via-white to-[#F8FAFC]">
      {/* Background Subtle Medical Radial Highlights */}
      <div className="absolute top-0 right-1/4 w-96 h-96 bg-[#00D4B2]/5 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute top-1/3 left-0 w-80 h-80 bg-[#0F2C59]/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
          
          {/* Left Column: Proposition & Guarantees */}
          <div className="lg:col-span-7 flex flex-col items-start text-start">
            
            {/* Clean category kicker with medical badge */}
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#00D4B2]/10 border border-[#00D4B2]/25 text-xs font-bold text-[#008f77] mb-4 shadow-2xs">
              <span className="inline-block w-2 h-2 rounded-full bg-[#00D4B2] animate-pulse"></span>
              <span>{lang === 'ar' ? 'المنظومة الرقمية الشاملة لجراحي وأطباء الأسنان' : 'Solution Clef en Main pour Chirurgiens-Dentistes'}</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-[#0F2C59] tracking-tight leading-[1.18] mb-4 text-balance">
              {strings.hero.title}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-slate-600 leading-relaxed mb-6 max-w-2xl font-normal">
              {strings.hero.subtitle}
            </p>

            {/* Primary Action Buttons */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 w-full sm:w-auto mb-5">
              <button
                onClick={onOpenBooking}
                className="w-full sm:w-auto px-4 sm:px-6 py-3.5 text-white bg-gradient-to-r from-[#0F2C59] via-[#14396f] to-[#0F2C59] hover:from-[#14396f] hover:to-[#1a4a8f] rounded-2xl shadow-xl shadow-[#0F2C59]/25 transition-all duration-200 transform hover:-translate-y-0.5 active:scale-95 group border border-white/10 flex items-center justify-center gap-2 sm:gap-3"
              >
                {/* Structured Inset Pricing Badge */}
                <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white/10 border border-white/10 shrink-0">
                  <span className="text-[10px] sm:text-[11px] line-through decoration-[1.5px] text-slate-300 font-semibold whitespace-nowrap">
                    {lang === 'ar' ? '5000 درهم' : '5000 DH'}
                  </span>
                  <span className="text-xs sm:text-sm font-black text-[#00D4B2] font-mono whitespace-nowrap">
                    {lang === 'ar' ? '2000 درهم' : '2000 DH'}
                  </span>
                </div>

                {/* Primary CTA Title */}
                <span className="text-xs sm:text-sm md:text-base font-extrabold text-white tracking-tight whitespace-nowrap">
                  {lang === 'ar' ? 'احجز باقتك الآن' : 'Réserver Votre Pack'}
                </span>

                {/* Limited Offer Tag */}
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/30 font-bold whitespace-nowrap hidden min-[390px]:inline-block">
                  {lang === 'ar' ? 'لفترة محدودة' : 'Offre limitée'}
                </span>

                {/* Arrow Icon */}
                <ArrowRight className={`w-4 h-4 text-[#00D4B2] group-hover:translate-x-1 transition-transform shrink-0 ${lang === 'ar' ? 'rotate-180 group-hover:-translate-x-1' : ''}`} />
              </button>

              <button
                onClick={onExploreDemo}
                className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm sm:text-base font-bold text-[#0F2C59] bg-white hover:bg-slate-50 border border-slate-200 hover:border-[#0F2C59]/30 rounded-2xl shadow-xs transition-colors w-full sm:w-auto"
              >
                <span>{strings.hero.ctaSecondary}</span>
              </button>
            </div>

            {/* Subtle pricing footnote */}
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-600 mb-8 bg-emerald-50/80 px-3.5 py-2 rounded-lg border border-emerald-200/60 flex-wrap">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <div className="flex items-center gap-1.5 flex-wrap">
                <span className="text-[11px] text-slate-400 line-through decoration-[1.5px] font-semibold whitespace-nowrap">
                  {lang === 'ar' ? '5000 درهم' : '5000 DH'}
                </span>
                <span className="text-xs font-black text-emerald-700 whitespace-nowrap">
                  {lang === 'ar' ? '2000 درهم فقط' : '2000 DH'}
                </span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold border border-amber-300 whitespace-nowrap">
                  {lang === 'ar' ? 'لفترة محدودة' : 'Offre limitée'}
                </span>
                <span className="text-slate-400">•</span>
                <span>{lang === 'ar' ? 'الدفع بعد المعاينة • 0 درهم اشتراك سنوي' : 'Paiement après livraison • 0 DH d’abonnement'}</span>
              </div>
            </div>

            {/* Guarantee Badges / Trust Pillars - Elegant Medical Luxury Palette */}
            <div className="w-full grid grid-cols-1 min-[480px]:grid-cols-2 gap-2.5 sm:gap-3.5 pt-6 border-t border-slate-200/80">
              {strings.guarantees.map((g: any, idx: number) => {
                const is60Hours = g.label.includes('60');
                const IconComp = getFeatureIcon(g.iconKey);

                return (
                  <div
                    key={idx}
                    className={`${
                      is60Hours ? 'col-span-full' : ''
                    } p-3.5 sm:p-4 rounded-xl sm:rounded-2xl border border-slate-200/90 bg-white/90 hover:bg-white shadow-[0_2px_8px_-2px_rgba(15,44,89,0.06)] hover:shadow-[0_8px_20px_-4px_rgba(15,44,89,0.12)] hover:border-[#0F2C59]/30 transition-all duration-300 flex items-center justify-between gap-3 group relative overflow-hidden`}
                  >
                    {/* Subtle top indicator accent on hover */}
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-[#00D4B2] to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                    <div className="flex items-center gap-3 min-w-0 flex-1">
                      {/* Styled Icon Container - Medical Green / Emerald Theme to match site icons */}
                      <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-emerald-50 border border-emerald-200/80 text-emerald-600 flex items-center justify-center shrink-0 shadow-2xs group-hover:bg-emerald-600 group-hover:text-white group-hover:border-emerald-600 transition-all duration-200">
                        <IconComp className="w-5 h-5 transition-transform group-hover:scale-110 text-emerald-600 group-hover:text-white" />
                      </div>

                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="text-sm sm:text-[15px] font-extrabold text-[#0F2C59] leading-tight tracking-tight">
                            {g.label}
                          </span>
                          {g.badge && (
                            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/80 group-hover:bg-[#00D4B2]/20 group-hover:text-emerald-800 group-hover:border-[#00D4B2]/40 transition-colors shrink-0">
                              {g.badge}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 group-hover:text-slate-600 leading-snug mt-0.5">
                          {g.sub}
                        </p>
                      </div>
                    </div>

                    <Sparkles className="w-4 h-4 text-[#00D4B2] shrink-0 opacity-40 group-hover:opacity-100 transition-opacity hidden sm:block" />
                  </div>
                );
              })}
            </div>

            {/* Medical Ethics Compliance Bar */}
            <div className="mt-4 flex items-center justify-center sm:justify-start gap-2 text-xs font-semibold text-slate-600 bg-slate-100/90 py-2 px-3.5 rounded-xl border border-slate-200">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                {lang === 'ar'
                  ? 'ميثاق مهني معتمد • متوافق 100% مع أخلاقيات الهيئة الوطنية لأطباء الأسنان بالمغرب'
                  : 'Charte Médicale • 100% Conforme à la Déontologie de l’Ordre National des Médecins Dentistes'}
              </span>
            </div>

          </div>

          {/* Right Column: Hero Visual Showcase */}
          <div className="lg:col-span-5 relative">
            <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-slate-900 group">
              <img
                src={heroDoctorImg}
                alt={lang === 'ar' ? 'طبيب أسنان في عيادة رقمية عصرية' : 'Chirurgien-Dentiste dans son Cabinet Digitalisé'}
                className="w-full h-[380px] sm:h-[440px] object-cover object-top transition-transform duration-700 group-hover:scale-105"
                referrerPolicy="no-referrer"
              />
              
              {/* Overlay Gradient */}
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A192F]/90 via-[#0A192F]/20 to-transparent"></div>

              {/* Top Doctor Status Badge */}
              <div className="absolute top-3.5 left-3.5 px-3 py-1.5 rounded-full bg-slate-950/75 backdrop-blur-md border border-white/15 text-white flex items-center gap-2 shadow-lg">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="text-xs font-bold text-slate-100">
                  {lang === 'ar' ? 'طبيب أسنان رقمي • جاهز 24/7' : 'Chirurgien-Dentiste 100% Digitalisé'}
                </span>
              </div>

              {/* Float Glass card on top of image */}
              <div className="absolute bottom-4 left-4 right-4 p-4 rounded-xl glass-panel-dark text-white border border-white/10 shadow-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-[#00D4B2] animate-ping"></span>
                    <span className="text-xs font-semibold uppercase tracking-wider text-[#00D4B2]">
                      {lang === 'ar' ? 'عيادة متصلة 24/7' : 'Cabinet Connecté 24/7'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-300 line-through decoration-[1.5px] font-semibold whitespace-nowrap">
                      {lang === 'ar' ? '5000 درهم' : '5000 DH'}
                    </span>
                    <span className="text-xs font-mono font-bold text-emerald-400 whitespace-nowrap">
                      {lang === 'ar' ? '2000 درهم' : '2000 DH TTC'}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-400/25 text-amber-300 border border-amber-400/40 font-bold whitespace-nowrap">
                      {lang === 'ar' ? 'لفترة محدودة' : 'Offre limitée'}
                    </span>
                  </div>
                </div>
                <p className="text-xs text-slate-200 leading-relaxed">
                  {lang === 'ar'
                    ? 'حجز مواعيد فوري، محاكي ميزانية وضمان ظهور متصدر في Google Maps من أول يوم.'
                    : 'Prise de rendez-vous directe, simulateur de budget et visibilité Google Maps garantis dès la mise en ligne.'}
                </p>
              </div>
            </div>
          </div>

        </div>

        {/* Technical Trust & Performance Certification Ribbon */}
        <div className="mt-12 pt-8 border-t border-slate-200/80">
          <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-8 text-xs font-semibold text-slate-600">
            <div className="flex items-center gap-2">
              <Zap className="w-4 h-4 text-[#008f77]" />
              <span>{lang === 'ar' ? 'سرعة فائقة < 0.8 ثانية (Google 99/100)' : 'Google PageSpeed 99/100 (< 0.8s)'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'ar' ? 'تشفير آمن SSL 256-bit معتمد' : 'Sécurité SSL 256-Bit & HTTPS'}</span>
            </div>
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600" />
              <span>{lang === 'ar' ? 'استضافة سحابية عالية الأداء 24/7' : 'Cloud CDN Haute Disponibilité 24/7'}</span>
            </div>
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>{lang === 'ar' ? 'ضمان الدفع بعد المعاينة الكاملة' : 'Paiement Après Livraison & Validation'}</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
};
