import React from 'react';
import { Language } from '../types';
import { Phone, Mail, ShieldCheck, MapPin, Clock, Heart } from 'lucide-react';

interface FooterProps {
  lang: Language;
}

export const Footer: React.FC<FooterProps> = ({ lang }) => {
  const isAr = lang === 'ar';

  return (
    <footer className="bg-[#0F2C59] text-white pt-14 pb-20 md:pb-12 border-t border-slate-800">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-8 pb-10 border-b border-white/10">
          
          {/* Brand Info */}
          <div className="md:col-span-5">
            <div className="text-xl font-bold tracking-tight text-white flex items-center gap-3.5 mb-3">
              {/* Harmonious Architectural Bezel matching Header */}
              <div className="relative shrink-0">
                <div className="w-11 h-11 rounded-full p-[2px] bg-gradient-to-tr from-[#0F2C59] via-[#D4AF37] to-[#00D4B2] shadow-md shadow-[#0F2C59]/40 flex items-center justify-center">
                  <div className="w-full h-full rounded-full bg-[#0A192F] p-0.5 overflow-hidden flex items-center justify-center border border-white/20 shadow-inner">
                    <img
                      src="/images/dental-branding-logo.webp"
                      alt="Dental Branding Pro Official Emblem"
                      width={44}
                      height={44}
                      className="w-full h-full object-contain rounded-full"
                    />
                  </div>
                </div>
                <span className="absolute -bottom-0.5 -end-0.5 w-3 h-3 rounded-full bg-gradient-to-tr from-amber-400 to-amber-300 border-2 border-[#0F2C59] shadow-xs"></span>
              </div>

              <div className="flex items-center gap-2">
                <span className="font-black text-lg sm:text-xl text-white">Dental Branding</span>
                <span className="text-[10px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-gradient-to-r from-amber-500/20 via-[#00D4B2]/20 to-emerald-500/20 text-[#00D4B2] border border-[#00D4B2]/40 font-mono">
                  PRO
                </span>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed max-w-sm mb-4">
              {isAr
                ? 'المنظومة الرقمية الشاملة المخصصة لأطباء وجراحي الأسنان في المغرب: موقع تفاعلي، مدونة سيو طبية، بطاقة ذكية DentaLink ودليل تشغيلي متكامل.'
                : 'L’écosystème numérique tout-en-un réservé aux cabinets et centres de chirurgie dentaire : site interactif, blog médical SEO, carte bio DentaLink & guide opérationnel.'}
            </p>
            <div className="flex items-center gap-2 flex-wrap text-xs font-mono">
              <span className="text-slate-400 line-through decoration-[1.5px] text-[10px] font-semibold whitespace-nowrap">
                {isAr ? '5000 درهم' : '5000 DH'}
              </span>
              <span className="text-[#00D4B2] font-black">
                {isAr ? '2000 درهم شاملة' : '2000 DH TTC'}
              </span>
              <span className="text-[10px] bg-amber-400/20 text-amber-300 border border-amber-400/40 px-1.5 py-0.5 rounded font-bold">
                {isAr ? 'لفترة محدودة' : 'Offre limitée'}
              </span>
              <span className="text-slate-400 font-sans text-[11px]">
                {isAr ? '• الدفع بعد المعاينة • 0 درهم/سنة' : '• Paiement après livraison • 0 DH/an'}
              </span>
            </div>
          </div>

          {/* Contact Direct */}
          <div className="md:col-span-4 space-y-2.5">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              {isAr ? 'معلومات التواصل المباشر' : 'Coordonnées Officielles'}
            </div>
            <a
              href="https://wa.me/212717516563"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-xs text-slate-200 hover:text-[#00D4B2] transition-colors"
            >
              <Phone className="w-4 h-4 text-[#00D4B2] shrink-0" />
              <span dir="ltr">0717516563 (+212 717 516 563)</span>
            </a>
            <a
              href="mailto:dentalbrandingpro@gmail.com"
              className="flex items-center gap-2 text-xs text-slate-200 hover:text-[#00D4B2] transition-colors"
            >
              <Mail className="w-4 h-4 text-[#00D4B2] shrink-0" />
              <span>dentalbrandingpro@gmail.com</span>
            </a>
            <div className="flex items-center gap-2 text-xs text-slate-300">
              <Clock className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                {isAr
                  ? 'دعم فني واستجابة مستمرة 24/7 لشركائنا من الأطباء'
                  : 'Support & permanence 24/7 pour les cabinets partenaires'}
              </span>
            </div>
          </div>

          {/* Guarantees Summary */}
          <div className="md:col-span-3 space-y-2 text-xs text-slate-300">
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
              {isAr ? 'ضمانات الجودة والالتزام' : 'Engagements Qualité'}
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'تسليم مضمون في غضون 7 أيام' : 'Livraison garantie en 7 jours'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'فحص ومعاينة شاملة قبل الدفع' : 'Inspection complète avant paiement'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{isAr ? 'اسم نطاق واستضافة سريعة مجاناً' : 'Hébergement & Domaine offerts'}</span>
            </div>
          </div>

        </div>

        {/* Quiet copyright */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-2">
          <div>
            © {new Date().getFullYear()} Dental Branding Pro. {isAr ? 'جميع الحقوق محفوظة.' : 'Tous droits réservés.'}
          </div>
          <div className="flex items-center gap-1 text-slate-400">
            <span>
              {isAr
                ? 'صُممت بدقة وعناية لخدمة التميز الطبي في طب الأسنان'
                : 'Conçu avec rigueur pour l\'excellence dentaire'}
            </span>
          </div>
        </div>

      </div>
    </footer>
  );
};
