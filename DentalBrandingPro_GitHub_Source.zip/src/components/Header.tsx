import React, { useState } from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import {
  Zap,
  Menu,
  X,
  Play,
  Pause,
  Car,
  Phone,
  ChevronRight,
  Sparkles,
  ShieldCheck,
} from 'lucide-react';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  onOpenQuickMode: () => void;
  onOpenBooking?: () => void;
  // Podcast controls in top bar
  isPodcastPlaying?: boolean;
  onTogglePodcastPlay?: () => void;
  onOpenCarMode?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  onOpenQuickMode,
  onOpenBooking,
  isPodcastPlaying = false,
  onTogglePodcastPlay,
  onOpenCarMode,
}) => {
  const strings = t[lang];
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const isAr = lang === 'ar';

  const navLinks = [
    { href: '#produits', label: strings.nav.products },
    { href: '#podcast', label: isAr ? '🎙️ البودكاست التنفيذي' : '🎙️ Podcast Audio' },
    { href: '#etapes', label: isAr ? 'في 3 خطوات' : 'En 3 Étapes' },
    { href: '#faq', label: isAr ? 'الأسئلة الشائعة' : 'FAQ' },
    { href: '#demo-3d', label: strings.nav.demo },
  ];

  return (
    <div className="w-full relative z-40">
      {/* 1. SEAMLESS TOP EXECUTIVE UTILITY STRIP (Deep Tech-Navy & Gold-Cyan Accents) */}
      <div className="w-full bg-[#061124] text-slate-200 text-xs border-b border-white/10 select-none">
        <div className="mx-auto max-w-7xl px-3 sm:px-6 lg:px-8 h-9 sm:h-10 flex items-center justify-between gap-2 sm:gap-4 overflow-hidden">
          
          {/* Left: Language Switcher & Moroccan Accreditation */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Segmented Luxury Language Switcher */}
            <div className="inline-flex items-center p-0.5 rounded-full bg-white/10 border border-white/15 shadow-inner">
              <button
                onClick={() => lang !== 'fr' && onToggleLang()}
                className={`flex items-center justify-center px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-extrabold transition-all duration-200 ${
                  lang === 'fr'
                    ? 'bg-gradient-to-r from-[#00D4B2] to-emerald-400 text-[#061124] shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="Afficher en Français"
              >
                <span>FR</span>
              </button>

              <button
                onClick={() => lang !== 'ar' && onToggleLang()}
                className={`flex items-center justify-center px-2.5 py-0.5 rounded-full text-[10px] sm:text-[11px] font-extrabold transition-all duration-200 ${
                  lang === 'ar'
                    ? 'bg-gradient-to-r from-[#00D4B2] to-emerald-400 text-[#061124] shadow-xs'
                    : 'text-slate-300 hover:text-white'
                }`}
                title="العرض باللغة العربية"
              >
                <span>{isAr ? 'عربي' : 'العربية'}</span>
              </button>
            </div>

            {/* Moroccan Trust & Express Delivery Badge */}
            <div className="hidden md:flex items-center gap-1.5 text-[11px] text-slate-300 pl-2.5 border-l border-white/15">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00D4B2] animate-pulse"></span>
              <span className="font-medium">
                {isAr ? 'المغرب • باقة تسليم 7 أيام متكاملة' : 'Maroc • Pack Clé en Main 7 Jours'}
              </span>
            </div>
          </div>

          {/* Center: Live Executive Podcast Ticker & Quick Play */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink min-w-0">
            <button
              onClick={onTogglePodcastPlay}
              className={`group inline-flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-full text-[10px] sm:text-xs font-bold transition-all duration-200 active:scale-95 shrink truncate border ${
                isPodcastPlaying
                  ? 'bg-gradient-to-r from-emerald-500/20 via-[#00D4B2]/20 to-emerald-500/20 text-[#00D4B2] border-[#00D4B2]/40 shadow-xs ring-1 ring-[#00D4B2]/30'
                  : 'bg-white/10 hover:bg-white/20 border-white/15 text-slate-200 hover:text-white'
              }`}
              title={
                isPodcastPlaying
                  ? (isAr ? 'إيقاف البودكاست مؤقتاً' : 'Mettre en pause le podcast')
                  : (isAr ? 'تشغيل البودكاست الطبي المدمج' : 'Écouter le podcast médical')
              }
            >
              <div
                className={`w-4 h-4 rounded-full flex items-center justify-center shrink-0 transition-transform group-hover:scale-110 ${
                  isPodcastPlaying
                    ? 'bg-[#00D4B2] text-[#061124]'
                    : 'bg-white/20 text-white'
                }`}
              >
                {isPodcastPlaying ? (
                  <Pause className="w-2.5 h-2.5 fill-current" />
                ) : (
                  <Play className="w-2.5 h-2.5 fill-current translate-x-0.2" />
                )}
              </div>

              {/* Animated Mini Wave bars when playing */}
              {isPodcastPlaying && (
                <div className="flex items-end gap-0.5 h-2.5 shrink-0">
                  <span className="w-0.5 h-2.5 bg-[#00D4B2] rounded-full animate-bounce"></span>
                  <span className="w-0.5 h-1.5 bg-[#00D4B2] rounded-full animate-pulse"></span>
                  <span className="w-0.5 h-2 bg-[#00D4B2] rounded-full animate-bounce delay-75"></span>
                </div>
              )}

              <span className="truncate">
                {isPodcastPlaying
                  ? (isAr ? 'البودكاست قيد التشغيل' : 'Podcast en cours')
                  : (isAr ? '🎙️ البودكاست التنفيذي 2026' : '🎙️ Podcast Audio 2026')}
              </span>
            </button>
          </div>

          {/* Right: Quick Mode 60s & Driving Mode & Direct VIP WhatsApp */}
          <div className="flex items-center gap-1.5 sm:gap-2.5 shrink-0">
            {/* Desktop Driving Mode shortcut */}
            {onOpenCarMode && (
              <button
                onClick={onOpenCarMode}
                className="hidden xl:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold text-amber-300 bg-amber-400/10 hover:bg-amber-400/20 border border-amber-400/25 transition-colors"
                title={isAr ? 'تشغيل وضع القيادة للسيارة' : 'Mode Conduite Auto'}
              >
                <Car className="w-3 h-3 text-amber-300" />
                <span>{isAr ? 'وضع السيارة' : 'Mode Auto'}</span>
              </button>
            )}

            {/* Quick Mode 60s */}
            <button
              onClick={onOpenQuickMode}
              className="inline-flex items-center gap-1 px-2 sm:px-2.5 py-0.5 sm:py-1 rounded-full text-[10px] sm:text-xs font-bold text-amber-300 bg-amber-400/15 hover:bg-amber-400/25 border border-amber-400/30 transition-all active:scale-95 whitespace-nowrap shadow-2xs"
              title={isAr ? 'ملخص تنفيذي 60 ثانية' : 'Synthèse 60 secondes'}
            >
              <Zap className="w-3 h-3 text-amber-400 fill-amber-400/30" />
              <span>{isAr ? '⚡ 60 ثانية' : '⚡ Mode 60s'}</span>
            </button>

            {/* Direct Phone / WhatsApp button on desktop */}
            <a
              href="https://wa.me/212717516563"
              target="_blank"
              rel="noopener noreferrer"
              className="hidden lg:inline-flex items-center gap-1.5 text-slate-300 hover:text-[#00D4B2] transition-colors text-xs font-semibold pl-2 border-l border-white/15"
              title="+212 717 516 563"
            >
              <Phone className="w-3 h-3 text-[#00D4B2]" />
              <span className="font-mono text-[11px] tracking-wide text-slate-200">0717-516563</span>
            </a>
          </div>

        </div>
      </div>

      {/* 2. MAIN LUXURY MEDICAL NAVIGATION BAR (Sticky, Ultra-Refined Architecture) */}
      <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-xl border-b border-slate-200/90 shadow-[0_4px_24px_-4px_rgba(15,44,89,0.08)] relative">
        <div className="mx-auto flex h-16 sm:h-20 max-w-7xl items-center justify-between px-3 sm:px-6 lg:px-8 gap-2 sm:gap-6">
          
          {/* Logo & Brand Identity — Bespoke Luxury Gold & Deep Navy Bezel */}
          <a href="#" className="flex items-center gap-3 sm:gap-3.5 group shrink min-w-0" aria-label="Dental Branding Pro">
            
            {/* Architectural Bezel Frame matching logo prestige */}
            <div className="relative shrink-0">
              {/* Outer ambient glow halo */}
              <div className="absolute -inset-1 rounded-full bg-gradient-to-tr from-amber-400/30 via-[#00D4B2]/30 to-[#0F2C59]/40 blur-[5px] opacity-60 group-hover:opacity-100 transition-opacity duration-300"></div>

              {/* Multi-layered concentric luxury ring */}
              <div className="relative w-11 h-11 sm:w-13 sm:h-13 rounded-full p-[2px] bg-gradient-to-tr from-[#0F2C59] via-[#D4AF37] to-[#00D4B2] shadow-md shadow-[#0F2C59]/20 group-hover:shadow-lg group-hover:shadow-amber-500/25 transition-all duration-300">
                {/* Midnight navy inner casing */}
                <div className="w-full h-full rounded-full bg-[#0A192F] p-0.5 overflow-hidden flex items-center justify-center border border-white/20 shadow-inner">
                  <img
                    src="/images/dental-branding-logo.webp"
                    alt="Dental Branding Pro Official Emblem"
                    width={52}
                    height={52}
                    className="w-full h-full object-contain rounded-full transition-transform duration-300 group-hover:scale-105"
                  />
                </div>
              </div>

              {/* Status jewel indicator (Gold & White) */}
              <span className="absolute -bottom-0.5 -end-0.5 w-3.5 h-3.5 rounded-full bg-gradient-to-tr from-amber-400 to-amber-300 border-2 border-white shadow-xs flex items-center justify-center">
                <span className="w-1 h-1 rounded-full bg-[#0A192F]"></span>
              </span>
            </div>

            {/* High-Elegance Brand Typography */}
            <div className="flex flex-col text-start justify-center min-w-0">
              <div className="flex items-center gap-1.5 sm:gap-2">
                <span className="text-base sm:text-xl font-black tracking-tight text-[#0F2C59] group-hover:text-[#0A192F] transition-colors leading-none whitespace-nowrap">
                  Dental Branding
                </span>
                
                {/* Prestige PRO metallic badge */}
                <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-gradient-to-r from-amber-500/15 via-[#00D4B2]/15 to-emerald-500/15 text-amber-900 border border-amber-500/30 leading-none shrink-0 shadow-2xs font-mono">
                  PRO
                </span>
              </div>

              {/* Elevated Tagline / Positioning */}
              <span className="hidden md:flex items-center gap-1 text-[11px] font-semibold text-slate-500 leading-tight mt-1 truncate max-w-[280px] lg:max-w-none">
                <span className="w-1 h-1 rounded-full bg-[#00D4B2] shrink-0"></span>
                <span>
                  {isAr
                    ? 'المنظومة الرقمية الرائدة لجراحي الأسنان بالمغرب'
                    : 'Écosystème Numérique Haute Précision pour Chirurgiens-Dentistes'}
                </span>
              </span>
            </div>
          </a>

          {/* Desktop Navigation Links with animated indicator */}
          <nav className="hidden lg:flex items-center gap-5 xl:gap-7 text-xs sm:text-sm font-semibold text-slate-700">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="hover:text-[#0F2C59] transition-colors py-2 relative group whitespace-nowrap"
              >
                <span className="group-hover:text-[#0F2C59] transition-colors font-bold">{link.label}</span>
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-gradient-to-r from-[#00D4B2] to-emerald-400 group-hover:w-full transition-all duration-300 rounded-full"></span>
              </a>
            ))}
          </nav>

          {/* Right Action: Pricing Pill & Primary CTA Button & Mobile Hamburger */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            
            {/* Sleek audio pill in main bar (compact) */}
            {onTogglePodcastPlay && (
              <button
                onClick={onTogglePodcastPlay}
                className={`hidden xl:inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-bold transition-all duration-200 active:scale-95 border ${
                  isPodcastPlaying
                    ? 'bg-emerald-500/10 border-emerald-500 text-emerald-800 shadow-sm shadow-emerald-500/15 ring-1 ring-emerald-500/30'
                    : 'bg-slate-50 hover:bg-slate-100 border-slate-200 text-slate-700'
                }`}
                title={
                  isPodcastPlaying
                    ? (isAr ? 'إيقاف البودكاست مؤقتاً' : 'Pause le podcast')
                    : (isAr ? 'تشغيل البودكاست' : 'Écouter le podcast')
                }
              >
                <span
                  className={`w-5 h-5 rounded-lg flex items-center justify-center shrink-0 transition-all ${
                    isPodcastPlaying
                      ? 'bg-emerald-500 text-white shadow-xs animate-pulse'
                      : 'bg-[#0F2C59] text-[#00D4B2]'
                  }`}
                >
                  {isPodcastPlaying ? (
                    <Pause className="w-2.5 h-2.5 fill-current" />
                  ) : (
                    <Play className="w-2.5 h-2.5 fill-current translate-x-0.2" />
                  )}
                </span>
                <span className="font-extrabold text-[11px] whitespace-nowrap">
                  {isPodcastPlaying
                    ? (isAr ? 'إيقاف البودكاست' : 'Pause Audio')
                    : (isAr ? 'بودكاست صوتي' : 'Podcast Audio')}
                </span>
              </button>
            )}

            {/* Official Moroccan pricing tag */}
            <div className="hidden min-[1140px]:flex flex-col items-end text-end mr-0.5">
              <div className="flex items-center gap-1.5 text-[11px] font-black text-emerald-700">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                <span className="text-[10px] text-slate-400 line-through decoration-[1.5px] font-semibold whitespace-nowrap">
                  {isAr ? '5000 درهم' : '5000 DH'}
                </span>
                <span className="whitespace-nowrap">2 000 DH TTC</span>
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold border border-amber-300 whitespace-nowrap">
                  {isAr ? 'لفترة محدودة' : 'Offre limitée'}
                </span>
              </div>
              <span className="text-[10px] text-slate-400 font-medium whitespace-nowrap">
                {isAr ? 'السعر الأصلي 5000 درهم • دفعة واحدة بدون اشتراك' : 'Prix initial 5000 DH • Sans abonnement'}
              </span>
            </div>

            {/* Mobile Menu Hamburger Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 rounded-xl text-slate-800 hover:bg-slate-100 transition-colors border border-slate-200"
              aria-label="Menu"
            >
              {mobileMenuOpen ? (
                <X className="w-5 h-5 text-slate-800" />
              ) : (
                <Menu className="w-5 h-5 stroke-[2.5] text-slate-800" />
              )}
            </button>
          </div>

        </div>

        {/* 3. MOBILE SLIDE-DOWN DRAWER MENU (Mounted relative to header top-full) */}
        {mobileMenuOpen && (
          <div className="lg:hidden absolute top-full inset-x-0 z-50 bg-white/98 backdrop-blur-2xl border-b border-slate-200 shadow-2xl transition-all animate-fadeIn">
            <div className="max-w-7xl mx-auto px-4 py-5 space-y-4">
              
              <div className="flex items-center justify-between px-2 text-[11px] font-bold uppercase tracking-wider text-slate-400">
                <span>{isAr ? 'أقسام المنظومة' : 'Navigation Rapide'}</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-slate-400 line-through decoration-[1.5px] text-[10px] font-semibold whitespace-nowrap">
                    {isAr ? '5000 درهم' : '5000 DH'}
                  </span>
                  <span className="text-emerald-600 font-bold whitespace-nowrap">2 000 DH</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold whitespace-nowrap">
                    {isAr ? 'لفترة محدودة' : 'Offre limitée'}
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 gap-1.5">
                {navLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className="flex items-center justify-between px-4 py-3 rounded-xl text-sm font-bold text-slate-800 hover:bg-slate-50 hover:text-[#0F2C59] transition-colors border border-transparent hover:border-slate-200"
                  >
                    <span>{link.label}</span>
                    <ChevronRight className={`w-4 h-4 text-slate-400 ${isAr ? 'rotate-180' : ''}`} />
                  </a>
                ))}
              </div>

              {/* Mobile Podcast Player Card */}
              {onTogglePodcastPlay && (
                <div className="p-3.5 rounded-2xl bg-[#0F2C59] text-white flex items-center justify-between gap-3 shadow-md shadow-[#0F2C59]/15">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-xl bg-white/10 flex items-center justify-center text-[#00D4B2] shrink-0">
                      {isPodcastPlaying ? (
                        <Pause className="w-4 h-4 fill-current animate-pulse" />
                      ) : (
                        <Play className="w-4 h-4 fill-current translate-x-0.2" />
                      )}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-bold truncate">
                        {isAr ? 'البودكاست التنفيذي للعيادات' : 'Podcast Exécutif Dentaire'}
                      </div>
                      <div className="text-[11px] text-[#00D4B2] font-medium flex items-center gap-1.5">
                        <span className={`w-1.5 h-1.5 rounded-full ${isPodcastPlaying ? 'bg-emerald-400 animate-ping' : 'bg-slate-400'}`}></span>
                        <span>{isPodcastPlaying ? (isAr ? 'قيد التشغيل الآن' : 'En lecture') : (isAr ? 'متوقف مؤقتاً' : 'En pause')}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={onTogglePodcastPlay}
                    className={`px-3 py-1.5 rounded-xl font-black text-xs transition-all active:scale-95 shrink-0 shadow-xs ${
                      isPodcastPlaying
                        ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                        : 'bg-[#00D4B2] text-[#0A192F]'
                    }`}
                  >
                    {isPodcastPlaying ? (isAr ? 'إيقاف' : 'Pause') : (isAr ? 'تشغيل' : 'Écouter')}
                  </button>
                </div>
              )}

              {/* Mobile Car Driving Mode shortcut */}
              {onOpenCarMode && (
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    onOpenCarMode();
                  }}
                  className="w-full flex items-center justify-center gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-700 font-bold text-xs"
                >
                  <Car className="w-4 h-4 text-amber-600" />
                  <span>{isAr ? '🚗 تفعيل واجهة القيادة في السيارة' : '🚗 Activer le Mode Conduite Auto'}</span>
                </button>
              )}

              {/* Direct Contact Phone */}
              <div className="pt-3 border-t border-slate-100 flex items-center justify-between px-2 text-xs">
                <span className="text-slate-500">{isAr ? 'استشارة فورية واتساب:' : 'Conseil direct WhatsApp :'}</span>
                <a
                  href="https://wa.me/212717516563"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="font-mono font-bold text-[#0F2C59] hover:text-[#00D4B2] flex items-center gap-1"
                >
                  <Phone className="w-3.5 h-3.5 text-[#00D4B2]" />
                  +212 717 516 563
                </a>
              </div>

            </div>
          </div>
        )}
      </header>
    </div>
  );
};
