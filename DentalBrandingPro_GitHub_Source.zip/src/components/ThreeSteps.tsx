import React from 'react';
import { Language } from '../types';
import {
  ClipboardList,
  Rocket,
  ShieldCheck,
  CheckCircle2,
  Clock,
  ArrowRight,
  Sparkles,
  Zap,
  Check,
} from 'lucide-react';

interface ThreeStepsProps {
  lang: Language;
  onOpenBooking: () => void;
}

export const ThreeSteps: React.FC<ThreeStepsProps> = ({
  lang,
  onOpenBooking,
}) => {
  const isAr = lang === 'ar';

  const steps = [
    {
      stepNumber: '01',
      badge: isAr ? 'الخطوة الأولى • بدون دفع' : 'Étape 1 • Aucun Paiement',
      title: isAr
        ? 'طلب الحزمة وإرسال معلومات العيادة'
        : 'Commande & Transmission des Informations',
      desc: isAr
        ? 'تتواصل معنا عبر الواتساب أو النموذج السريع. ترسل اسم العيادة والتخصص، الشعار والمدينة ورقم الواتساب. لا يُطلب منك دفع أي درهم في هذه المرحلة إطلاقاً.'
        : 'Vous transmettez vos informations de base (nom du praticien, spécialité, ville, logo éventuel et contact WhatsApp). Aucun paiement n’est requis à ce stade.',
      highlights: isAr
        ? [
            '0 درهم دفعة أولى أو تسبيق',
            'استلام الطلب والبدء الفوري',
            'محادثة مباشرة لتحديد التفاصيل',
          ]
        : [
            '0 DH d’acompte ou d’avance',
            'Prise en charge immédiate',
            'Échange direct sur vos priorités',
          ],
      icon: ClipboardList,
      gradient: 'from-blue-500 to-cyan-500',
      timing: isAr ? 'اليوم 1' : 'Jour 1',
    },
    {
      stepNumber: '02',
      badge: isAr ? 'الخطوة الثانية • 7 أيام' : 'Étape 2 • 7 Jours Chrono',
      title: isAr
        ? 'البرمجة والإعداد والإطلاق الشامل'
        : 'Développement & Configuration Complète',
      desc: isAr
        ? 'يقوم فريقنا التقني ببرمجة موقعك فائق السرعة (< 0.8s)، وربط النطاق والاستضافة المجانية الشاملة بدون تجديد سنوي، وتفعيل بنك الردود وبطاقة DentaLink الذكية الخاصة بك.'
        : 'Notre équipe développe votre site ultra-rapide (< 0.8s), configure votre nom de domaine et hébergement offerts, vos banques de réponses et votre carte DentaLink.',
      highlights: isAr
        ? [
            'سرعة فائقة مطابقة لمعايير Google',
            'حجز دومين واستضافة سريعة مجاناً',
            'ربط الواتساب ورمز QR عالي الدقة',
          ]
        : [
            'Score PageSpeed optimal (< 0.8s)',
            'Nom de domaine & SSL offerts',
            'Liaison WhatsApp & QR code HD',
          ],
      icon: Rocket,
      gradient: 'from-cyan-500 to-emerald-500',
      timing: isAr ? 'الأيام 2 - 7' : 'Jours 2 à 7',
    },
    {
      stepNumber: '03',
      badge: isAr ? 'الخطوة الثالثة • بعد الرضا' : 'Étape 3 • Paiement après Validation',
      title: isAr
        ? 'المعاينة والتجربة، ثم الدفع (2000 درهم بدل 5000 لفترة محدودة)'
        : 'Inspection Complète & Règlement de 2000 DH (au lieu de 5000 DH)',
      desc: isAr
        ? 'تختبر بنفسك منظومة العيادة على الهاتف والكمبيوتر. تتأكد من عمل كافة الروابط ونماذج الحجز. لا تدفع مبلغ 2000 درهم (السعر الأصلي 5000 درهم - عرض لفترة محدودة) إلا بعد الرضا الكامل والمعاينة. 0 درهم اشتراك سنوي.'
        : 'Vous testez personnellement votre écosystème sur smartphone et PC. Une fois 100% satisfait du résultat, vous réglez le tarif de 2000 DH (au lieu de 5000 DH, offre limitée). 0 DH d’abonnement.',
      highlights: isAr
        ? [
            'معاينة واختبار فعلي قبل أي سداد',
            '2000 درهم فقط بدل 5000 درهم (لفترة محدودة)',
            '0 درهم اشتراك شهري أو سنوي',
          ]
        : [
            'Contrôle total avant règlement',
            '2000 DH au lieu de 5000 DH (Offre limitée)',
            '0 DH de frais récurrents cachés',
          ],
      icon: ShieldCheck,
      gradient: 'from-emerald-500 to-teal-500',
      timing: isAr ? 'عند الاستلام' : 'À la livraison',
    },
  ];

  return (
    <section
      id="etapes"
      className="py-16 lg:py-24 bg-[#F8FAFC] dark:bg-[#071324] border-b border-slate-200 dark:border-slate-800 transition-colors duration-200 relative overflow-hidden"
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-50 dark:bg-emerald-950/50 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold text-emerald-700 dark:text-[#00D4B2] mb-4 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-[#00D4B2]" />
            <span>
              {isAr
                ? 'في 3 خطوات بسيطة فقط'
                : 'Processus en 3 Étapes Simples'}
            </span>
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-[#0F2C59] dark:text-white tracking-tight mb-4">
            {isAr
              ? 'كيف تنتقل عيادتك إلى المنظومة في 3 خطوات ؟'
              : 'Comment Équiper Votre Cabinet en 3 Étapes ?'}
          </h2>

          <p className="text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            {isAr
              ? 'نهج عملي شفاف ومريح بنسبة 100% : لا ندفعك لأي مخاطرة مالية، ولا نطلب منك أي درهم قبل أن تعاين وتجرب عمل المنظومة بالكامل.'
              : 'Une démarche ultra-claire et sans risque financier : vous ne versez aucun acompte avant d’avoir inspecté et validé votre écosystème en direct.'}
          </p>
        </div>

        {/* 3 Steps Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {steps.map((st, index) => {
            const Icon = st.icon;
            return (
              <div
                key={index}
                className="relative bg-white dark:bg-[#0A192F] rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-xl flex flex-col justify-between transition-all duration-300 hover:shadow-2xl hover:border-[#00D4B2]/50 group"
              >
                {/* Big Number Watermark */}
                <div className="absolute top-4 right-4 text-5xl font-black text-slate-100 dark:text-slate-800/60 select-none pointer-events-none group-hover:text-[#00D4B2]/10 transition-colors">
                  {st.stepNumber}
                </div>

                <div>
                  {/* Badge & Timing */}
                  <div className="flex items-center justify-between gap-2 mb-6">
                    <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 border border-slate-200 dark:border-slate-700">
                      {st.badge}
                    </span>
                    <span className="text-xs font-semibold text-[#00D4B2] flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {st.timing}
                    </span>
                  </div>

                  {/* Icon */}
                  <div
                    className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${st.gradient} text-white flex items-center justify-center shadow-lg mb-6 group-hover:scale-105 transition-transform`}
                  >
                    <Icon className="w-7 h-7" />
                  </div>

                  {/* Step Title */}
                  <h3 className="text-xl font-bold text-[#0F2C59] dark:text-white mb-3 leading-snug">
                    {st.title}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                    {st.desc}
                  </p>

                  {/* Bullet highlights */}
                  <div className="space-y-2 pt-4 border-t border-slate-100 dark:border-slate-800">
                    {st.highlights.map((h, hIdx) => (
                      <div key={hIdx} className="flex items-center gap-2 text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-200">
                        <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Step Connector Indicator */}
                <div className="mt-8 pt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span>{isAr ? `المرحلة ${index + 1} من 3` : `Étape ${index + 1} sur 3`}</span>
                  <span className="font-bold text-[#0F2C59] dark:text-[#00D4B2]">
                    {index === 2 ? (
                      <div className="flex items-center gap-1.5 justify-end">
                        <span className="text-[10px] text-slate-400 line-through decoration-[1.5px] font-semibold whitespace-nowrap">
                          {isAr ? '5000 درهم' : '5000 DH'}
                        </span>
                        <span className="whitespace-nowrap">
                          {isAr ? '2000 درهم (لفترة محدودة)' : '2000 DH (Offre limitée)'}
                        </span>
                      </div>
                    ) : (
                      isAr ? 'مضمونة 100%' : 'Garantie 100%'
                    )}
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* CTA Box */}
        <div className="mt-14 text-center">
          <div className="inline-flex flex-col sm:flex-row items-center gap-4 p-2 sm:p-3 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-md">
            <div className="px-4 py-2 text-sm text-slate-700 dark:text-slate-300 font-medium">
              {isAr
                ? 'جاهز لبدء الخطوة الأولى دون أي دفع مسبق ؟'
                : 'Prêt à lancer l’Étape 1 sans aucun paiement préalable ?'}
            </div>
            <button
              onClick={onOpenBooking}
              className="w-full sm:w-auto px-6 py-3 rounded-xl bg-[#00D4B2] hover:bg-[#00bf9e] text-slate-950 font-bold text-sm shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Zap className="w-4 h-4 text-slate-950" />
              <span>{isAr ? 'ابدأ الآن في دقيقة واحدة' : 'Démarrer en 1 minute'}</span>
              <ArrowRight className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
