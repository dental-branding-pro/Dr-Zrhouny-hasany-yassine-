import React, { useState, useEffect } from 'react';
import { Language } from '../types';
import { t } from '../data/translations';
import { X, MessageCircle, ShieldCheck, Check } from 'lucide-react';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const BookingModal: React.FC<BookingModalProps> = ({ isOpen, onClose, lang }) => {
  const strings = t[lang];

  const [doctorName, setDoctorName] = useState('');
  const [city, setCity] = useState('');
  const [phone, setPhone] = useState('');
  const [priority, setPriority] = useState(strings.bookingModal.priorityOptions[0]);

  // Keyboard accessibility: Close on Escape
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const sanitize = (val: string, maxLen = 80) =>
    val.replace(/[^\p{L}\p{N}\s.,+()_-]/gu, '').trim().slice(0, maxLen);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanDoctor = sanitize(doctorName);
    const cleanCity = sanitize(city);
    const cleanPhone = sanitize(phone, 30);

    const message = lang === 'ar'
      ? `السلام عليكم Dental Branding Pro،
أود طلب المنظومة الرقمية الشاملة لعيادة الأسنان :
• الطبيب / العيادة : ${cleanDoctor || 'غير محدد'}
• المدينة : ${cleanCity || 'غير محددة'}
• هاتف الواتساب للتواصل : ${cleanPhone || 'غير محدد'}
• الهدف / الأولوية : ${priority}
• السعر المتفق عليه : 2000 درهم فقط بدل 5000 درهم (عرض لفترة محدودة - الدفع بعد التسليم والمعاينة الكاملة).`
      : `Bonjour Dental Branding Pro,
Je souhaite commander l'écosystème pour mon cabinet dentaire :
• Docteur / Cabinet : ${cleanDoctor || 'Non précisé'}
• Ville : ${cleanCity || 'Non précisée'}
• WhatsApp de contact : ${cleanPhone || 'Non précisé'}
• Objectif / Priorité : ${priority}
• Tarif convenu : 2000 DH au lieu de 5000 DH (Offre limitée - Paiement après livraison & inspection).`;

    const url = `https://wa.me/212717516563?text=${encodeURIComponent(message)}`;
    const link = document.createElement('a');
    link.href = url;
    link.target = '_blank';
    link.rel = 'noopener noreferrer';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    onClose();
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs"
    >
      <div className="relative w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden transition-colors">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#0F2C59] dark:bg-slate-800 text-white flex items-center justify-between border-b border-white/10 dark:border-slate-700">
          <div>
            <h3 id="booking-modal-title" className="text-base sm:text-lg font-bold text-white">
              {strings.bookingModal.title}
            </h3>
            <p className="text-xs text-slate-300 mt-0.5">
              {strings.bookingModal.subtitle}
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Fermer la boîte de dialogue"
            className="p-1.5 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Promotional Price Banner */}
        <div className="bg-amber-50 dark:bg-amber-950/40 border-b border-amber-200 dark:border-amber-800/60 px-6 py-2.5 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="font-semibold text-slate-700 dark:text-slate-300">
              {lang === 'ar' ? 'سعر الباقة:' : 'Tarif du Pack :'}
            </span>
            <span className="text-slate-400 line-through decoration-[1.5px] font-semibold text-[10px] whitespace-nowrap">
              {lang === 'ar' ? '5000 درهم' : '5000 DH'}
            </span>
            <span className="font-extrabold text-[#0F2C59] dark:text-[#00D4B2] whitespace-nowrap">
              {lang === 'ar' ? '2000 درهم' : '2000 DH'}
            </span>
            <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-200 dark:bg-amber-900 text-amber-900 dark:text-amber-200 font-bold">
              {lang === 'ar' ? 'لفترة محدودة' : 'Offre limitée'}
            </span>
          </div>
          <span className="text-[11px] text-emerald-700 dark:text-emerald-400 font-bold shrink-0">
            {lang === 'ar' ? 'الدفع بعد المعاينة' : 'Paiement à la livraison'}
          </span>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4 text-xs sm:text-sm">
          
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              {strings.bookingModal.doctorName} *
            </label>
            <input
              type="text"
              required
              placeholder={strings.bookingModal.doctorPlaceholder}
              value={doctorName}
              onChange={(e) => setDoctorName(e.target.value)}
              className="w-full text-xs p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-hidden focus:border-[#00D4B2]"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {strings.bookingModal.city} *
              </label>
              <input
                type="text"
                required
                placeholder={strings.bookingModal.cityPlaceholder}
                value={city}
                onChange={(e) => setCity(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-hidden focus:border-[#00D4B2]"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
                {strings.bookingModal.phone} *
              </label>
              <input
                type="tel"
                required
                placeholder={strings.bookingModal.phonePlaceholder}
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full text-xs p-2.5 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white placeholder:text-slate-400 dark:placeholder:text-slate-500 focus:outline-hidden focus:border-[#00D4B2]"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">
              {strings.bookingModal.priority}
            </label>
            <div className="w-full text-xs p-3 rounded-xl border border-emerald-300 dark:border-emerald-700/60 bg-emerald-50/70 dark:bg-emerald-950/30 text-slate-900 dark:text-white flex items-center justify-between gap-2 shadow-2xs">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse shrink-0" />
                <span className="font-bold text-[#0F2C59] dark:text-[#00D4B2]">
                  {strings.bookingModal.priorityOptions[0]}
                </span>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold shrink-0">
                {lang === 'ar' ? 'المنظومة الشاملة' : 'Pack Clé en Main'}
              </span>
            </div>
          </div>

          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800/60 text-[11px] text-emerald-900 dark:text-emerald-300 flex items-start gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
            <span>{strings.bookingModal.note}</span>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-[#0F2C59] dark:bg-[#00D4B2] hover:bg-[#163a73] dark:hover:bg-[#10B981] text-white dark:text-[#0A192F] rounded-xl font-bold text-xs sm:text-sm shadow-md flex items-center justify-center gap-2 transition-colors"
          >
            <MessageCircle className="w-4 h-4 text-[#00D4B2] dark:text-[#0A192F]" />
            <span>{strings.bookingModal.submit}</span>
          </button>
        </form>

      </div>
    </div>
  );
};
