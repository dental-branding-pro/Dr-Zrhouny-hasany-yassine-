import React, { useState, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  Volume2,
  VolumeX,
  Radio,
  Car,
  Clock,
  Sparkles,
  Share2,
  Headphones,
  CheckCircle,
  PhoneCall,
  ChevronDown,
  ChevronUp,
  Settings,
  Check,
} from 'lucide-react';
import { DENTAL_PODCAST_DATA } from '../data/podcastData';

interface DentalPodcastSectionProps {
  lang: 'fr' | 'ar';
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onTogglePlay: () => void;
  onSeek: (seconds: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  playbackRate: number;
  onChangePlaybackRate: (speed: number) => void;
  onOpenCarMode: () => void;
  onOpenBooking: () => void;
  audioSourceName: string;
  isCustomFile: boolean;
  onOpenAudioSettings: () => void;
  onUploadFile: (file: File) => void;
}

export const DentalPodcastSection: React.FC<DentalPodcastSectionProps> = ({
  lang,
  isPlaying,
  currentTime,
  duration,
  onTogglePlay,
  onSeek,
  isMuted,
  onToggleMute,
  playbackRate,
  onChangePlaybackRate,
  onOpenCarMode,
  onOpenBooking,
  audioSourceName,
  onOpenAudioSettings,
  onUploadFile,
}) => {
  const isAr = lang === 'ar';
  const episode = DENTAL_PODCAST_DATA;
  const [showDetails, setShowDetails] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const quickFileInputRef = useRef<HTMLInputElement>(null);

  const formatTime = (secs: number) => {
    if (isNaN(secs) || !isFinite(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  const currentChapter =
    episode.chapters
      .slice()
      .reverse()
      .find((ch) => currentTime >= ch.timeSeconds) || episode.chapters[0];

  const currentChapterIndex = episode.chapters.findIndex((c) => c.id === currentChapter.id);

  const handleCopyLink = () => {
    const url = window.location.origin + window.location.pathname + '#podcast';
    navigator.clipboard?.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleQuickUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadFile(file);
    }
  };

  const speeds = [1.0, 1.25, 1.5, 2.0];

  // Cycle speed rate
  const cyclePlaybackRate = () => {
    const currentIndex = speeds.indexOf(playbackRate);
    const nextRate = speeds[(currentIndex + 1) % speeds.length];
    onChangePlaybackRate(nextRate);
  };

  return (
    <section id="podcast" className="relative py-8 sm:py-12 bg-slate-900 text-white overflow-hidden scroll-mt-16">
      {/* Background Glow */}
      <div className="absolute inset-0 pointer-events-none opacity-20">
        <div className="absolute -top-24 -left-24 w-80 h-80 bg-[#00D4B2] rounded-full blur-[120px]" />
        <div className="absolute -bottom-24 -right-24 w-80 h-80 bg-[#0F2C59] rounded-full blur-[120px]" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6">
        {/* Compact Header: Takes minimal vertical space */}
        <div className="text-center max-w-2xl mx-auto mb-5">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/70 border border-cyan-500/30 text-cyan-300 text-xs font-bold shadow-xs mb-2">
            <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
            <span>
              {isAr ? '🎙️ بودكاست صوتي لعيادات الأسنان' : '🎙️ Podcast Audio Officiel'}
            </span>
          </div>

          <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-white tracking-tight leading-snug mb-1.5 text-balance">
            {isAr
              ? 'استمع للتحليل الكامل: المنظومة الشاملة لجراحي الأسنان'
              : "Écoutez l'Analyse Complète : L'Écosystème Digital"}
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 max-w-lg mx-auto">
            {isAr
              ? 'كيف توفر المنظومة أكثر من 15 ساعة أسبوعياً لعيادتك وتضاعف المواعيد المؤكدة عبر الواتساب وخرائط جوجل بـ 2000 درهم فقط.'
              : 'Automatisez vos réservations WhatsApp, dominez Google Maps et libérez 15h/semaine pour 2 000 DH.'}
          </p>
        </div>

        {/* The Master Studio Compact Console */}
        <div className="bg-[#0A192F]/95 border border-white/10 rounded-2xl p-4 sm:p-6 shadow-2xl backdrop-blur-xl relative overflow-hidden">
          {/* Hidden quick file input */}
          <input
            type="file"
            ref={quickFileInputRef}
            onChange={handleQuickUpload}
            accept="audio/*,.mp3,.m4a,.wav,.aac,.ogg"
            className="hidden"
          />

          {/* Top Bar inside Card: Episode details + Quick Controls */}
          <div className="flex items-center justify-between gap-3 pb-3.5 border-b border-white/10 mb-4">
            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/25 flex items-center justify-center text-cyan-400 shrink-0">
                <Headphones className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-xs sm:text-sm font-extrabold text-white truncate">
                    {isAr ? 'الحلقة 01: الإطلاق الحصري' : 'Épisode 01 : Stratégie & Automatisation'}
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 shrink-0">
                    HD
                  </span>
                </div>
                <div className="text-[11px] text-cyan-300/90 font-medium truncate flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse shrink-0" />
                  <span className="truncate">{audioSourceName}</span>
                </div>
              </div>
            </div>

            {/* Quick Actions (Car Mode + Settings + Share) */}
            <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
              {/* Car Mode Button (Compact) */}
              <button
                onClick={onOpenCarMode}
                className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-amber-500/15 border border-amber-500/40 hover:bg-amber-500/25 active:scale-95 text-amber-300 text-xs font-bold transition-all"
                title={isAr ? 'تشغيل وضع القيادة في السيارة' : 'Activer le mode conduite'}
              >
                <Car className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden min-[380px]:inline">{isAr ? 'وضع القيادة' : 'Mode Conduite'}</span>
              </button>

              {/* Audio Settings */}
              <button
                onClick={onOpenAudioSettings}
                className="p-1.5 sm:p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 active:scale-95 text-slate-300 hover:text-cyan-300 transition-all"
                title={isAr ? 'إعدادات وخيارات الصوت' : 'Paramètres audio'}
                aria-label="Settings"
              >
                <Settings className="w-4 h-4" />
              </button>

              {/* Share Button */}
              <button
                onClick={handleCopyLink}
                className="p-1.5 sm:p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 active:scale-95 text-slate-300 hover:text-white transition-all relative"
                title={isAr ? 'نسخ الرابط' : 'Copier le lien'}
                aria-label="Share"
              >
                {copiedLink ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {/* Active Chapter Highlight Pill (Ultra-Compact) */}
          <div className="mb-3.5 px-3 py-2 rounded-xl bg-cyan-950/50 border border-cyan-500/25 flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-2 truncate">
              {/* Mini Audio Equalizer Animation */}
              <div className="flex items-end gap-0.5 h-3 shrink-0">
                <span
                  className={`w-0.5 bg-cyan-400 rounded-full transition-all ${
                    isPlaying ? 'animate-bounce h-3' : 'h-1'
                  }`}
                  style={{ animationDuration: '0.6s' }}
                />
                <span
                  className={`w-0.5 bg-cyan-400 rounded-full transition-all ${
                    isPlaying ? 'animate-bounce h-2' : 'h-1.5'
                  }`}
                  style={{ animationDuration: '0.8s', animationDelay: '0.15s' }}
                />
                <span
                  className={`w-0.5 bg-cyan-400 rounded-full transition-all ${
                    isPlaying ? 'animate-bounce h-3' : 'h-0.5'
                  }`}
                  style={{ animationDuration: '0.7s', animationDelay: '0.3s' }}
                />
              </div>
              <span className="font-bold text-cyan-300 shrink-0">
                {isAr ? 'المحور' : 'Chapitre'} {currentChapterIndex + 1}:
              </span>
              <span className="text-white font-semibold truncate">
                {isAr ? currentChapter.title.ar : currentChapter.title.fr}
              </span>
            </div>
            <span className="text-[11px] font-mono text-cyan-400 shrink-0">
              {currentChapter.timeFormatted}
            </span>
          </div>

          {/* Scrubber Progress Slider */}
          <div className="space-y-1 mb-3.5">
            <div
              className="w-full h-2 sm:h-2.5 bg-slate-800 rounded-full cursor-pointer relative overflow-hidden group border border-white/5"
              onClick={(e) => {
                const rect = e.currentTarget.getBoundingClientRect();
                const clickX = isAr ? rect.right - e.clientX : e.clientX - rect.left;
                const ratio = Math.max(0, Math.min(1, clickX / rect.width));
                onSeek(ratio * duration);
              }}
            >
              <div
                className="h-full bg-gradient-to-r from-cyan-400 via-teal-400 to-emerald-400 rounded-full relative"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="flex justify-between items-center text-[11px] font-mono font-medium text-slate-400 px-0.5">
              <span>{formatTime(currentTime)}</span>
              <span>{formatTime(duration)}</span>
            </div>
          </div>

          {/* Main Controls Row (Rewind, Play/Pause, Forward, Speed, Mute) */}
          <div className="flex items-center justify-between gap-3 mb-4 flex-wrap">
            {/* Playback Transport Buttons */}
            <div className="flex items-center gap-2 sm:gap-3">
              {/* Skip back 15s */}
              <button
                onClick={() => onSeek(Math.max(0, currentTime - 15))}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-slate-300 hover:text-white flex items-center justify-center transition-all border border-white/10"
                title={isAr ? 'تراجع 15 ثانية' : 'Reculer 15s'}
              >
                <RotateCcw className="w-4 h-4 text-cyan-400" />
              </button>

              {/* Main Play / Pause Button (Ergonomic 48px) */}
              <button
                onClick={onTogglePlay}
                className={`flex items-center justify-center w-12 h-12 sm:w-13 sm:h-13 rounded-2xl font-black shadow-lg active:scale-95 hover:scale-105 transition-all ${
                  isPlaying
                    ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 shadow-amber-500/30'
                    : 'bg-gradient-to-r from-[#00D4B2] via-teal-400 to-emerald-400 text-slate-950 shadow-teal-500/30 animate-pulse'
                }`}
                aria-label={isPlaying ? 'Pause' : 'Play'}
              >
                {isPlaying ? (
                  <Pause className="w-5 h-5 fill-current" />
                ) : (
                  <Play className="w-5 h-5 fill-current translate-x-0.5" />
                )}
              </button>

              {/* Skip forward 15s */}
              <button
                onClick={() => onSeek(Math.min(duration, currentTime + 15))}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/5 hover:bg-white/10 active:scale-95 text-slate-300 hover:text-white flex items-center justify-center transition-all border border-white/10"
                title={isAr ? 'تقديم 15 ثانية' : 'Avancer 15s'}
              >
                <RotateCw className="w-4 h-4 text-cyan-400" />
              </button>
            </div>

            {/* Speed & Volume Toggles */}
            <div className="flex items-center gap-2">
              {/* Speed Cycle Button */}
              <button
                onClick={cyclePlaybackRate}
                className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono font-bold text-slate-200 hover:text-cyan-300 transition-all active:scale-95"
                title={isAr ? 'تبديل سرعة التشغيل' : 'Vitesse'}
              >
                {playbackRate}x
              </button>

              {/* Mute Button */}
              <button
                onClick={onToggleMute}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 active:scale-95 text-slate-300 hover:text-white flex items-center justify-center transition-all"
                title={isMuted ? 'Unmute' : 'Mute'}
                aria-label="Volume"
              >
                {isMuted ? (
                  <VolumeX className="w-4 h-4 text-rose-400" />
                ) : (
                  <Volume2 className="w-4 h-4 text-teal-400" />
                )}
              </button>
            </div>
          </div>

          {/* Quick Chapters Strip (Compact 4 Pills) */}
          <div className="pt-3 border-t border-white/10">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                <span>{isAr ? 'محاور الحلقة السريعة' : 'Chapitres rapides'}</span>
              </span>

              {/* Toggle Details Accordion */}
              <button
                onClick={() => setShowDetails(!showDetails)}
                className="text-[11px] text-cyan-400 hover:text-cyan-300 font-bold inline-flex items-center gap-0.5"
              >
                <span>{showDetails ? (isAr ? 'إخفاء التفاصيل' : 'Réduire') : isAr ? 'تفاصيل المحاور' : 'Détails'}</span>
                {showDetails ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
              </button>
            </div>

            {/* 4 Compact Chapter Buttons */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
              {episode.chapters.map((ch, idx) => {
                const isActive = currentChapter.id === ch.id;
                return (
                  <button
                    key={ch.id}
                    onClick={() => {
                      onSeek(ch.timeSeconds);
                      if (!isPlaying) onTogglePlay();
                    }}
                    className={`p-2 rounded-xl text-start transition-all border flex items-center justify-between gap-1.5 text-xs ${
                      isActive
                        ? 'bg-teal-500 text-slate-950 border-teal-400 font-bold shadow-sm'
                        : 'bg-white/5 hover:bg-white/10 text-slate-300 border-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="truncate min-w-0">
                      <div className="text-[10px] opacity-75 font-mono">
                        #{idx + 1} • {ch.timeFormatted}
                      </div>
                      <div className="truncate font-semibold text-[11px]">
                        {isAr ? ch.title.ar.split(':')[0] : ch.title.fr.split(':')[0]}
                      </div>
                    </div>
                    {isActive && isPlaying ? (
                      <Pause className="w-3.5 h-3.5 shrink-0 fill-current" />
                    ) : (
                      <Play className="w-3.5 h-3.5 shrink-0 fill-current opacity-70" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Collapsible Detailed Description (Only when user expands) */}
            {showDetails && (
              <div className="mt-3 p-3 rounded-xl bg-white/5 border border-white/10 space-y-2 text-xs text-slate-300 animate-fadeIn">
                <div className="font-bold text-cyan-300 mb-1">
                  {isAr ? 'ملخص محاور الحلقة الاستثنائية:' : 'Résumé des thématiques de l’épisode :'}
                </div>
                {episode.chapters.map((ch, i) => (
                  <div key={ch.id} className="flex items-start gap-2">
                    <span className="font-mono text-[10px] text-cyan-400 px-1 py-0.5 rounded bg-cyan-950/60 shrink-0">
                      {ch.timeFormatted}
                    </span>
                    <div>
                      <span className="font-bold text-white">
                        {isAr ? ch.title.ar : ch.title.fr}:{' '}
                      </span>
                      <span className="text-slate-300 text-[11px]">
                        {isAr ? ch.description.ar : ch.description.fr}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Slim Bottom Booking Bar */}
          <div className="mt-3.5 pt-3 border-t border-white/10 flex items-center justify-between gap-2 flex-wrap">
            <div className="flex items-center gap-1.5 text-xs text-slate-300 flex-wrap">
              <span>{isAr ? 'المنظومة كاملة:' : 'Pack Clé en Main :'}</span>
              <span className="text-slate-400 line-through decoration-[1.5px] text-[10px] font-semibold whitespace-nowrap">
                {isAr ? '5000 درهم' : '5000 DH'}
              </span>
              <span className="text-emerald-400 font-extrabold font-mono whitespace-nowrap">
                {isAr ? '2000 درهم' : '2000 DH'}
              </span>
              <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-400/20 text-amber-300 border border-amber-400/40 font-bold whitespace-nowrap">
                {isAr ? 'لفترة محدودة' : 'Offre limitée'}
              </span>
              <span className="text-slate-400 text-[11px] whitespace-nowrap">
                {isAr ? '(الدفع بعد المعاينة)' : '(Paiement après livraison)'}
              </span>
            </div>

            <button
              onClick={onOpenBooking}
              className="inline-flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md active:scale-95 transition-all shrink-0"
            >
              <PhoneCall className="w-3.5 h-3.5" />
              <div className="inline-flex items-center gap-1 bg-slate-950/15 px-1.5 py-0.5 rounded">
                <span className="text-[9px] line-through decoration-[1.5px] decoration-slate-900 text-slate-900/80 font-bold whitespace-nowrap">
                  {isAr ? '5000 درهم' : '5000 DH'}
                </span>
                <span className="text-[11px] font-black whitespace-nowrap">
                  {isAr ? '2000 درهم' : '2000 DH'}
                </span>
              </div>
              <span className="whitespace-nowrap">{isAr ? 'حجز المنظومة الآن' : 'Commander le Pack'}</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
