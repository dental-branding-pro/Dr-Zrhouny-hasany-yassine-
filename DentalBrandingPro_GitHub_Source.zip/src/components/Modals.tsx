import React, { useState } from 'react';
import { Language, ModalContent } from '../types';
import {
  X,
  Check,
  Copy,
  Download,
  Calendar,
  Phone,
  MapPin,
  ExternalLink,
  MessageCircle,
  Stethoscope,
  BookOpen,
  QrCode,
  Share2,
  Sparkles,
  Search,
} from 'lucide-react';

interface ModalsProps {
  modal: ModalContent | null;
  onClose: () => void;
  lang: Language;
}

export const Modals: React.FC<ModalsProps> = ({ modal, onClose, lang }) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Diagnostic tool state
  const [diagStep, setDiagStep] = useState(1);
  const [selectedIssue, setSelectedIssue] = useState('douleur');
  const [selectedUrgency, setSelectedUrgency] = useState('moyenne');

  // FAQ search state
  const [faqSearch, setFaqSearch] = useState('');

  // Booking state
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('10:00');
  const [bookingReason, setBookingReason] = useState('Consultation générale & Bilan');

  if (!modal) return null;

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  // Download vCard helper
  const downloadVCard = () => {
    const vcardData = `BEGIN:VCARD
VERSION:3.0
N:Cabinet Dentaire;Dr;;;
FN:Dr. Cabinet Dentaire Pro
ORG:Centre Médico-Dentaire d'Excellence
TEL;TYPE=WORK,VOICE:+212717516563
TEL;TYPE=CELL,WHATSAPP:+212717516563
EMAIL;TYPE=PREF,INTERNET:dentalbrandingpro@gmail.com
URL:https://centre-dentaire-yasmile.netlify.app/
NOTE:Prise de rendez-vous en ligne 24/7 disponible sur notre site web.
END:VCARD`;

    const blob = new Blob([vcardData], { type: 'text/vcard;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'Dr_Cabinet_Dentaire.vcf');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto"
      dir={lang === 'ar' ? 'rtl' : 'ltr'}
    >
      <div className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8 transition-colors">
        
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#0F2C59] dark:bg-slate-800 text-white flex items-center justify-between border-b border-white/10 dark:border-slate-700">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#00D4B2]" />
            <h3 className="text-base sm:text-lg font-bold tracking-tight text-white">
              {modal.title}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content Switcher */}
        <div className="p-6 max-h-[75vh] overflow-y-auto text-slate-800 dark:text-slate-200">
          
          {/* 1. DIAGNOSTIC INTERACTIF */}
          {modal.type === 'diagnostic' && (
            <div className="space-y-6">
              <div className="p-3 bg-teal-50 rounded-xl border border-teal-200 text-xs text-teal-900 flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-teal-600 shrink-0" />
                <span>Simulateur d'orientation pour vos patients : aide à qualifier le motif de visite avant le RDV.</span>
              </div>

              {diagStep === 1 && (
                <div className="space-y-4">
                  <div className="text-sm font-bold text-slate-900">Étape 1 : Quel est votre principal motif de consultation ?</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { id: 'douleur', label: 'Douleur aiguë / Sensibilité froid-chaud' },
                      { id: 'esthetique', label: 'Esthétique du sourire / Dents tachées' },
                      { id: 'manque', label: 'Dent manquante / Remplacement' },
                      { id: 'gencive', label: 'Gencives qui saignent / Mobilité' },
                    ].map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setSelectedIssue(item.id)}
                        className={`p-3 rounded-xl border text-start text-xs font-semibold transition-all ${
                          selectedIssue === item.id
                            ? 'border-[#00D4B2] bg-teal-50/60 text-[#0F2C59] ring-2 ring-[#00D4B2]'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={() => setDiagStep(2)}
                    className="w-full mt-4 py-2.5 bg-[#0F2C59] text-white rounded-xl font-bold text-xs hover:bg-[#163a73]"
                  >
                    Suivant : Préciser le degré de gêne ⟶
                  </button>
                </div>
              )}

              {diagStep === 2 && (
                <div className="space-y-4">
                  <div className="text-sm font-bold text-slate-900">Étape 2 : Depuis combien de temps ressentez-vous ce besoin ?</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {[
                      { id: 'urgent', label: 'Depuis moins de 24h (Urgent)' },
                      { id: 'semaine', label: 'Depuis quelques jours à 1 semaine' },
                      { id: 'mois', label: 'Depuis plusieurs mois (Projet global)' },
                      { id: 'controle', label: 'Pas de douleur, simple contrôle de routine' },
                    ].map((item) => (
                      <button
                        key={item.id}
                        onClick={() => setSelectedUrgency(item.id)}
                        className={`p-3 rounded-xl border text-start text-xs font-semibold transition-all ${
                          selectedUrgency === item.id
                            ? 'border-[#00D4B2] bg-teal-50/60 text-[#0F2C59] ring-2 ring-[#00D4B2]'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                      >
                        {item.label}
                      </button>
                    ))}
                  </div>

                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 mt-4">
                    <div className="text-xs font-bold text-slate-800 mb-1">Recommandation personnalisée générée :</div>
                    <p className="text-xs text-slate-600 mb-3">
                      Une consultation clinique approfondie avec bilan radiologique panoramique est fortement conseillée pour évaluer avec précision votre situation.
                    </p>
                    <a
                      href={`https://wa.me/212717516563?text=${encodeURIComponent(
                        `Bonjour Dr, j'ai effectué le pré-diagnostic sur votre site web (Motif: ${selectedIssue}, Durée: ${selectedUrgency}). Je souhaite réserver une consultation.`
                      )}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center justify-center gap-2 w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-sm"
                    >
                      <MessageCircle className="w-4 h-4" />
                      <span>Transmettre mon bilan au Cabinet via WhatsApp</span>
                    </a>
                  </div>

                  <button
                    onClick={() => setDiagStep(1)}
                    className="text-xs text-slate-500 hover:underline"
                  >
                    ⟵ Recommencer l'évaluation
                  </button>
                </div>
              )}
            </div>
          )}

          {/* 2. PRISE DE RDV WHATSAPP DIRECTE */}
          {modal.type === 'whatsapp_booking' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Planification rapide avec motif pré-renseigné pour votre secrétariat.
              </p>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Motif de consultation</label>
                <select
                  value={bookingReason}
                  onChange={(e) => setBookingReason(e.target.value)}
                  className="w-full text-xs p-2.5 rounded-lg border border-slate-300 bg-white"
                >
                  <option>Consultation générale & Bilan complet</option>
                  <option>Détartrage & Polissage</option>
                  <option>Implantologie & Prothèse sur implant</option>
                  <option>Esthétique (Blanchiment / Facettes)</option>
                  <option>Urgence dentaire (Douleur intense)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Date souhaitée</label>
                  <input
                    type="date"
                    value={bookingDate}
                    onChange={(e) => setBookingDate(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Créneau horaire</label>
                  <select
                    value={bookingTime}
                    onChange={(e) => setBookingTime(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-slate-300 bg-white"
                  >
                    <option>09h30 - 11h00</option>
                    <option>11h00 - 13h00</option>
                    <option>14h30 - 16h30</option>
                    <option>16h30 - 18h30</option>
                  </select>
                </div>
              </div>

              <a
                href={`https://wa.me/212717516563?text=${encodeURIComponent(
                  `Bonjour, je souhaite réserver un rendez-vous pour : ${bookingReason} le ${bookingDate || 'prochain créneau disponible'} vers ${bookingTime}.`
                )}`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs mt-4 shadow-sm"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Ouvrir WhatsApp et valider le RDV au 0717516563</span>
              </a>
            </div>
          )}

          {/* 4. BANQUE DE RÉPONSES WHATSAPP */}
          {modal.type === 'whatsapp_responses' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                4 modèles prêts à l'emploi que votre assistante copie-colle en 1 seconde pour répondre sur WhatsApp :
              </p>

              {[
                {
                  id: 'resp-tarifs',
                  title: 'Réponse : Demande de Tarifs / Prix d’un implant',
                  text: 'Bonjour ! Le prix d’un implant dépend de la qualité osseuse et de la prothèse adaptée à votre anatomie. Nos implants en titane certifié débutent à partir de 6500 DH. Une consultation clinique avec radiographie permet de vous remettre un devis personnalisé exact. Souhaitez-vous planifier votre bilan cette semaine ?',
                },
                {
                  id: 'resp-urgence',
                  title: 'Réponse : Urgence dentaire / Douleur le weekend',
                  text: 'Bonjour, nous prenons votre douleur très au sérieux. Prenez un antalgique prescrit (paracétamol) sans dépasser la dose. Appliquez une poche de froid sur la joue si gonflement. Notre cabinet ouvre dès lundi 9h00, nous pouvons vous intercaler en priorité à 09h30. Confirmez-nous votre venue.',
                },
                {
                  id: 'resp-postop',
                  title: 'Réponse : Instructions post-extraction dentaire',
                  text: 'Bonjour ! Conseils importants : 1. Ne crachez pas et ne rincez pas énergiquement pendant 24h. 2. Mangez tiède ou froid (glace recommandée). 3. Prenez votre ordonnance comme indiqué. En cas de saignement persistant, mordez une compresse propre pendant 20 minutes.',
                },
                {
                  id: 'resp-retard',
                  title: 'Réponse : Patient en retard',
                  text: 'Bonjour M./Mme, le Dr vous attend pour votre soin prévu à cette heure. Afin de vous consacrer tout le temps nécessaire sans impacter les patients suivants, pouvez-vous nous préciser votre heure d’arrivée exacte ?',
                },
              ].map((item) => (
                <div key={item.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-[#0F2C59]">{item.title}</span>
                    <button
                      onClick={() => handleCopy(item.id, item.text)}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-700 hover:text-teal-900 bg-white px-2 py-1 rounded border border-slate-200"
                    >
                      {copiedId === item.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Copié !</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copier</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed bg-white p-2.5 rounded-lg border border-slate-100 font-mono">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* 5. AVIS GOOGLE RESPONSES */}
          {modal.type === 'google_reviews' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Protégez et bonifiez votre réputation Google avec des réponses rédigées selon le code déontologique :
              </p>

              {[
                {
                  id: 'rev-5star',
                  title: 'Réponse aux avis 5 étoiles (Patient satisfait)',
                  text: 'Un grand merci pour votre confiance et vos mots encourageants ! Toute notre équipe met un point d’honneur à assurer des soins doux et précis dans un environnement apaisant. Au plaisir de veiller sur votre sourire lors de votre prochain contrôle.',
                },
                {
                  id: 'rev-fear',
                  title: 'Réponse patient phobique rassuré',
                  text: 'Merci infiniment pour ce témoignage touchant. Savoir que nous avons pu vous réconcilier avec les soins dentaires et effacer votre appréhension est notre plus belle récompense professionnelle.',
                },
                {
                  id: 'rev-1star',
                  title: 'Désamorçage d’un avis négatif / mécontentement sur le retard',
                  text: 'Bonjour. La satisfaction et le confort de nos patients sont nos priorités absolues. Il arrive parfois qu’une urgence chirurgicale imprévue décale nos horaires, et nous comprenons parfaitement que l’attente soit désagréable. Nous vous invitons à contacter directement notre secrétariat au 0717516563 afin d’échanger avec vous et trouver la solution adaptée.',
                },
              ].map((item) => (
                <div key={item.id} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-[#0F2C59]">{item.title}</span>
                    <button
                      onClick={() => handleCopy(item.id, item.text)}
                      className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-700 hover:text-teal-900 bg-white px-2 py-1 rounded border border-slate-200"
                    >
                      {copiedId === item.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span>Copié !</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copier</span>
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed bg-white p-2.5 rounded-lg border border-slate-100 font-mono">
                    {item.text}
                  </p>
                </div>
              ))}
            </div>
          )}

          {/* 6. ARTICLES SEO SPÉCIFIQUES VILLE */}
          {modal.type === 'seo_articles' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Structure de 3 articles ultra-optimisés pour le référencement naturel local (Exemple : Casablanca / Rabat) :
              </p>

              <div className="space-y-3">
                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-[#0F2C59] mb-1">
                    Article 1 : Implants Dentaires : Déroulement, Prix et Choix du Chirurgien
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Cible les mots-clés : <em>implant dentaire prix Maroc, meilleur chirurgien dentiste, pose implant sans douleur</em>.
                  </p>
                  <div className="mt-2 text-[11px] text-teal-700 font-semibold">
                    Structure H2/H3 incluse + Balises Schema MedicalBusiness intégrées.
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-[#0F2C59] mb-1">
                    Article 2 : Facettes Dentaires Emax : Comment Obtenir un Hollywood Smile Naturel
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Cible : <em>facette dentaire tarif, blanchiment vs facettes, alignement sans bague</em>.
                  </p>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="text-xs font-bold text-[#0F2C59] mb-1">
                    Article 3 : Urgence Dentaire le Weekend : Que Faire et Qui Contacter Immédiatement
                  </div>
                  <p className="text-[11px] text-slate-600">
                    Génère du trafic récurrent à forte intention de conversion immédiate sur WhatsApp.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* 7. MOTEUR FAQ AUTOMATISÉ */}
          {modal.type === 'faq_engine' && (
            <div className="space-y-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Rechercher une question (ex: douleur, anesthésie, tarif...)"
                  value={faqSearch}
                  onChange={(e) => setFaqSearch(e.target.value)}
                  className="w-full text-xs pl-9 pr-3 py-2.5 rounded-xl border border-slate-300"
                />
              </div>

              <div className="space-y-2">
                {[
                  { q: 'La pose d’un implant dentaire est-elle douloureuse ?', a: 'Non, l’intervention est réalisée sous anesthésie locale puissante et s’avère souvent moins traumatisante qu’une extraction dentaire classique.' },
                  { q: 'Combien de temps dure un blanchiment dentaire ?', a: 'En cabinet, la séance dure environ 60 minutes avec lampe LED. Les résultats durent entre 1 et 3 ans selon votre hygiène et consommation de café/thé.' },
                  { q: 'Prenez-vous en charge les assurances ou mutuelles (CNOPS, CNSS) ?', a: 'Oui, notre secrétariat vous remet la feuille de soins dûment complétée ainsi que les devis et factures nécessaires à votre remboursement.' },
                  { q: 'À quel âge amener un enfant pour sa première visite ?', a: 'Il est conseillé de consulter dès l’apparition des premières dents de lait, ou vers l’âge de 3 ans pour instaurer une relation de confiance sans appréhension.' },
                ]
                  .filter((f) => f.q.toLowerCase().includes(faqSearch.toLowerCase()) || f.a.toLowerCase().includes(faqSearch.toLowerCase()))
                  .map((item, idx) => (
                    <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                      <div className="text-xs font-bold text-[#0F2C59] mb-1">{item.q}</div>
                      <div className="text-xs text-slate-600">{item.a}</div>
                    </div>
                  ))}
              </div>
            </div>
          )}

          {/* 8. QR CODE HD IMPRIMABLE */}
          {modal.type === 'qr_code' && (
            <div className="space-y-4 flex flex-col items-center text-center">
              <p className="text-xs text-slate-600 max-w-sm">
                Faites flasher ce QR Code par vos patients pour qu'ils enregistrent immédiatement votre cabinet dans leur téléphone ou réservent sur WhatsApp.
              </p>

              {/* Crisp SVG QR Code Representation */}
              <div className="p-6 bg-white rounded-2xl shadow-md border-2 border-slate-200 inline-block">
                <svg className="w-48 h-48" viewBox="0 0 200 200" fill="none">
                  {/* Outer corner finders */}
                  <rect x="10" y="10" width="50" height="50" fill="#0F2C59" rx="8" />
                  <rect x="20" y="20" width="30" height="30" fill="white" rx="4" />
                  <rect x="25" y="25" width="20" height="20" fill="#00D4B2" rx="2" />

                  <rect x="140" y="10" width="50" height="50" fill="#0F2C59" rx="8" />
                  <rect x="150" y="20" width="30" height="30" fill="white" rx="4" />
                  <rect x="155" y="25" width="20" height="20" fill="#00D4B2" rx="2" />

                  <rect x="10" y="140" width="50" height="50" fill="#0F2C59" rx="8" />
                  <rect x="20" y="150" width="30" height="30" fill="white" rx="4" />
                  <rect x="25" y="155" width="20" height="20" fill="#00D4B2" rx="2" />

                  {/* Aesthetic Data Matrix pattern dots */}
                  {[
                    [70, 20], [85, 20], [100, 20], [115, 20],
                    [70, 35], [100, 35], [120, 35],
                    [80, 50], [95, 50], [110, 50],
                    [20, 70], [35, 70], [50, 70], [70, 70], [90, 70], [110, 70], [130, 70], [150, 70], [170, 70],
                    [20, 85], [40, 85], [70, 85], [100, 85], [130, 85], [160, 85],
                    [20, 100], [50, 100], [80, 100], [110, 100], [140, 100], [170, 100],
                    [30, 115], [60, 115], [90, 115], [120, 115], [150, 115],
                    [70, 140], [85, 140], [110, 140], [130, 140], [160, 140], [180, 140],
                    [70, 155], [95, 155], [120, 155], [150, 155], [175, 155],
                    [70, 170], [85, 170], [105, 170], [135, 170], [165, 170],
                  ].map(([cx, cy], i) => (
                    <rect key={i} x={cx} y={cy} width="9" height="9" fill="#0F2C59" rx="2" />
                  ))}
                  {/* Center branding icon */}
                  <rect x="85" y="85" width="30" height="30" fill="#00D4B2" rx="6" />
                  <text x="100" y="105" fontSize="16" fontWeight="bold" textAnchor="middle" fill="#0F2C59">D</text>
                </svg>
              </div>

              <div className="flex gap-3 mt-2">
                <button
                  onClick={() => window.print()}
                  className="px-4 py-2 bg-[#0F2C59] hover:bg-[#163a73] text-white text-xs font-bold rounded-xl flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Imprimer pour le comptoir</span>
                </button>
                <button
                  onClick={downloadVCard}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold rounded-xl flex items-center gap-1.5 border border-slate-300"
                >
                  <Share2 className="w-3.5 h-3.5" />
                  <span>Télécharger la vCard</span>
                </button>
              </div>
            </div>
          )}

          {/* 9. VCARD DOWNLOAD */}
          {modal.type === 'vcard' && (
            <div className="space-y-4 text-center">
              <div className="w-12 h-12 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center mx-auto">
                <Phone className="w-6 h-6" />
              </div>
              <h4 className="text-base font-bold text-slate-900">Enregistrement Instantané du Contact</h4>
              <p className="text-xs text-slate-600 max-w-md mx-auto">
                En 1 clic, votre patient télécharge le fichier contact format standard (.vcf) avec nom du cabinet, adresse exacte, téléphone, WhatsApp direct et lien du site.
              </p>
              <button
                onClick={downloadVCard}
                className="w-full py-3 bg-[#00D4B2] hover:bg-[#10B981] text-[#0A192F] font-bold text-xs rounded-xl shadow-md flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>Télécharger la fiche contact (.vcf)</span>
              </button>
            </div>
          )}

          {/* 10. ITINÉRAIRE GOOGLE MAPS */}
          {modal.type === 'maps_itinerary' && (
            <div className="space-y-4">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-center gap-3">
                <MapPin className="w-5 h-5 text-rose-500 shrink-0" />
                <div>
                  <div className="text-xs font-bold text-slate-900">Localisation GPS du Cabinet</div>
                  <div className="text-[11px] text-slate-500">Boulevard Principal, Centre-ville</div>
                </div>
              </div>
              <div className="h-44 rounded-xl bg-slate-200 overflow-hidden relative flex items-center justify-center border border-slate-300">
                <div className="text-xs text-slate-600 text-center p-4">
                  <MapPin className="w-8 h-8 text-rose-500 mx-auto mb-1 animate-bounce" />
                  <span>Aperçu de la fiche Google Maps et itinéraire GPS 1-clic pour vos patients.</span>
                </div>
              </div>
              <a
                href="https://maps.google.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold text-xs"
              >
                <ExternalLink className="w-4 h-4" />
                <span>Ouvrir l'itinéraire sur Google Maps</span>
              </a>
            </div>
          )}

          {/* 11. BANQUE INSTAGRAM 52 SEMAINES */}
          {modal.type === 'instagram_bank' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                1 publication par semaine prête à être copiée, conçue pour éduquer et transformer vos abonnés en patients :
              </p>

              <div className="space-y-3">
                {[
                  {
                    week: 'Semaine 1',
                    theme: 'Peur du dentiste / Stomatophobie',
                    caption: 'Saviez-vous que 1 personne sur 3 hésite à consulter par appréhension ? Dans notre cabinet, chaque soin se fait à votre rythme, sous anesthésie douce et sans douleur. Prenez le contrôle de votre santé avec sérénité.',
                    tags: '#dentiste #soinsdentaires #sourire #bienetre #maroc',
                  },
                  {
                    week: 'Semaine 2',
                    theme: 'Mythe : Le charbon actif blanchit-il les dents ?',
                    caption: 'Attention aux fausses astuces d’Internet ! Le charbon végétal est abrasif : il raye l’émail sans blanchir la teinte naturelle. Pour un éclaircissement sécurisé, seul le peroxyde professionnel sous contrôle médical protège votre émail.',
                    tags: '#blanchimentdentaire #sourireparfait #conseildentiste',
                  },
                  {
                    week: 'Semaine 3',
                    theme: 'Pourquoi remplacer une molaire manquante ?',
                    caption: 'Même si elle ne se voit pas, une molaire perdue fait basculer les dents voisines et use votre mâchoire. L’implant dentaire préserve l’os et rétablit une mastication saine et puissante.',
                    tags: '#implantdentaire #chirurgiedentaire #santé',
                  },
                ].map((item, idx) => (
                  <div key={idx} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-xs font-bold text-[#0F2C59]">{item.week} : {item.theme}</span>
                      <button
                        onClick={() => handleCopy(`insta-${idx}`, `${item.caption}\n\n${item.tags}`)}
                        className="inline-flex items-center gap-1 text-[11px] font-semibold text-teal-700 bg-white px-2 py-0.5 rounded border border-slate-200"
                      >
                        {copiedId === `insta-${idx}` ? 'Copié !' : 'Copier'}
                      </button>
                    </div>
                    <p className="text-xs text-slate-700 mb-2 leading-relaxed">{item.caption}</p>
                    <span className="text-[11px] text-blue-600 font-mono">{item.tags}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 12. PUBLICATIONS GOOGLE MAPS */}
          {modal.type === 'google_posts' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                L’algorithme Google Maps valorise les fiches actives. Publiez ces mises à jour mensuelles pour booster votre classement :
              </p>

              {[
                {
                  title: 'Post Nouveauté & Équipement',
                  body: 'Notre cabinet renforce son plateau technique avec la radiographie 3D Cone Beam de dernière génération pour des diagnostics d’implants ultra-précis.',
                },
                {
                  title: 'Post Horaires & Disponibilités',
                  body: 'Permanence assurée pour vos urgences dentaires du lundi au samedi. Contactez directement notre secrétariat via le bouton WhatsApp.',
                },
              ].map((p, idx) => (
                <div key={idx} className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-xs font-bold text-[#0F2C59]">{p.title}</span>
                    <button
                      onClick={() => handleCopy(`gpost-${idx}`, p.body)}
                      className="text-[11px] font-semibold text-teal-700 bg-white px-2 py-0.5 rounded border border-slate-200"
                    >
                      {copiedId === `gpost-${idx}` ? 'Copié !' : 'Copier'}
                    </button>
                  </div>
                  <p className="text-xs text-slate-700 leading-relaxed">{p.body}</p>
                </div>
              ))}
            </div>
          )}

          {/* 13. GUIDE TOP 3 GOOGLE MAPS */}
          {modal.type === 'maps_top3_guide' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                La check-list exacte pour passer devant vos confrères sur la carte Google locale :
              </p>

              <div className="space-y-2.5">
                {[
                  '1. Cohérence stricte du NAP (Nom, Adresse exacte, Numéro de téléphone) sur tous les annuaires.',
                  '2. Catégorie principale configurée sur "Chirurgien-dentiste" et secondaires sur "Clinique dentaire", "Implantologue".',
                  '3. Ajout de 10 photos professionnelles réelles du cabinet (façade, accueil, fauteuil, stérilisation).',
                  '4. Réponse systématique à 100% des avis reçus en moins de 48h en intégrant des mots-clés de soins.',
                  '5. Activation de la messagerie instantanée WhatsApp reliée au profil Google Business.',
                ].map((step, idx) => (
                  <div key={idx} className="p-2.5 bg-slate-50 rounded-lg border border-slate-200 text-xs text-slate-800 flex items-start gap-2">
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{step}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 14. SCÉNARIOS SECRÉTAIRE MÉDICALE */}
          {modal.type === 'secretary_script' && (
            <div className="space-y-4">
              <p className="text-xs text-slate-600">
                Script téléphonique mot-à-mot pour convertir les patients indécis sans paraître commercial :
              </p>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
                <div className="font-bold text-[#0F2C59]">Situation : Le patient demande "Combien coûte une couronne ?"</div>
                <p className="text-slate-700 italic">
                  <strong>Secrétaire :</strong> "Bonjour Monsieur/Madame ! Nos couronnes en zircone haute esthétique débutent à 2200 DH selon la dent concernée. Mais pour s'assurer que la racine est saine et peut recevoir la couronne en toute sécurité, le Docteur effectue systématiquement un contrôle préalable avec radiographie. Préférez-vous un créneau le matin ou en après-midi pour que le Docteur examine votre situation ?"
                </p>
                <div className="pt-2 text-[11px] text-teal-800 font-semibold border-t border-slate-200">
                  Résultat : Le patient ne raccroche pas pour comparer ailleurs, il réserve son bilan.
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 bg-slate-100/80 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 dark:text-slate-400 font-medium">
            Composant actif de l'écosystème Dental Branding Pro
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-white dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold rounded-lg border border-slate-300 dark:border-slate-700 transition-colors"
          >
            Fermer
          </button>
        </div>

      </div>
    </div>
  );
};
