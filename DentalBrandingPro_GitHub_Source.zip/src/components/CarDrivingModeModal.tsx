import React, { useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  RotateCw,
  X,
  Volume2,
  VolumeX,
  Radio,
  Car,
  Settings,
  Sparkles,
  PhoneCall,
  CheckCircle2,
  Gauge,
  FolderSync,
} from 'lucide-react';
import { DENTAL_PODCAST_DATA } from '../data/podcastData';

interface CarDrivingModeModalProps {
  isOpen: boolean;
  onClose: () => void;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  onTogglePlay: () => void;
  onSeek: (seconds: number) => void;
  isMuted: boolean;
  onToggleMute: () => void;
  lang: 'fr' | 'ar';
  onOpenBooking: () => void;
  audioSourceName: string;
  onOpenAudioSettings: () => void;
  onUploadFile: (file: File) => void;
  playbackRate?: number;
  onChangePlaybackRate?: (rate: number) => void;
}

export const CarDrivingModeModal: React.FC<CarDrivingModeModalProps> = ({
  isOpen,
  onClose,
  isPlaying,
  currentTime,
  duration,
  onTogglePlay,
  onSeek,
  isMuted,
  onToggleMute,
  lang,
  onOpenBooking,
  audioSourceName,
  onOpenAudioSettings,
  onUploadFile,
  playbackRate = 1.0,
  onChangePlaybackRate,
}) => {
  const isAr = lang === 'ar';
  const episode = DENTAL_PODCAST_DATA;
  const carFileInputRef = useRef<HTMLInputElement>(null);

  // Format time mm:ss
  const formatTime = (secs: number) => {
    if (isNaN(secs) || !isFinite(secs)) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  // Keyboard controls for car mode (Space = play/pause, Arrows = skip)
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        onTogglePlay();
      } else if (e.code === 'ArrowRight') {
        e.preventDefault();
        onSeek(Math.min(duration, currentTime + (isAr ? -15 : 15)));
      } else if (e.code === 'ArrowLeft') {
        e.preventDefault();
        onSeek(Math.max(0, currentTime + (isAr ? 15 : -15)));
      } else if (e.code === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, isPlaying, currentTime, duration, isAr, onTogglePlay, onSeek, onClose]);

  if (!isOpen) return null;

  const currentChapterIndex = episode.chapters
    .slice()
    .reverse()
    .findIndex((ch) => currentTime >= ch.timeSeconds);

  const currentChapter =
    currentChapterIndex !== -1
      ? episode.chapters[episode.chapters.length - 1 - currentChapterIndex]
      : episode.chapters[0];

  const activeIndex = episode.chapters.findIndex((c) => c.id === currentChapter.id);

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  // Cycle speed rate
  const cyclePlaybackRate = () => {
    if (!onChangePlaybackRate) return;
    const rates = [1.0, 1.25, 1.5, 1.75];
    const currentIndex = rates.indexOf(playbackRate);
    const nextRate = rates[(currentIndex + 1) % rates.length];
    onChangePlaybackRate(nextRate);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-[#060B18] text-white flex flex-col justify-between p-3.5 sm:p-6 select-none overflow-y-auto animate-fadeIn"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      {/* Hidden file input for quick car mode audio change */}
      <input
        type="file"
        ref={carFileInputRef}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onUploadFile(file);
        }}
        accept="audio/*,.mp3,.m4a,.wav"
        className="hidden"
      />

      {/* Atmospheric Ambient Glow (Subtle and non-intrusive) */}
      <div className="fixed inset-0 pointer-events-none opacity-20 overflow-hidden">
        <div className="absolute -top-32 -left-32 w-80 h-80 bg-teal-500 rounded-full blur-[120px]" />
        <div className="absolute -bottom-32 -right-32 w-80 h-80 bg-blue-600 rounded-full blur-[120px]" />
      </div>

      {/* 1. TOP BAR: Clean, spacious, and un-crowded */}
      <header className="relative z-10 flex items-center justify-between pb-3 border-b border-white/10 shrink-0 gap-2">
        {/* Left / Start: Car Mode Badge */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300">
            <Car className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="font-extrabold text-xs sm:text-sm tracking-wide">
              {isAr ? 'وضع القيادة' : 'Mode Conduite'}
            </span>
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
          </div>

          {/* Quick Audio Source trigger */}
          <button
            onClick={() => carFileInputRef.current?.click()}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] text-slate-300 hover:text-cyan-300 transition-colors"
            title={isAr ? 'تغيير الملف الصوتي' : 'Changer la source audio'}
          >
            <FolderSync className="w-3.5 h-3.5 text-cyan-400" />
            <span className="truncate max-w-[130px] font-medium">{audioSourceName}</span>
          </button>
        </div>

        {/* Right / End: Clean Action Buttons (Mute, Speed, Settings, Close) */}
        <div className="flex items-center gap-2">
          {/* Playback Speed Pill */}
          {onChangePlaybackRate && (
            <button
              onClick={cyclePlaybackRate}
              className="px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-mono font-bold text-slate-200 hover:text-white transition-all active:scale-95"
              title={isAr ? 'سرعة التشغيل' : 'Vitesse de lecture'}
            >
              {playbackRate}x
            </button>
          )}

          {/* Settings button */}
          <button
            onClick={onOpenAudioSettings}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-cyan-300 active:scale-95 transition-all"
            title={isAr ? 'خيارات الملف الصوتي' : 'Options audio'}
            aria-label="Settings"
          >
            <Settings className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
          </button>

          {/* Mute button */}
          <button
            onClick={onToggleMute}
            className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center justify-center text-slate-300 hover:text-white active:scale-95 transition-all"
            title={isMuted ? 'Unmute' : 'Mute'}
            aria-label="Volume"
          >
            {isMuted ? (
              <VolumeX className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-rose-400" />
            ) : (
              <Volume2 className="w-4 h-4 sm:w-4.5 sm:h-4.5 text-teal-400" />
            )}
          </button>

          {/* Close / Exit Button: High-visibility, zero-wrap */}
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-3 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-200 hover:text-white active:scale-95 transition-all font-bold text-xs sm:text-sm shadow-md"
            title={isAr ? 'الخروج من وضع القيادة' : 'Quitter le mode conduite'}
          >
            <X className="w-4 h-4" />
            <span>{isAr ? 'خروج' : 'Fermer'}</span>
          </button>
        </div>
      </header>

      {/* 2. MAIN PLAYER BODY: Well-spaced, elegant, uncluttered */}
      <main className="relative z-10 my-auto py-3 sm:py-5 flex flex-col items-center text-center max-w-xl mx-auto w-full px-1 shrink-0">
        {/* Podcast Title Kicker */}
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-950/60 border border-teal-500/30 text-teal-300 text-xs font-bold mb-2.5">
          <Radio className="w-3.5 h-3.5 text-teal-400 animate-pulse" />
          <span>Dental Branding Pro • {isAr ? 'البودكاست الطبي' : 'Podcast Médical'}</span>
        </div>

        {/* Episode Main Title */}
        <h1 className="text-base sm:text-lg md:text-xl font-black text-white leading-snug tracking-tight mb-4 px-2">
          {isAr ? episode.title.ar : episode.title.fr}
        </h1>

        {/* Current Chapter Card: Refined Glassmorphic Display (Zero Blue Clutter) */}
        <div className="w-full bg-slate-900/70 border border-white/10 hover:border-teal-500/40 rounded-2xl p-3.5 sm:p-4 mb-4 backdrop-blur-md shadow-xl text-start transition-all">
          <div className="flex items-center justify-between gap-2 mb-1.5">
            <div className="flex items-center gap-2 text-teal-300 font-extrabold text-xs uppercase tracking-wider">
              {/* Animated Mini Waveform */}
              <div className="flex items-end gap-0.5 h-3.5">
                <span
                  className={`w-1 bg-teal-400 rounded-full transition-all ${
                    isPlaying ? 'animate-bounce h-3.5' : 'h-1.5'
                  }`}
                  style={{ animationDuration: '0.6s' }}
                />
                <span
                  className={`w-1 bg-teal-400 rounded-full transition-all ${
                    isPlaying ? 'animate-bounce h-2.5' : 'h-2'
                  }`}
                  style={{ animationDuration: '0.8s', animationDelay: '0.15s' }}
                />
                <span
                  className={`w-1 bg-teal-400 rounded-full transition-all ${
                    isPlaying ? 'animate-bounce h-3.5' : 'h-1'
                  }`}
                  style={{ animationDuration: '0.7s', animationDelay: '0.3s' }}
                />
              </div>
              <span>
                {isAr ? 'المحور الحالي' : 'Chapitre actuel'} ({currentChapter.timeFormatted})
              </span>
            </div>

            <span className="text-[11px] font-mono font-bold px-2 py-0.5 rounded-md bg-white/10 text-slate-300">
              {activeIndex + 1} / {episode.chapters.length}
            </span>
          </div>

          <div className="text-sm sm:text-base md:text-lg font-black text-white leading-snug">
            {isAr ? currentChapter.title.ar : currentChapter.title.fr}
          </div>

          <p className="text-xs sm:text-sm text-slate-300/80 mt-1 line-clamp-1">
            {isAr ? currentChapter.description.ar : currentChapter.description.fr}
          </p>
        </div>

        {/* Touch-Friendly Progress Bar & Timestamps */}
        <div className="w-full space-y-1.5 mb-4">
          <div
            className="w-full h-3.5 sm:h-4 bg-slate-800 rounded-full overflow-hidden cursor-pointer p-0.5 relative border border-white/10"
            onClick={(e) => {
              const rect = e.currentTarget.getBoundingClientRect();
              const clickX = isAr ? rect.right - e.clientX : e.clientX - rect.left;
              const ratio = Math.max(0, Math.min(1, clickX / rect.width));
              onSeek(ratio * duration);
            }}
          >
            <div
              className="h-full bg-gradient-to-r from-teal-400 via-cyan-400 to-emerald-400 rounded-full transition-all duration-150 relative"
              style={{ width: `${progressPercent}%` }}
            >
              <span className="absolute top-1/2 -translate-y-1/2 right-0.5 w-2.5 h-2.5 bg-white rounded-full shadow-md" />
            </div>
          </div>

          <div className="flex justify-between items-center text-xs sm:text-sm font-mono font-bold text-slate-400 px-1">
            <span>{formatTime(currentTime)}</span>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* 3. XXL Ergonomic Driving Controls */}
        <div className="flex items-center justify-center gap-5 sm:gap-8 my-2">
          {/* Skip Back 15s */}
          <button
            onClick={() => onSeek(Math.max(0, currentTime - 15))}
            className="flex flex-col items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-teal-400/50 active:scale-90 transition-all text-slate-200 shadow-lg"
            title={isAr ? 'تراجع 15 ثانية' : 'Reculer 15s'}
          >
            <RotateCcw className="w-6 h-6 sm:w-7 sm:h-7 text-teal-400" />
            <span className="text-[10px] sm:text-xs font-mono font-bold mt-1 text-slate-300">-15s</span>
          </button>

          {/* MASSIVE Play / Pause Button */}
          <button
            onClick={onTogglePlay}
            className={`flex items-center justify-center w-22 h-22 sm:w-26 sm:h-26 rounded-full font-black shadow-2xl transition-all active:scale-95 ${
              isPlaying
                ? 'bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 text-white shadow-amber-500/40 ring-4 sm:ring-6 ring-amber-500/25'
                : 'bg-gradient-to-br from-[#00D4B2] via-teal-500 to-emerald-500 text-slate-950 shadow-teal-500/50 ring-4 sm:ring-6 ring-teal-500/25 animate-pulse'
            }`}
            aria-label={isPlaying ? 'Pause' : 'Play'}
          >
            {isPlaying ? (
              <Pause className="w-10 h-10 sm:w-12 sm:h-12 fill-current" />
            ) : (
              <Play className="w-10 h-10 sm:w-12 sm:h-12 fill-current translate-x-0.5" />
            )}
          </button>

          {/* Skip Forward 15s */}
          <button
            onClick={() => onSeek(Math.min(duration, currentTime + 15))}
            className="flex flex-col items-center justify-center w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/15 hover:border-teal-400/50 active:scale-90 transition-all text-slate-200 shadow-lg"
            title={isAr ? 'تقديم 15 ثانية' : 'Avancer 15s'}
          >
            <RotateCw className="w-6 h-6 sm:w-7 sm:h-7 text-teal-400" />
            <span className="text-[10px] sm:text-xs font-mono font-bold mt-1 text-slate-300">+15s</span>
          </button>
        </div>

        {/* 4. Quick Chapter Selection Strip */}
        <div className="flex items-center justify-center gap-2 overflow-x-auto py-2 w-full max-w-lg no-scrollbar">
          {episode.chapters.map((ch, idx) => {
            const isCurrent = currentChapter.id === ch.id;
            return (
              <button
                key={ch.id}
                onClick={() => onSeek(ch.timeSeconds)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all border shrink-0 ${
                  isCurrent
                    ? 'bg-teal-500 text-slate-950 border-teal-400 shadow-md font-black'
                    : 'bg-white/5 text-slate-300 border-white/10 hover:border-white/25 hover:text-white'
                }`}
              >
                #{idx + 1} {ch.timeFormatted}
              </button>
            );
          })}
        </div>
      </main>

      {/* 5. BOTTOM BAR: Slim, non-intrusive and never cut off */}
      <footer className="relative z-10 w-full max-w-xl mx-auto pt-2 shrink-0">
        <div className="flex items-center justify-between gap-3 p-2.5 sm:p-3 rounded-2xl bg-white/5 border border-white/10 text-xs sm:text-sm backdrop-blur-xs">
          <div className="flex items-center gap-2 text-slate-300 truncate">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span className="truncate text-xs sm:text-xs font-medium">
              {isAr
                ? 'المنظومة الشاملة: 2000 درهم (الدفع بعد الاستلام والمعاينة)'
                : 'Pack Clé en Main : 2000 DH (Paiement après livraison)'}
            </span>
          </div>

          <button
            onClick={() => {
              onClose();
              onOpenBooking();
            }}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-1.5 sm:px-4 sm:py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black shadow-md active:scale-95 transition-all text-xs shrink-0"
          >
            <PhoneCall className="w-3.5 h-3.5" />
            <span>{isAr ? 'حجز الآن' : 'Commander'}</span>
          </button>
        </div>
      </footer>
    </div>
  );
};
