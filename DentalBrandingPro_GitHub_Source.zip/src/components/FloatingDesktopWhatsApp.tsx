import React, { useState } from 'react';
import { Language } from '../types';
import { MessageCircle, X, ShieldCheck } from 'lucide-react';

interface FloatingDesktopWhatsAppProps {
  lang: Language;
}

export const FloatingDesktopWhatsApp: React.FC<FloatingDesktopWhatsAppProps> = ({ lang }) => {
  const isAr = lang === 'ar';
  const [isOpen, setIsOpen] = useState(true);
  const [isHovered, setIsHovered] = useState(false);

  const whatsappMessage = isAr
    ? encodeURIComponent('السلام عليكم Dental Branding Pro، أود الاستفسار حول المنظومة الرقمية لعيادة الأسنان وباقة 2000 درهم (عرض لفترة محدودة).')
    : encodeURIComponent("Bonjour Dental Branding Pro, je souhaite des informations sur l'écosystème pour cabinet dentaire et le pack à 2000 DH (offre limitée).");

  const whatsappUrl = `https://wa.me/212717516563?text=${whatsappMessage}`;

  return (
    <aside
      aria-label={isAr ? 'محادثة فورية على واتساب' : 'Assistance WhatsApp'}
      className="hidden md:flex fixed bottom-6 end-6 z-40 flex-col items-end gap-2.5 transition-all duration-300 font-sans"
    >
      {/* Interactive Floating Card / Tooltip */}
      {isOpen && (
        <div
          role="region"
          aria-label={isAr ? 'نافذة المساعدة السريعة' : 'Fenêtre d’assistance rapide'}
          className={`relative bg-white dark:bg-[#0A192F] text-slate-800 dark:text-white p-4 rounded-2xl shadow-2xl border-2 border-emerald-500/40 w-72 sm:w-80 transition-all duration-300 transform ${
            isHovered ? 'scale-102 shadow-emerald-500/10' : ''
          }`}
          onMouseEnter={() => setIsHovered(true)}
          onMouseLeave={() => setIsHovered(false)}
        >
          {/* Close button */}
          <button
            onClick={() => setIsOpen(false)}
            aria-label={isAr ? 'إغلاق نافذة المساعدة' : 'Fermer la fenêtre'}
            className="absolute top-2.5 end-2.5 p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>

          {/* Header with avatar & active status */}
          <div className="flex items-center gap-3 mb-2.5">
            <div className="relative shrink-0">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white shadow-md">
                <MessageCircle className="w-5 h-5 fill-current" />
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 rounded-full border-2 border-white dark:border-[#0A192F] animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">
                  {isAr ? 'فريق Dental Branding Pro' : 'Support Dental Branding Pro'}
                </h4>
              </div>
              <p className="text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                <span>{isAr ? 'متصل الآن • رد فوري للأطباء' : 'En ligne • Réponse immédiate'}</span>
              </p>
            </div>
          </div>

          {/* Body prompt */}
          <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-3">
            {isAr ? (
              <>
                مرحباً دكتور، هل لديك أي استفسار حول{' '}
                <span className="font-bold text-slate-900 dark:text-white">باقة 2000 درهم</span>{' '}
                <span className="text-[10px] text-slate-400 line-through decoration-[1.5px] whitespace-nowrap">
                  5000 درهم
                </span>{' '}
                أو الدفع بعد المعاينة ؟
              </>
            ) : (
              <>
                Docteur, une question sur le{' '}
                <span className="font-bold text-slate-900 dark:text-white">Pack à 2000 DH</span>{' '}
                <span className="text-[10px] text-slate-400 line-through decoration-[1.5px] whitespace-nowrap">
                  5000 DH
                </span>{' '}
                ou le paiement après livraison ?
              </>
            )}
          </p>

          {/* Ethics guarantee tag */}
          <div className="mb-3 px-2.5 py-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200/60 dark:border-emerald-800/60 flex items-center gap-1.5 text-[10px] font-semibold text-emerald-800 dark:text-emerald-300">
            <ShieldCheck className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
            <span>
              {isAr
                ? 'متوافق 100% مع أخلاقيات هيئة أطباء الأسنان'
                : '100% Conforme à la Déontologie de l’Ordre'}
            </span>
          </div>

          {/* Direct CTA Button */}
          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full py-2.5 px-3.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs shadow-md shadow-emerald-600/20 hover:shadow-emerald-600/35 transition-all flex items-center justify-center gap-2 group"
          >
            <MessageCircle className="w-4 h-4 fill-current group-hover:scale-110 transition-transform" />
            <span>{isAr ? 'بدء محادثة واتساب فورية' : 'Ouvrir WhatsApp en direct'}</span>
          </a>
        </div>
      )}

      {/* Main Floating Trigger Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        onClick={(e) => {
          if (!isOpen) {
            e.preventDefault();
            setIsOpen(true);
          }
        }}
        aria-label={isAr ? 'تواصل معنا على واتساب' : 'Contacter sur WhatsApp'}
        className="group relative flex items-center gap-2.5 px-4 py-3 bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-full shadow-2xl shadow-emerald-600/30 hover:shadow-emerald-600/50 transition-all transform hover:-translate-y-1 active:scale-95"
      >
        <div className="relative">
          <MessageCircle className="w-5 h-5 fill-current" />
          <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full border border-white dark:border-slate-900" />
        </div>
        <span className="text-xs font-bold whitespace-nowrap">
          {isAr ? 'محادثة فورية (0717516563)' : 'WhatsApp Direct (0717516563)'}
        </span>
      </a>
    </aside>
  );
};
