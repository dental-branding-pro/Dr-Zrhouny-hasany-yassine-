import React, { useState, useRef } from 'react';
import {
  X,
  UploadCloud,
  FileAudio,
  Link2,
  Mic,
  Volume2,
  Check,
  AlertCircle,
  HelpCircle,
  Sparkles,
  RefreshCw,
  ExternalLink,
} from 'lucide-react';
import { DENTAL_PODCAST_DATA } from '../data/podcastData';

interface AudioSourceModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: 'fr' | 'ar';
  currentSourceName: string;
  isCustomFile: boolean;
  onUploadFile: (file: File) => void;
  onSetUrl: (url: string) => void;
  onResetToDefault: () => void;
}

export const AudioSourceModal: React.FC<AudioSourceModalProps> = ({
  isOpen,
  onClose,
  lang,
  currentSourceName,
  isCustomFile,
  onUploadFile,
  onSetUrl,
  onResetToDefault,
}) => {
  const isAr = lang === 'ar';
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [urlInput, setUrlInput] = useState('');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onUploadFile(file);
      setSuccessToast(
        isAr
          ? `تم تحميل الملف بنجاح: ${file.name}`
          : `Fichier audio chargé avec succès : ${file.name}`
      );
      setTimeout(() => {
        setSuccessToast(null);
        onClose();
      }, 1500);
    }
  };

  const handleApplyUrl = (e: React.FormEvent) => {
    e.preventDefault();
    if (!urlInput.trim()) return;
    onSetUrl(urlInput.trim());
    setSuccessToast(
      isAr ? 'تم تفعيل الرابط الصوتي بنجاح!' : 'Lien audio appliqué avec succès !'
    );
    setTimeout(() => {
      setSuccessToast(null);
      onClose();
    }, 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn"
      dir={isAr ? 'rtl' : 'ltr'}
    >
      <div className="bg-[#0A192F] border border-cyan-500/30 text-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl relative max-h-[90vh] overflow-y-auto">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 end-5 p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-all"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
            <FileAudio className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-xl sm:text-2xl font-black text-white">
              {isAr ? 'إعداد وتشغيل ملف البودكاست الصوتي' : 'Configuration du Fichier Podcast'}
            </h3>
            <p className="text-xs text-slate-400">
              {isAr
                ? 'اختر مصدر الصوت الذي ترغب في سماعه في الموقع ووضع القيادة'
                : "Choisissez la source audio à écouter sur le site et en mode conduite"}
            </p>
          </div>
        </div>

        {/* Current Audio Badge */}
        <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 mb-6 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Volume2 className="w-5 h-5 text-cyan-400 shrink-0" />
            <div className="text-xs">
              <span className="text-slate-400 block">
                {isAr ? 'المصدر النشط حالياً:' : 'Source active :'}
              </span>
              <span className="font-bold text-white text-sm">
                {currentSourceName}
              </span>
            </div>
          </div>
          {isCustomFile && (
            <button
              onClick={() => {
                onResetToDefault();
                setSuccessToast(isAr ? 'تمت العودة للصوت الافتراضي' : 'Réinitialisé');
                setTimeout(() => setSuccessToast(null), 1500);
              }}
              className="text-xs font-bold px-3 py-1.5 rounded-xl bg-rose-500/20 text-rose-300 hover:bg-rose-500/30 transition-all flex items-center gap-1"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>{isAr ? 'استعادة الافتراضي' : 'Réinitialiser'}</span>
            </button>
          )}
        </div>

        {/* Success Alert */}
        {successToast && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-bold flex items-center gap-2 animate-fadeIn">
            <Check className="w-4 h-4" />
            <span>{successToast}</span>
          </div>
        )}

        <div className="space-y-4">
          {/* NATIVE EMBEDDED AUDIO STATUS */}
          <div className="p-4 rounded-2xl bg-emerald-950/40 border-2 border-emerald-500/50 shadow-lg shadow-emerald-950/50">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-extrabold text-emerald-300 flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                {isAr ? '✨ المقطع الصوتي مثبت برمجياً في الموقع' : '✨ Audio Officiel Intégré au Site'}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {isAr ? 'مُدمج 100%' : 'Intégré 100%'}
              </span>
            </div>
            <p className="text-xs text-slate-300 mb-3 leading-relaxed">
              {isAr
                ? 'تم دمج وتثبيت ملف البودكاست الأصلي مباشرة في ملفات الموقع. يعمل تلقائياً عند فتح الموقع دون الحاجة لتحميل أي ملف خارجي أو الذهاب لمواقع أخرى.'
                : 'Le fichier audio complet est installé directement sur le serveur du site web. Il démarre automatiquement à l’ouverture, sans aucun téléchargement requis.'}
            </p>

            <button
              onClick={() => {
                onResetToDefault();
                onClose();
              }}
              className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-black text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all active:scale-95"
            >
              <span>{isAr ? '▶️ تشغيل المقطع المثبت برمجياً الآن' : '▶️ Écouter la version intégrée'}</span>
            </button>
          </div>

          {/* OPTIONAL: Direct File Upload from Device */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-cyan-950/30 to-slate-900 border border-cyan-500/30 hover:border-cyan-400 transition-all">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs sm:text-sm font-extrabold text-cyan-300 flex items-center gap-2">
                <UploadCloud className="w-4 h-4" />
                {isAr
                  ? 'اختياري: استخدام ملف صوتي مخصص آخر'
                  : 'Optionnel : Utiliser un autre fichier audio personnalisé'}
              </span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300">
                MP3, M4A, WAV
              </span>
            </div>
            <p className="text-xs text-slate-400 mb-4 leading-relaxed">
              {isAr
                ? 'إذا كان لديك ملف صوتي مسجل جديد وترغب في تجربته مكان المقطع المدمج:'
                : 'Si vous avez un autre fichier audio et souhaitez l’écouter à la place de l’épisode intégré :'}
            </p>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="audio/*,.mp3,.m4a,.wav,.aac,.ogg"
              className="hidden"
            />

            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-cyan-400 via-teal-500 to-emerald-400 hover:opacity-95 text-slate-950 font-black text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 active:scale-95 transition-all"
            >
              <UploadCloud className="w-5 h-5" />
              <span>
                {isAr
                  ? '📂 اختر ملف البودكاست من هاتفك / حاسوبك'
                  : '📂 Choisir le fichier audio sur mon appareil'}
              </span>
            </button>
          </div>

          {/* OPTION 2: Direct Link (URL) */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5 mb-2">
              <Link2 className="w-3.5 h-3.5 text-cyan-400" />
              {isAr ? 'الخيار 2: رابط ملف صوتي مباشر (URL)' : 'Option 2 : Lien direct (URL)'}
            </span>
            <form onSubmit={handleApplyUrl} className="flex gap-2">
              <input
                type="url"
                value={urlInput}
                onChange={(e) => setUrlInput(e.target.value)}
                placeholder="https://example.com/podcast.mp3"
                className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-white/15 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs transition-all"
              >
                {isAr ? 'تطبيق' : 'Appliquer'}
              </button>
            </form>
          </div>
        </div>

        {/* Explanation Card: Why wasn't it heard previously? */}
        <div className="mt-5 p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 text-amber-200 text-xs space-y-2">
          <div className="flex items-center gap-2 font-bold text-amber-300">
            <HelpCircle className="w-4 h-4 shrink-0" />
            <span>
              {isAr
                ? 'لماذا لم يُسمع الصوت في المعاينة في المرة السابقة؟'
                : 'Pourquoi le son ne se jouait-il pas précédemment ?'}
            </span>
          </div>
          <p className="leading-relaxed text-slate-300">
            {isAr ? (
              <>
                <strong>1. سياسة المتصفحات:</strong> تمنع معظم المتصفحات تشغيل الصوت تلقائياً (Autoplay) حتى يقوم المستخدم بالضغط بنفسه على زر التشغيل ⏵ أو التأكد من إزالة الكتم.
                <br />
                <strong>2. ملفك الشخصي:</strong> روبوت الذكاء الاصطناعي لا يملك وصولاً لملفات هاتفك الشخصي. لذلك وفرنا لك هذا الزر السريع لتحميل ملفك والاستماع إليه فوراً في المعاينة!
              </>
            ) : (
              <>
                <strong>1. Politique des navigateurs :</strong> La lecture automatique est bloquée jusqu’au clic sur Lecture ⏵.
                <br />
                <strong>2. Fichier privé :</strong> Vos fichiers NotebookLM résident sur votre appareil ; utilisez le bouton ci-dessus pour les charger dans la démo !
              </>
            )}
          </p>
        </div>
      </div>
    </div>
  );
};
